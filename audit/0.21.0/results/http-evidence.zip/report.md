# Community access control comparison

## 영향 (진단자 작성)
Private post/message/file exposure and fixed controls

## 재현 절차
Owner baseline; alternate account; owner recheck. See results.json.

## 1. vuln-private-post owner baseline
GET http://127.0.0.1:18299/api/community/vuln/posts/102

Owner baseline, rechecked with identical body: true

요청: requests/1.http
응답: responses/1.http

## 2. vuln-private-post
GET http://127.0.0.1:18299/api/community/vuln/posts/102

타인 객체 접근 의심 · 소유자 전용 정책 · 소유 필드가 대상 계정 소유값과 다름

요청: requests/2.http
응답: responses/2.http

## 3. vuln-private-message owner baseline
GET http://127.0.0.1:18299/api/community/vuln/messages/202

Owner baseline, rechecked with identical body: true

요청: requests/3.http
응답: responses/3.http

## 4. vuln-private-message
GET http://127.0.0.1:18299/api/community/vuln/messages/202

타인 객체 접근 의심 · 소유자 전용 정책 · 소유 필드가 대상 계정 소유값과 다름

요청: requests/4.http
응답: responses/4.http

## 5. vuln-private-file owner baseline
GET http://127.0.0.1:18299/api/community/vuln/files/bob-private-file

Owner baseline, rechecked with identical body: true

요청: requests/5.http
응답: responses/5.http

## 6. vuln-private-file
GET http://127.0.0.1:18299/api/community/vuln/files/bob-private-file

우회 의심 · 동일 성공 응답 · 수동 확인

요청: requests/6.http
응답: responses/6.http

## 7. vuln-anonymous-file owner baseline
GET http://127.0.0.1:18299/api/community/vuln/files/bob-private-file

Owner baseline, rechecked with identical body: true

요청: requests/7.http
응답: responses/7.http

## 8. vuln-anonymous-file
GET http://127.0.0.1:18299/api/community/vuln/files/bob-private-file

우회 의심 · 동일 성공 응답 · 수동 확인

요청: requests/8.http
응답: responses/8.http

## 9. vuln-admin-spoof owner baseline
GET http://127.0.0.1:18299/api/community/vuln/admin/users

Owner baseline, rechecked with identical body: true

요청: requests/9.http
응답: responses/9.http

## 10. vuln-admin-spoof
GET http://127.0.0.1:18299/api/community/vuln/admin/users

우회 의심 · 비교 대상 JSON 필드 동일 · 실제 접근 확인

요청: requests/10.http
응답: responses/10.http

## 11. vuln-public-policy owner baseline
GET http://127.0.0.1:18299/api/community/vuln/posts/101

Owner baseline, rechecked with identical body: true

요청: requests/11.http
응답: responses/11.http

## 12. vuln-public-policy
GET http://127.0.0.1:18299/api/community/vuln/posts/101

공개/공유 허용 · 설정한 경로·메서드 정책 · 성공 응답 관측

요청: requests/12.http
응답: responses/12.http

## 13. vuln anonymous search
GET http://127.0.0.1:18299/api/community/vuln/search

No injection; private body present=true

요청: requests/13.http
응답: responses/13.http

## 14. vuln unauthorized write readback
GET http://127.0.0.1:18299/api/community/fixed/posts/106

After Alice write: CHANGED_BY_ALICE present=true

요청: requests/14.http
응답: responses/14.http

## 15. fixed-private-post owner baseline
GET http://127.0.0.1:18299/api/community/fixed/posts/102

Owner baseline, rechecked with identical body: true

요청: requests/15.http
응답: responses/15.http

## 16. fixed-private-post
GET http://127.0.0.1:18299/api/community/fixed/posts/102

은닉형 접근 차단 후보 · 소유자 재조회 2xx 동일 · 대상 HTTP 404

요청: requests/16.http
응답: responses/16.http

## 17. fixed-private-message owner baseline
GET http://127.0.0.1:18299/api/community/fixed/messages/202

Owner baseline, rechecked with identical body: true

요청: requests/17.http
응답: responses/17.http

## 18. fixed-private-message
GET http://127.0.0.1:18299/api/community/fixed/messages/202

은닉형 접근 차단 후보 · 소유자 재조회 2xx 동일 · 대상 HTTP 404

요청: requests/18.http
응답: responses/18.http

## 19. fixed-private-file owner baseline
GET http://127.0.0.1:18299/api/community/fixed/files/bob-private-file

Owner baseline, rechecked with identical body: true

요청: requests/19.http
응답: responses/19.http

## 20. fixed-private-file
GET http://127.0.0.1:18299/api/community/fixed/files/bob-private-file

은닉형 접근 차단 후보 · 소유자 재조회 2xx 동일 · 대상 HTTP 404

요청: requests/20.http
응답: responses/20.http

## 21. fixed-anonymous-file owner baseline
GET http://127.0.0.1:18299/api/community/fixed/files/bob-private-file

Owner baseline, rechecked with identical body: true

요청: requests/21.http
응답: responses/21.http

## 22. fixed-anonymous-file
GET http://127.0.0.1:18299/api/community/fixed/files/bob-private-file

은닉형 접근 차단 후보 · 소유자 재조회 2xx 동일 · 대상 HTTP 404

요청: requests/22.http
응답: responses/22.http

## 23. fixed-admin-spoof owner baseline
GET http://127.0.0.1:18299/api/community/fixed/admin/users

Owner baseline, rechecked with identical body: true

요청: requests/23.http
응답: responses/23.http

## 24. fixed-admin-spoof
GET http://127.0.0.1:18299/api/community/fixed/admin/users

차단 근거 확인 · HTTP 403

요청: requests/24.http
응답: responses/24.http

## 25. fixed-public-policy owner baseline
GET http://127.0.0.1:18299/api/community/fixed/posts/101

Owner baseline, rechecked with identical body: true

요청: requests/25.http
응답: responses/25.http

## 26. fixed-public-policy
GET http://127.0.0.1:18299/api/community/fixed/posts/101

공개/공유 허용 · 설정한 경로·메서드 정책 · 성공 응답 관측

요청: requests/26.http
응답: responses/26.http

## 27. fixed anonymous search
GET http://127.0.0.1:18299/api/community/fixed/search

No injection; private body present=false

요청: requests/27.http
응답: responses/27.http

## 28. fixed unauthorized write readback
GET http://127.0.0.1:18299/api/community/fixed/posts/106

After Alice write: CHANGED_BY_ALICE present=false

요청: requests/28.http
응답: responses/28.http


자동 관찰은 후보이며 진단자가 실제 영향과 재현 결과를 확인해야 합니다. 인증값·쿼리값은 가려져 있으므로 재현 시 로컬 원본으로 보완하세요.
