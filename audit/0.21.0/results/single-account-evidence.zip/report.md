# Evidence gate audit

## 영향 (진단자 작성)
fixture

## 재현 절차
Alice evidence only

## 1. Alice only
GET http://127.0.0.1:18299/api/community/fixed/posts

one of two required accounts

요청: requests/1.http
응답: responses/1.http


자동 관찰은 후보이며 진단자가 실제 영향과 재현 결과를 확인해야 합니다. 인증값·쿼리값은 가려져 있으므로 재현 시 로컬 원본으로 보완하세요.
