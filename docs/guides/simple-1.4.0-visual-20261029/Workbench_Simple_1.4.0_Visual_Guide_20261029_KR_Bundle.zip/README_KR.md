# Workbench Simple 1.4.0 화면별 사용 가이드

[Workbench_Simple_1.4.0_Visual_Guide_20261029_KR.pdf](Workbench_Simple_1.4.0_Visual_Guide_20261029_KR.pdf) · [Workbench_Simple_1.4.0_Visual_Guide_20261029_KR.html](Workbench_Simple_1.4.0_Visual_Guide_20261029_KR.html)

압축을 풀고 HTML을 브라우저에서 엽니다. 이미지·폰트·본문은 파일에 포함되어 오프라인으로 읽습니다. PDF는 같은 폴더에 두세요. 외부 제품 설치·검증·공유 대화 링크를 열 때만 인터넷이 필요합니다.

검색·화면 확대·중요 영역 펼치기·이전/다음·다크 모드와 브라우저에 저장되는 단계 확인을 제공합니다. 단계 확인은 실제 사이트 점검 완료 판정이 아닙니다.

원본 캡처는 운영 UI의 합성 예제와 Chrome API fixture이며 실제 Burp GUI/native MV3 설치 성공과 구분합니다. 출처·검증 범위는 SOURCE_NOTES_KR.md와 validation.json, source-manifest.json을 확인하세요. SHA256SUMS는 이 묶음 안의 PDF·HTML을 검증합니다.
