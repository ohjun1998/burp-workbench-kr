# Workbench 0.46.1 Vuln Bank 재검증 근거

최종 실행: after/run6, 이전 버전 같은 환경 대조: before/baseline-run2.
Workbench 독립 도구 10개와 별도 Feature Mapper의 대표 기능 조건입니다. 모든 버튼·페이로드·외부 BApp을 전수검사한 결과가 아닙니다.

권한 비교는 5개 요청 × 4개 계정 = 20칸에서 기준 5칸을 제외합니다. 이전 TP5/TN8/REVIEW2에서 개선 TP5/TN10/REVIEW0이며 두 실행 모두 FP0/FN0입니다. 보류는 다른 분류에 중복 집계하지 않습니다.
SQL은 동일 잔액 경로의 기본 목록과 실제 입력값 검사 패널을 사용했습니다. 음수 송금은 이전 CUSTOM 응답 판정의 공백을, 신규 설정형 쓰기 전후 조회 규칙으로 보완했습니다. CUSTOM의 모든 업무 의미를 자동 추론한다는 뜻이 아닙니다.

PNG는 실제 Burp에서 실행한 확장의 Swing 패널 렌더링입니다. PDF는 읽기 쉽도록 일부 영역을 확대하며 원본 PNG를 보존합니다. 수동 Burp 데스크톱 클릭 검증은 아닙니다. JSON/CSV에 화면의 판정 근거가 있습니다.

실행 환경은 PGlite 0.5.10/PostgreSQL18.6 호환 DB, 순차 Flask2.0.1, 실제 Burp Community2026.3.3/Java21, Chromium146입니다. Vuln Bank 소스는 고정 커밋 원본이며 공식 Compose/PostgreSQL13 환경과 다릅니다. 외부 AI는 기본 mock 모드입니다.

초기 시도에서 PGlite 연결 동시성 지연과 30초 idle timeout에 의한 첫 health 503을 확인했습니다. 최종 두 실행은 연결 한도50, idle timeout0, 순차 Flask로 재검사했습니다. 중간 실행을 최종 결과로 합산하지 않습니다. 브라우저 보조 확장 클릭 연동은 이전 환경 제약으로 재시도하지 않았으며 NOT_RUN입니다.

인증 토큰·개인 프로필·DB 데이터·원본 전체 트래픽은 배포하지 않습니다. 표시된 이름/계좌/잔액은 이 작업의 가상 실습 데이터입니다.

참고: https://github.com/Commando-X/vuln-bank/tree/4bb7cd5f46921959f034455e5615782481966177
PGlite 실행 방식: https://pglite.dev/docs/pglite-socket
