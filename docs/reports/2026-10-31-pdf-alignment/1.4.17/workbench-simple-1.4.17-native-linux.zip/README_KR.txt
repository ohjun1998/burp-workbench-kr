Simple1.4.17 실제 Linux Xorg/xfwm4/Robot 검증 자료입니다. 합성 Burp API·원본을 사용하며 실제 Windows Burp GUI 검증이 아닙니다. 대상 HTTP0건. 두 테마 버튼80·창50·Guide50, 총180개 검사입니다. 캐시·실행 프로필은 포함하지 않습니다.
