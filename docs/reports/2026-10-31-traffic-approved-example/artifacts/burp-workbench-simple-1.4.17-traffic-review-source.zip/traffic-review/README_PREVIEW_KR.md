# 요청·응답 목록 검토 빌드

이 패키지는 Simple1.4.17을 기반으로 요청·응답 목록 화면만 승인 시안에 맞춘 미배포 검토 빌드입니다. 기존 정식1.4.17 배포 파일을 대체하지 않습니다. 내부 버전 번호는1.4.17로 유지합니다.

완전한 독립 빌드 입력(확장/Mapper 소스, 리소스, 고정 의존성, 검사와 도구)을 포함합니다. 이전 버전 설명서와 디자인 이미지 이력은 제외했습니다. Java17과 Python3.10+가 필요합니다.

압축을 푼 뒤 `traffic-review/simple/burp-workbench`에서 `python build_all.py`를 실행하세요. 생성 JAR는 `dist/burp-workbench-simple-1.4.17.jar`입니다. Java17을 PATH에 두세요. API/Rhino/Brotli 의존성은 포함되어 있습니다.

전체 보고서와 실제 Linux Swing 캡처: https://github.com/ohjun1998/burp-workbench-kr/tree/account-a/traffic-approved-exact/docs/reports/2026-10-31-traffic-approved-example
