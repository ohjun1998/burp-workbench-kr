import importlib
import os
import subprocess
import sys
import tempfile
import textwrap
import types
import unittest
from pathlib import Path
from unittest.mock import patch


REPO_ROOT = Path(__file__).resolve().parents[1]


def install_fake_psycopg2():
    if "psycopg2" in sys.modules:
        return

    fake_psycopg2 = types.ModuleType("psycopg2")
    fake_pool_module = types.ModuleType("psycopg2.pool")
    fake_pool_module.PoolError = Exception
    fake_pool_module.SimpleConnectionPool = object
    fake_pool_module.ThreadedConnectionPool = object
    fake_psycopg2.pool = fake_pool_module

    sys.modules["psycopg2"] = fake_psycopg2
    sys.modules["psycopg2.pool"] = fake_pool_module


class DatabasePoolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        install_fake_psycopg2()
        cls.database = importlib.import_module("database")

    def test_get_connection_retries_transient_pool_exhaustion(self):
        database = self.database

        class ExhaustingPool:
            def __init__(self):
                self.calls = 0

            def getconn(self):
                self.calls += 1
                if self.calls == 1:
                    raise database.pool.PoolError("connection pool exhausted")
                return "connection"

        exhausting_pool = ExhaustingPool()
        with patch.object(database, "connection_pool", exhausting_pool), \
                patch.dict(os.environ, {"DB_POOL_CHECKOUT_ATTEMPTS": "2", "DB_POOL_CHECKOUT_RETRY_DELAY": "0"}), \
                patch.object(database.time, "sleep") as sleep, \
                patch("builtins.print"):
            connection = database.get_connection()

        self.assertEqual(connection, "connection")
        self.assertEqual(exhausting_pool.calls, 2)
        sleep.assert_called_once_with(0.0)


class HealthEndpointTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        install_fake_psycopg2()
        import database

        cls._original_init_connection_pool = database.init_connection_pool
        database.init_connection_pool = lambda *args, **kwargs: None

        if "app" in sys.modules:
            del sys.modules["app"]

        try:
            cls.app_module = importlib.import_module("app")
        except ModuleNotFoundError as exc:
            raise unittest.SkipTest(f"App dependencies are not installed locally: {exc.name}") from exc

        cls.client = cls.app_module.app.test_client()

        database.init_connection_pool = cls._original_init_connection_pool

    def test_healthz_returns_ok_when_database_is_available(self):
        with patch.object(self.app_module, "check_database_connection", return_value=True):
            response = self.client.get("/healthz")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), {"status": "ok", "database": "up"})

    def test_healthz_returns_503_when_database_is_unavailable(self):
        with patch.object(self.app_module, "check_database_connection", return_value=False):
            response = self.client.get("/healthz")

        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.get_json(), {"status": "error", "database": "down"})

class StartScriptTests(unittest.TestCase):
    def test_start_script_waits_for_db_and_execs_flask_dev_server(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            bin_dir = tmp_path / "bin"
            bin_dir.mkdir()

            self._write_fake_executable(
                bin_dir / "pg_isready",
                """
                #!/bin/sh
                COUNT_FILE="${TEST_TMPDIR}/pg_isready.count"
                count=0
                if [ -f "$COUNT_FILE" ]; then
                  count=$(cat "$COUNT_FILE")
                fi
                count=$((count + 1))
                printf '%s' "$count" > "$COUNT_FILE"
                if [ "$count" -lt 3 ]; then
                  exit 1
                fi
                exit 0
                """,
            )
            self._write_fake_executable(
                bin_dir / "sleep",
                """
                #!/bin/sh
                exit 0
                """,
            )
            self._write_fake_executable(
                bin_dir / "python",
                """
                #!/bin/sh
                printf '%s\n' "$@" > "${TEST_TMPDIR}/python.args"
                exit 0
                """,
            )

            env = os.environ.copy()
            env.update(
                {
                    "PATH": f"{bin_dir}{os.pathsep}{env['PATH']}",
                    "TEST_TMPDIR": tmp_dir,
                    "DB_HOST": "db",
                    "DB_PORT": "5432",
                    "DB_USER": "postgres",
                    "DB_NAME": "vulnerable_bank",
                }
            )

            result = subprocess.run(
                ["sh", str(REPO_ROOT / "start.sh")],
                cwd=REPO_ROOT,
                env=env,
                capture_output=True,
                text=True,
            )

            self.assertEqual(result.returncode, 0, msg=result.stderr or result.stdout)
            self.assertEqual((tmp_path / "pg_isready.count").read_text(), "3")

            python_args = (tmp_path / "python.args").read_text().splitlines()
            self.assertEqual(python_args, ["app.py"])

    def _write_fake_executable(self, path, script):
        path.write_text(textwrap.dedent(script).lstrip())
        path.chmod(0o755)


if __name__ == "__main__":
    unittest.main()
