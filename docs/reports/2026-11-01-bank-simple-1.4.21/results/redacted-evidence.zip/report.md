# 로컬 VulnBank

## 영향 (진단자 작성)
실습 계정

## 재현 절차
Alice 잔액 접근

## 1. 연결 원본 1
GET http://127.0.0.1:24904/check_balance/1791279111

로컬 은행 Alice 잔액 접근

패킷 ID: http-sha256:df546842821d2701a9d4432e72045b63f1d7fc26f0c2bf2ef3d2bb5452d1d93c
요청: requests/1.http
응답: responses/1.http


자동 관찰은 후보이며 진단자가 실제 영향과 재현 결과를 확인해야 합니다. 인증값·쿼리값은 가려져 있으므로 재현 시 로컬 원본으로 보완하세요. 원본 HTTP 바이트는 이 ZIP에 포함되지 않습니다.
