# Local bounty workflow audit

## 영향 (진단자 작성)
Deliberate vulnerable/fixed controls

## 재현 절차
Owner baseline, alternate account, owner recheck; staged stored/upload reads

## 1. vuln owner baseline 202
GET http://127.0.0.1:18399/api/bounty/vuln/objects/202

Same-object owner baseline; identical owner recheck=true

요청: requests/1.http
응답: responses/1.http

## 2. vuln alternate account 202
GET http://127.0.0.1:18399/api/bounty/vuln/objects/202

기대 DENY · 성공 응답 관측 · 권한 위반 후보, 수동 확인

요청: requests/2.http
응답: responses/2.http

## 3. vuln owner baseline 205
GET http://127.0.0.1:18399/api/bounty/vuln/objects/205

Same-object owner baseline; identical owner recheck=true

요청: requests/3.http
응답: responses/3.http

## 4. vuln alternate account 205
GET http://127.0.0.1:18399/api/bounty/vuln/objects/205

기대 DENY · 성공 응답 관측 · 권한 위반 후보, 수동 확인

요청: requests/4.http
응답: responses/4.http

## 5. fixed owner baseline 202
GET http://127.0.0.1:18399/api/bounty/fixed/objects/202

Same-object owner baseline; identical owner recheck=true

요청: requests/5.http
응답: responses/5.http

## 6. fixed alternate account 202
GET http://127.0.0.1:18399/api/bounty/fixed/objects/202

기대 DENY · 차단 근거 일치 · 소유자 재조회 2xx 동일 · 대상 HTTP 404

요청: requests/6.http
응답: responses/6.http

## 7. fixed owner baseline 205
GET http://127.0.0.1:18399/api/bounty/fixed/objects/205

Same-object owner baseline; identical owner recheck=true

요청: requests/7.http
응답: responses/7.http

## 8. fixed alternate account 205
GET http://127.0.0.1:18399/api/bounty/fixed/objects/205

기대 DENY · 차단 근거 일치 · 소유자 재조회 2xx 동일 · 대상 HTTP 404

요청: requests/8.http
응답: responses/8.http

## 9. vuln stored write
POST http://127.0.0.1:18399/api/bounty/vuln/stored

Successful write; no browser execution claim

요청: requests/9.http
응답: responses/9.http

## 10. vuln stored read
GET http://127.0.0.1:18399/api/bounty/vuln/stored/602a4d1e-d3bd-44fa-b28c-375d4f7bda7f

흐름 SF-F2 · 마커 PR_0123456789abcdeb
쓰기 성공 응답: 관측 (저장 자체의 증명 아님)
조회 재출력: 2xx 응답에서 관측
HTML 응답 출력: 관측 · 실행 미검증
브라우저 실행: 미검증
쓰기 원본: SF-P1 · POST http://127.0.0.1:18399/api/bounty/vuln/stored · HTTP 200
조회 원본: SF-P2 · GET http://127.0.0.1:18399/api/bounty/vuln/stored/602a4d1e-d3bd-44fa-b28c-375d4f7bda7f · HTTP 200
같은 Origin/마커에 따른 연관 후보입니다. 서버 영구 저장·사용자 영향은 별도 확인하세요. 원문/쿼리 값/인증값은 이 요약에 포함하지 않습니다.

요청: requests/10.http
응답: responses/10.http

## 11. vuln upload download
GET http://127.0.0.1:18399/api/bounty/vuln/uploads/5bd70ef0-71ab-4e9d-870d-5def9db8481a

HTML inline versus text attachment; browser execution not tested

요청: requests/11.http
응답: responses/11.http

## 12. fixed stored write
POST http://127.0.0.1:18399/api/bounty/fixed/stored

Successful write; no browser execution claim

요청: requests/12.http
응답: responses/12.http

## 13. fixed stored read
GET http://127.0.0.1:18399/api/bounty/fixed/stored/9180fc60-b0e2-4853-80b4-3f39c27b5f99

흐름 SF-F2 · 마커 PR_0123456789abcdea
쓰기 성공 응답: 관측 (저장 자체의 증명 아님)
조회 재출력: 2xx 응답에서 관측
HTML 응답 출력: 이스케이프 문자 후보 · 안전 확정 아님
브라우저 실행: 미검증
쓰기 원본: SF-P1 · POST http://127.0.0.1:18399/api/bounty/fixed/stored · HTTP 200
조회 원본: SF-P2 · GET http://127.0.0.1:18399/api/bounty/fixed/stored/9180fc60-b0e2-4853-80b4-3f39c27b5f99 · HTTP 200
같은 Origin/마커에 따른 연관 후보입니다. 서버 영구 저장·사용자 영향은 별도 확인하세요. 원문/쿼리 값/인증값은 이 요약에 포함하지 않습니다.

요청: requests/13.http
응답: responses/13.http

## 14. fixed upload download
GET http://127.0.0.1:18399/api/bounty/fixed/uploads/d73843e7-99d2-45c0-b6df-014251cd066f

HTML inline versus text attachment; browser execution not tested

요청: requests/14.http
응답: responses/14.http


자동 관찰은 후보이며 진단자가 실제 영향과 재현 결과를 확인해야 합니다. 인증값·쿼리값은 가려져 있으므로 재현 시 로컬 원본으로 보완하세요.
