package lab.enterprise;
import static lab.enterprise.CommunityAccessPolicy.Permission.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.server.ResponseStatusException;
import jakarta.servlet.http.*;
import java.util.*;import java.io.*;import java.nio.charset.StandardCharsets;

@RestController
public class CommunityController {
 private final JdbcTemplate db;
 private final CommunityAccessPolicy policy;
 public CommunityController(LabController legacy,JdbcTemplate db,CommunityAccessPolicy policy){this.db=db;this.policy=policy;
  ensure("community_posts","CREATE TABLE community_posts (id INTEGER PRIMARY KEY, owner_id INTEGER, category VARCHAR(30), visibility VARCHAR(20), title VARCHAR(200), body VARCHAR(4000))");
  ensure("community_comments","CREATE TABLE community_comments (id VARCHAR(50) PRIMARY KEY, post_id INTEGER, owner_id INTEGER, body VARCHAR(2000))");
  ensure("community_messages","CREATE TABLE community_messages (id INTEGER PRIMARY KEY, sender_id INTEGER, receiver_id INTEGER, body VARCHAR(2000))");
  ensure("community_files","CREATE TABLE community_files (id VARCHAR(50) PRIMARY KEY, post_id INTEGER, owner_id INTEGER, filename VARCHAR(150), mime VARCHAR(100), data BLOB)");
  if(db.queryForObject("SELECT COUNT(*) FROM lab_users WHERE id=4",Integer.class)==0)db.update("INSERT INTO lab_users VALUES (?,?,?,?,?)",4,"moderator",LabController.hash("LabOnly!2026"),"MODERATOR","moderator@lab.invalid");
  if(db.queryForObject("SELECT COUNT(*) FROM community_posts",Integer.class)==0)seed();
 }
 private void ensure(String table,String ddl){try{db.queryForObject("SELECT COUNT(*) FROM "+table,Integer.class);}catch(org.springframework.jdbc.BadSqlGrammarException e){int c=e.getSQLException().getErrorCode();if(c!=942&&c!=42102&&c!=42104)throw e;db.execute(ddl);}}
 private void seed(){
  db.update("INSERT INTO community_posts VALUES (101,1,'general','PUBLIC','처음 오신 분들을 위한 커뮤니티 안내','개발과 보안 이야기를 나누는 LOOP에 오신 것을 환영합니다. 서로의 경험과 질문을 공유해 주세요.')");
  db.update("INSERT INTO community_posts VALUES (102,2,'general','PRIVATE','Bob의 비공개 프로젝트 메모','BOB_PRIVATE_NOTE: 비공개 프로젝트 회의 기록입니다. 작성자와 전체 관리자만 읽을 수 있습니다.')");
  db.update("INSERT INTO community_posts VALUES (103,1,'questions','MEMBERS','Burp Proxy 설정을 같이 공부해요','회원 전용 게시판입니다. 로그인한 회원끼리 테스트 경험을 공유합니다.')");
  db.update("INSERT INTO community_posts VALUES (104,1,'security','PRIVATE','Alice의 비공개 진단 기록','ALICE_PRIVATE_NOTE: 개인 진단 기록. 다른 회원과 게시판 관리자에게 공개하지 않습니다.')");
  db.update("INSERT INTO community_posts VALUES (105,3,'security','PUBLIC','보안 게시판 운영 원칙','moderator는 공개/회원 전용 security 게시판을 관리합니다. 개인 쪽지나 비공개 글을 읽을 권한은 없습니다.')");
  db.update("INSERT INTO community_messages VALUES (201,1,3,'ALICE_TO_ADMIN_PRIVATE_MESSAGE: 가입 문의입니다.')");
  db.update("INSERT INTO community_messages VALUES (202,2,3,'BOB_TO_ADMIN_PRIVATE_MESSAGE: 비공개 쪽지입니다.')");
  db.update("INSERT INTO community_files VALUES (?,?,?,?,?,?)","bob-private-file",102,2,"project-notes.txt","text/plain","BOB_PRIVATE_ATTACHMENT: project notes".getBytes(StandardCharsets.UTF_8));
 }
 private static void fail(HttpStatus s,String m){throw new ResponseStatusException(s,m);}
 private static boolean secure(String mode){if(!mode.equals("vuln")&&!mode.equals("fixed"))fail(HttpStatus.NOT_FOUND,"모드 없음");return mode.equals("fixed");}
 private int who(HttpServletRequest r){return policy.current(r).id();}
 private int login(HttpServletRequest r){return policy.require(r,MEMBER).id();}
 private void csrf(HttpServletRequest r){policy.csrf(r);}
 private String role(int id){return policy.role(id);}
 private boolean read(Map<String,Object> post,int id){return policy.readPost(post,id);}
 private boolean write(Map<String,Object> post,int id){return policy.managePost(post,id);}
 private Map<String,Object> post(int id){var rows=db.queryForList("SELECT p.*,u.username FROM community_posts p JOIN lab_users u ON u.id=p.owner_id WHERE p.id=?",id);if(rows.isEmpty())fail(HttpStatus.NOT_FOUND,"게시글 없음");return rows.get(0);}
 private Map<String,Object> visible(String mode,int id,HttpServletRequest r){boolean f=secure(mode);var p=post(id);int u=who(r);if(f&&!read(p,u))fail(HttpStatus.NOT_FOUND,"게시글 없음");if(!f&&!p.get("VISIBILITY").equals("PUBLIC"))login(r);return p;}
 @GetMapping(value="/",produces="text/html;charset=UTF-8") public String home()throws IOException{try(var in=getClass().getResourceAsStream("/static/community.html")){return new String(in.readAllBytes(),StandardCharsets.UTF_8);}}
 @GetMapping(value={"/login","/login/"},produces="text/html;charset=UTF-8") public ResponseEntity<String> loginPage()throws IOException{try(var in=getClass().getResourceAsStream("/static/login.html")){return ResponseEntity.ok().header("Cache-Control","no-store").body(new String(in.readAllBytes(),StandardCharsets.UTF_8));}}
 @AccessRule(PUBLIC)
 @GetMapping("/api/community/{mode}/posts") public List<Map<String,Object>> posts(@PathVariable("mode")String m,@RequestParam(name="lab_hidden",required=false)String hidden,@RequestHeader(name="X-Lab-Board",required=false)String header,@CookieValue(name="loop_hint",required=false)String cookie,HttpServletRequest r){boolean f=secure(m);int u=who(r);return db.queryForList("SELECT p.*,u.username FROM community_posts p JOIN lab_users u ON u.id=p.owner_id ORDER BY p.id DESC").stream().filter(p->read(p,u)).map(p->{var out=new LinkedHashMap<>(p);out.remove("BODY");if(!f){if(hidden!=null)out.put("debugQuery","LOOP_QUERY="+hidden);if(header!=null)out.put("debugHeader","LOOP_HEADER="+header);if(cookie!=null)out.put("debugCookie","LOOP_COOKIE="+cookie);}return (Map<String,Object>)out;}).toList();}
 @AccessRule(PUBLIC)
 @GetMapping("/api/community/{mode}/people") public List<Map<String,Object>> people(@PathVariable("mode")String m){secure(m);return db.queryForList("SELECT id,username,role FROM lab_users ORDER BY id");}
 @AccessRule(PUBLIC)
 @PostMapping("/api/community/register") public synchronized Map<String,Object> register(@RequestParam("username")String name,@RequestParam("password")String password,@RequestParam("email")String email){if(name.length()>40||password.length()>120||email.length()>140)fail(HttpStatus.BAD_REQUEST,"회원 정보 길이 확인");if(name.isBlank()||password.isBlank()||email.isBlank())fail(HttpStatus.BAD_REQUEST,"회원 정보를 입력하세요");if(db.queryForObject("SELECT COUNT(*) FROM lab_users WHERE username=?",Integer.class,name)>0)fail(HttpStatus.CONFLICT,"이미 사용 중인 닉네임입니다");if(!name.matches("[A-Za-z0-9_.-]{3,40}")||password.length()<10||!email.matches("[A-Za-z0-9._+-]{1,80}@[A-Za-z0-9.-]{1,60}"))fail(HttpStatus.BAD_REQUEST,"닉네임·비밀번호·이메일 형식을 확인하세요");int id=db.queryForObject("SELECT COALESCE(MAX(id),4) FROM lab_users",Integer.class)+1;db.update("INSERT INTO lab_users VALUES (?,?,?,?,?)",id,name,LabController.hash(password),"USER",email);return Map.of("id",id,"username",name,"role","USER","trainingOnly",true);}
 @AccessRule(PUBLIC)
 @GetMapping("/api/community/{mode}/posts/{id}") public Map<String,Object> detail(@PathVariable("mode")String m,@PathVariable("id")int id,HttpServletRequest r){var p=new LinkedHashMap<>(visible(m,id,r));p.put("capabilities",Map.of("edit",who(r)!=0&&write(p,who(r)),"delete",who(r)!=0&&write(p,who(r)),"comment",policy.has(who(r),COMMENT_WRITE),"report",policy.has(who(r),REPORT_CREATE)));p.put("comments",db.queryForList("SELECT c.*,u.username FROM community_comments c JOIN lab_users u ON u.id=c.owner_id WHERE post_id=? ORDER BY c.id",id).stream().map(c->{c.put("canManage",policy.ownOrManage(who(r),c.get("OWNER_ID"),CONTENT_MANAGE));return c;}).toList());p.put("files",db.queryForList("SELECT id,filename,mime FROM community_files WHERE post_id=?",id));return p;}
 private static void validate(String title,String body,String visibility,String category){if(title.isBlank()||title.length()>200||body.length()>4000||!List.of("PUBLIC","MEMBERS","PRIVATE").contains(visibility)||!List.of("general","security","questions").contains(category))fail(HttpStatus.BAD_REQUEST,"제목·본문·공개 범위·게시판 확인");}
 @AccessRule(POST_WRITE)
 @PostMapping("/api/community/{mode}/posts") public synchronized Map<String,Object> create(@PathVariable("mode")String m,@RequestParam("title")String title,@RequestParam("body")String body,@RequestParam("visibility")String visibility,@RequestParam("category")String category,HttpServletRequest r){int u=login(r);if(secure(m))csrf(r);validate(title,body,visibility,category);int id=db.queryForObject("SELECT COALESCE(MAX(id),100) FROM community_posts",Integer.class)+1;db.update("INSERT INTO community_posts VALUES (?,?,?,?,?,?)",id,u,category,visibility,title,body);return Map.of("id",id);}
 @AccessRule(POST_WRITE)
 @PostMapping("/api/community/{mode}/posts/{id}/edit") public Map<String,Object> edit(@PathVariable("mode")String m,@PathVariable("id")int id,@RequestParam("title")String title,@RequestParam("body")String body,@RequestParam("visibility")String visibility,@RequestParam("category")String category,HttpServletRequest r){int u=login(r);var p=post(id);if(secure(m)){csrf(r);if(!write(p,u))fail(HttpStatus.FORBIDDEN,"작성자 또는 게시판 관리 권한 필요");if(role(u).equals("MODERATOR")&&((Number)p.get("OWNER_ID")).intValue()!=u&&(!category.equals("security")||visibility.equals("PRIVATE")))fail(HttpStatus.FORBIDDEN,"게시판 관리 범위 변경 불가");}validate(title,body,visibility,category);db.update("UPDATE community_posts SET title=?,body=?,visibility=?,category=? WHERE id=?",title,body,visibility,category,id);return Map.of("updated",id);}
 @AccessRule(POST_WRITE)
 @PostMapping("/api/community/{mode}/posts/{id}/delete") public Map<String,Object> delete(@PathVariable("mode")String m,@PathVariable("id")int id,HttpServletRequest r){int u=login(r);var p=post(id);if(secure(m)){csrf(r);if(!write(p,u))fail(HttpStatus.FORBIDDEN,"삭제 권한 없음");}db.update("DELETE FROM community_comments WHERE post_id=?",id);db.update("DELETE FROM community_files WHERE post_id=?",id);db.update("DELETE FROM community_posts WHERE id=?",id);return Map.of("deleted",id);}
 @AccessRule(COMMENT_WRITE)
 @PostMapping("/api/community/{mode}/posts/{id}/comments") public Map<String,Object> comment(@PathVariable("mode")String m,@PathVariable("id")int id,@RequestParam("body")String body,HttpServletRequest r){int u=login(r);visible(m,id,r);if(secure(m))csrf(r);if(body.isBlank()||body.length()>2000)fail(HttpStatus.BAD_REQUEST,"댓글 길이 확인");String key=UUID.randomUUID().toString();db.update("INSERT INTO community_comments VALUES (?,?,?,?)",key,id,u,body);return Map.of("id",key);}
 @AccessRule(PUBLIC)
 @GetMapping("/api/community/{mode}/search") public List<Map<String,Object>> search(@PathVariable("mode")String m,@RequestParam(name="q",defaultValue="")String q,HttpServletRequest r){boolean f=secure(m);if(q.length()>100)fail(HttpStatus.BAD_REQUEST,"검색어 길이 확인");List<Map<String,Object>> rows=f?db.queryForList("SELECT p.*,u.username FROM community_posts p JOIN lab_users u ON u.id=p.owner_id WHERE p.title LIKE ?","%"+q+"%"):db.queryForList("SELECT p.*,u.username FROM community_posts p JOIN lab_users u ON u.id=p.owner_id WHERE p.title LIKE '%"+q+"%'");return f?rows.stream().filter(p->read(p,who(r))).toList():rows;}
 @AccessRule(COMMENT_WRITE)
 @PostMapping("/api/community/{mode}/comments/{id}/edit") public Map<String,Object> commentEdit(@PathVariable String mode,@PathVariable String id,@RequestParam String body,HttpServletRequest r){int user=login(r);commentOwner(mode,id,user,r);if(body.isBlank()||body.length()>2000)fail(HttpStatus.BAD_REQUEST,"댓글 길이 확인");db.update("UPDATE community_comments SET body=? WHERE id=?",body,id);return Map.of("id",id);}
 @AccessRule(COMMENT_WRITE)
 @PostMapping("/api/community/{mode}/comments/{id}/delete") public Map<String,Object> commentDelete(@PathVariable String mode,@PathVariable String id,HttpServletRequest r){int user=login(r);commentOwner(mode,id,user,r);db.update("DELETE FROM community_comments WHERE id=?",id);return Map.of("deleted",id);}
 private void commentOwner(String mode,String id,int user,HttpServletRequest r){boolean f=secure(mode);var rows=db.queryForList("SELECT owner_id FROM community_comments WHERE id=?",id);if(rows.isEmpty())fail(HttpStatus.NOT_FOUND,"댓글 없음");if(f){csrf(r);if(!policy.ownOrManage(user,rows.get(0).get("OWNER_ID"),CONTENT_MANAGE))fail(HttpStatus.FORBIDDEN,"댓글 관리 권한 없음");}}
 @AccessRule(POST_WRITE)
 @PostMapping("/api/community/{mode}/posts/{id}/files") public Map<String,Object> upload(@PathVariable("mode")String m,@PathVariable("id")int id,@RequestParam("name")String name,HttpServletRequest r)throws IOException{int u=login(r);var p=post(id);boolean f=secure(m);if(f){csrf(r);if(!write(p,u))fail(HttpStatus.FORBIDDEN,"첨부 권한 없음");}if(name.isBlank()||name.length()>150)fail(HttpStatus.BAD_REQUEST,"파일명 확인");byte[] data=r.getInputStream().readNBytes(1048577);if(data.length==0||data.length>1048576)fail(HttpStatus.BAD_REQUEST,"파일 크기 1B~1MiB");String mime=Objects.requireNonNullElse(r.getContentType(),"application/octet-stream");if(f){if(!name.toLowerCase(Locale.ROOT).endsWith(".txt"))fail(HttpStatus.UNSUPPORTED_MEDIA_TYPE,"수정 실습은 다운로드 전용 TXT만 허용");mime="text/plain;charset=UTF-8";}String key=UUID.randomUUID().toString();db.update("INSERT INTO community_files VALUES (?,?,?,?,?,?)",key,id,u,name,mime,data);return Map.of("id",key,"url","/api/community/"+m+"/files/"+key);}
 @AccessRule(PUBLIC)
 @GetMapping("/api/community/{mode}/files/{id}") public ResponseEntity<byte[]> file(@PathVariable("mode")String m,@PathVariable("id")String id,HttpServletRequest r){boolean f=secure(m);var rows=db.queryForList("SELECT * FROM community_files WHERE id=?",id);if(rows.isEmpty())fail(HttpStatus.NOT_FOUND,"첨부파일 없음");var row=rows.get(0);if(f&&!read(post(((Number)row.get("POST_ID")).intValue()),who(r)))fail(HttpStatus.NOT_FOUND,"첨부파일 없음");byte[] data=db.queryForObject("SELECT data FROM community_files WHERE id=?",byte[].class,id);return ResponseEntity.ok().header("Content-Type",f?"application/octet-stream":(String)row.get("MIME")).header("Content-Disposition",f?"attachment; filename=\"community-file.txt\"":"inline").header("X-Content-Type-Options","nosniff").body(data);}
 @AccessRule(MESSAGE_USE)
 @GetMapping("/api/community/{mode}/messages") public List<Map<String,Object>> messages(@PathVariable("mode")String m,HttpServletRequest r){secure(m);int u=login(r);return db.queryForList("SELECT * FROM community_messages WHERE sender_id=? OR receiver_id=? ORDER BY id DESC",u,u);}
 @AccessRule(MESSAGE_USE)
 @GetMapping("/api/community/{mode}/messages/{id}") public Map<String,Object> message(@PathVariable("mode")String m,@PathVariable("id")int id,HttpServletRequest r){int u=login(r);boolean f=secure(m);var rows=db.queryForList("SELECT * FROM community_messages WHERE id=?",id);if(rows.isEmpty())fail(HttpStatus.NOT_FOUND,"쪽지 없음");var row=rows.get(0);if(f&&((Number)row.get("SENDER_ID")).intValue()!=u&&((Number)row.get("RECEIVER_ID")).intValue()!=u)fail(HttpStatus.NOT_FOUND,"쪽지 없음");return row;}
 @AccessRule(MESSAGE_USE)
 @PostMapping("/api/community/{mode}/messages") public synchronized Map<String,Object> send(@PathVariable("mode")String m,@RequestParam("receiver")int receiver,@RequestParam("body")String body,HttpServletRequest r){int u=login(r);if(secure(m))csrf(r);if(body.isBlank()||body.length()>2000||db.queryForObject("SELECT COUNT(*) FROM lab_users WHERE id=?",Integer.class,receiver)==0)fail(HttpStatus.BAD_REQUEST,"수신자·본문 확인");int id=db.queryForObject("SELECT COALESCE(MAX(id),200) FROM community_messages",Integer.class)+1;db.update("INSERT INTO community_messages VALUES (?,?,?,?)",id,u,receiver,body);return Map.of("id",id);}
 @AccessRule(USER_MANAGE)
 @GetMapping("/api/community/{mode}/admin/users") public List<Map<String,Object>> admin(@PathVariable("mode")String m,@RequestParam(name="role",defaultValue="USER")String supplied,HttpServletRequest r){int u=login(r);if(secure(m))policy.require(r,USER_MANAGE);else if(!supplied.equals("ADMIN"))fail(HttpStatus.FORBIDDEN,"전체 관리자 필요");return db.queryForList("SELECT id,username,role,email FROM lab_users ORDER BY id");}
 @AccessRule(LAB_RESET)
 @PostMapping("/api/community/reset") public synchronized Map<String,Object> reset(HttpServletRequest r){csrf(r);policy.require(r,LAB_RESET);for(String table:List.of("community_comments","community_messages","community_files","community_posts"))db.update("DELETE FROM "+table);seed();return Map.of("reset",true);}
 @ExceptionHandler(ResponseStatusException.class) public ResponseEntity<Map<String,Object>> error(ResponseStatusException e){return ResponseEntity.status(e.getStatusCode()).body(Map.of("error",Objects.requireNonNullElse(e.getReason(),"오류")));}
 @ExceptionHandler(org.springframework.dao.DataAccessException.class) public ResponseEntity<Map<String,Object>> dbError(Exception e,HttpServletRequest r){return ResponseEntity.status(500).body(Map.of("error",r.getRequestURI().contains("/vuln/")?e.toString():"처리 오류"));}
}
