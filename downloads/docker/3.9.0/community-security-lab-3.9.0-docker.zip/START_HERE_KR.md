# 커뮤니티 실습 Docker 패키지 3.9.0

ZIP을 한 폴더에 풀고 Docker Desktop 또는 Docker Engine + Compose v2를 실행하세요.
최초 빌드에는 이미지와 Maven 의존성 다운로드를 위한 인터넷 연결이 필요합니다.

Windows PowerShell: `./start.ps1`
Linux/macOS: `sh start.sh`
공통: `docker compose up -d --build --wait --wait-timeout 900`

접속: http://127.0.0.1:8088
상태 확인: `docker compose ps`
로그: `docker compose logs --tail 100`
종료: `docker compose down` (DB 볼륨 보존)

이 패키지는 현재 소스를 Docker 안에서 빌드합니다. 사전 빌드 이미지/오프라인 설치 파일이 아닙니다.
Oracle 시작에 시간이 필요합니다. 포트 8088, 8443, 8091, 8092 충돌을 먼저 확인하세요.
실습용 자격정보를 포함한 로컬 학습 사이트입니다. 모든 공개 포트는 127.0.0.1로 제한합니다.
현재 배포의 실제 Docker/Oracle/Nginx 기동 검증은 미실행입니다.
새 모의 버그바운티 실습: http://127.0.0.1:8088/bounty-lab
자세한 테스트 절차는 README_KR.md 및 DIAGNOSTICS_3.4_KR.md를 확인하세요.
