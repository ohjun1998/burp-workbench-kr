package kr.workbench;

import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.*;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.util.*;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public final class EnvironmentPanel extends JPanel implements AutoCloseable {
  private final TargetWindow targetSettings;
  private final JLabel targetSummary = new JLabel("대상 · 트래픽에서 선택하세요");
  final EnvironmentCatalog catalog = new EnvironmentCatalog();
  final JComboBox<String> origins = new JComboBox<>();
  final JTextField prefix = new JTextField("", 14);
  final JCheckBox compareMissing = new JCheckBox("없는 경로 응답과 비교", true),
      unverifiedOnly = new JCheckBox("일괄 검증은 미검증 후보만", true);
  final JCheckBox repeatMissing = new JCheckBox("기준 응답 2회 안정성 확인", true);
  final JTextField volatileFields = new JTextField(30);
  final TargetWindow candidateSettings =
      new TargetWindow(this, "환경 탐색 · 후보 설정", this::settingsContent);
  final JCheckBox common = new JCheckBox("공통 후보 포함", true);
  final JComboBox<Integer> limit = new JComboBox<>(new Integer[] {30, 100, 300});
  final DefaultTableModel tech = model("분류", "탐지 환경", "근거 수준", "관찰 근거"),
      paths = model("URL", "추천 근거", "진단 항목", "상태");
  final JTable
      pathTable =
          new JTable(paths) {
            public String getToolTipText(java.awt.event.MouseEvent e) {
              int view = rowAtPoint(e.getPoint());
              if (view < 0) return null;
              int row = convertRowIndexToModel(view);
              if (row >= candidates.size()) return null;
              var c = candidates.get(row);
              return c.source()
                  + " · "
                  + c.condition()
                  + " · "
                  + WorkbenchScope.reason(api, c.url());
            }
          },
      technologies = new JTable(tech);
  String category;
  boolean refreshing;
  final JLabel selection = new JLabel("전체 환경");
  final JCheckBox formatted = new JCheckBox("요청·응답 정렬", true);
  List<EnvironmentCatalog.Candidate> candidates = List.of();
  final JLabel status = new JLabel("SCOPE 내 응답 분석 · GET 확인 시 후보 설정의 계정으로 검증합니다.");
  final JComboBox<String> account =
      new JComboBox<>(new String[] {"비로그인", "비교 계정 1", "비교 계정 2", "비교 계정 3"});

  interface SessionProvider {
    Map<String, String> headers(int slot, String url);
  }

  SessionProvider sessions =
      (slot, url) -> {
        throw new IllegalArgumentException("권한 비교에서 계정을 지정하세요.");
      };
  final MontoyaApi api;
  final JTextArea requestView = message(), responseView = message();
  final JButton start = new JButton("후보 목록 GET 확인"),
      single = new JButton("선택 경로 GET 확인"),
      stop = new JButton("중지");
  final LinkedHashMap<String, Packet> packets = new LinkedHashMap<>();
  final AtomicBoolean stopping = new AtomicBoolean(), closed = new AtomicBoolean();
  SwingWorker<Void, Packet> job;

  record Packet(String url, String request, String response, String state, String decoded) {
    Packet(String url, String request, String response, String state) {
      this(url, request, response, state, response);
    }
  }

  static DefaultTableModel model(String... c) {
    return new DefaultTableModel(c, 0) {
      public boolean isCellEditable(int r, int col) {
        return false;
      }
    };
  }

  static JTextArea message() {
    JTextArea a = new JTextArea();
    a.setEditable(false);
    return a;
  }

  public EnvironmentPanel(MontoyaApi api) {
    super(new BorderLayout(8, 8));
    this.api = api;
    targetSettings =
        new TargetWindow(
            this,
            "서버·경로 탐색 · 대상 설정",
            () ->
                TargetWindow.options(
                    TargetWindow.scopes(
                        api,
                        url -> {
                          String origin = EnvironmentCatalog.origin(java.net.URI.create(url));
                          boolean observed = false;
                          for (int i = 0; i < origins.getItemCount(); i++)
                            if (origin.equals(origins.getItemAt(i))) observed = true;
                          if (observed) origins.setSelectedItem(origin);
                          else status.setText("등록된 대상의 응답을 요청·응답 목록에서 먼저 관찰하세요.");
                        }),
                    WorkbenchUi.row(new JLabel("관찰된 대상"), origins),
                    new JLabel("SCOPE 내 관찰된 응답을 기준으로 환경 후보를 구성합니다.")));
    setName("wb.environment");
    setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
    limit.setSelectedItem(100);
    origins.setPreferredSize(new Dimension(360, 30));
    JButton send = new JButton("선택 URL → 비로그인 GET Repeater"),
        copy = new JButton("URL 목록 복사"),
        clear = new JButton("분석 초기화");
    stop.setEnabled(false);
    JButton settings = new JButton("후보 설정"), more = new JButton("더보기"), all = new JButton("전체 환경");
    JPanel toolbar = new JPanel();
    toolbar.setLayout(new BoxLayout(toolbar, BoxLayout.Y_AXIS));
    toolbar.add(WorkbenchUi.row(targetSummary, targetSettings.button(), all));
    toolbar.add(WorkbenchUi.row(single, start, stop, send, settings, more));
    WorkbenchUi.primary(single);
    WorkbenchUi.primary(start);
    add(
        WorkbenchUi.header(
            FeatureGuide.title("environment"), "서버 환경 관찰 → 경로 후보 선택 → GET 응답 확인", toolbar),
        BorderLayout.NORTH);
    settings.addActionListener(
        e -> {
          if (job == null) candidateSettings.open();
        });
    JPopupMenu menu = new JPopupMenu();
    JMenuItem copyItem = new JMenuItem("URL 목록 복사"), clearItem = new JMenuItem("분석 초기화");
    menu.add(copyItem);
    menu.add(clearItem);
    more.addActionListener(e -> menu.show(more, 0, more.getHeight()));
    technologies.setAutoCreateRowSorter(true);
    technologies.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    technologies.setName("wb.environment.technologies");
    pathTable.setAutoCreateRowSorter(true);
    pathTable.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
    technologies.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
    int[] techWidths = {120, 180, 130, 350};
    for (int i = 0; i < 4; i++)
      technologies.getColumnModel().getColumn(i).setPreferredWidth(techWidths[i]);
    pathTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    pathTable.setName("wb.environment.paths");
    technologies
        .getSelectionModel()
        .addListSelectionListener(
            e -> {
              if (refreshing || e.getValueIsAdjusting()) return;
              int row = technologies.getSelectedRow();
              category =
                  row < 0
                      ? null
                      : tech.getValueAt(technologies.convertRowIndexToModel(row), 0).toString();
              refresh();
            });
    all.addActionListener(
        e -> {
          category = null;
          refresh();
        });
    JSplitPane lists =
        WorkbenchUi.split(
            JSplitPane.VERTICAL_SPLIT,
            WorkbenchUi.card("관찰한 환경", new JScrollPane(technologies)),
            WorkbenchUi.card("추천 경로 · 미검증 후보", candidatePane()),
            .35);
    lists.setName("wb.environment.lists");
    JSplitPane messages =
        WorkbenchUi.split(
            JSplitPane.VERTICAL_SPLIT,
            WorkbenchUi.card("요청 REQUEST", new JScrollPane(requestView)),
            WorkbenchUi.card("응답 RESPONSE", responsePane()),
            .5);
    messages.setName("wb.environment.messages");
    JSplitPane workspace = WorkbenchUi.split(JSplitPane.HORIZONTAL_SPLIT, lists, messages, .45);
    workspace.setName("wb.environment.workspace");
    add(workspace);
    add(status, BorderLayout.SOUTH);
    WorkbenchUi.style(this);
    WorkbenchUi.status(status);
    int[] widths = {440, 210, 300, 190};
    for (int i = 0; i < widths.length; i++)
      pathTable.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
    pathTable.moveColumn(3, 0);
    pathTable
        .getSelectionModel()
        .addListSelectionListener(
            e -> {
              if (!e.getValueIsAdjusting()) showSelected();
            });
    limit.addActionListener(e -> refresh());
    common.addActionListener(e -> refresh());
    origins.addActionListener(e -> refresh());
    prefix.addActionListener(e -> refresh());
    clearItem.addActionListener(e -> clearAnalysis());
    copyItem.addActionListener(
        e ->
            Toolkit.getDefaultToolkit()
                .getSystemClipboard()
                .setContents(
                    new StringSelection(
                        String.join(
                            "\n",
                            candidates.stream().map(EnvironmentCatalog.Candidate::url).toList())),
                    null));
    send.addActionListener(
        e -> {
          try {
            for (int view : pathTable.getSelectedRows()) {
              var c = candidates.get(pathTable.convertRowIndexToModel(view));
              HttpRequest r = HttpRequest.httpRequestFromUrl(c.url());
              if (!WorkbenchScope.contains(api, r))
                throw new IllegalArgumentException("Scope 밖 URL입니다: " + c.url());
              api.repeater().sendToRepeater(r, "환경 경로");
            }
            status.setText("Repeater에 준비했습니다. 전송은 Repeater에서 실행하세요.");
          } catch (Exception ex) {
            status.setText(ex.getMessage());
          }
        });
    single.addActionListener(e -> startOne());
    start.setToolTipText("목록의 후보를 실제 GET 요청으로 확인합니다. 없는 경로 기준 응답도 설정에 따라 추가 요청합니다.");
    single.setToolTipText("선택한 경로를 GET으로 확인합니다. 후보 하나에도 기준 응답을 위한 추가 요청이 생길 수 있습니다.");
    start.addActionListener(e -> start());
    formatted.addActionListener(e -> showSelected());
    stop.addActionListener(e -> stop());
    showSelected();
  }

  String selectedUrl() {
    int view = pathTable.getSelectedRow();
    if (view < 0) return null;
    int row = pathTable.convertRowIndexToModel(view);
    return row < candidates.size() ? candidates.get(row).url() : null;
  }

  static String preview(String raw) {
    return raw.length() > 65536 ? raw.substring(0, 65536) + "\n[미리보기 64K자 제한]" : raw;
  }

  void showSelected() {
    String url = selectedUrl();
    if (url == null) {
      requestView.setText("후보 경로를 선택하세요.");
      responseView.setText("검증 전 응답은 없습니다. 시작 버튼으로 검증하세요.");
      return;
    }
    Packet p = packets.get(url);
    if (p != null) {
      requestView.setText(formatted.isSelected() ? PacketFormat.pretty(p.request) : p.request);
      responseView.setText(formatted.isSelected() ? PacketFormat.pretty(p.decoded) : p.response);
    } else {
      try {
        requestView.setText(
            formatted.isSelected()
                ? PacketFormat.pretty(preview(HttpRequest.httpRequestFromUrl(url).toString()))
                : preview(HttpRequest.httpRequestFromUrl(url).toString()));
      } catch (Exception ex) {
        requestView.setText("GET " + url + "\n[검증 전 요청 미리보기]");
      }
      responseView.setText("미검증 · 시작 버튼으로 응답을 수집하세요.");
    }
    requestView.setCaretPosition(0);
    responseView.setCaretPosition(0);
  }

  final AtomicLong observationEpoch = new AtomicLong();

  record Observation(EnvironmentCatalog.Site site, long generation) {}

  void clearAnalysis() {
    if (job != null) {
      status.setText("중지 후 검증 종료를 기다려주세요.");
      return;
    }
    observationEpoch.incrementAndGet();
    catalog.sites.clear();
    packets.clear();
    origins.removeAllItems();
    refresh();
  }

  /** Decode and fingerprint without touching Swing or the UI-owned catalog. */
  Observation prepareObservation(HttpRequest request, HttpResponse response) {
    if (closed.get() || response == null || !WorkbenchScope.contains(api, request)) return null;
    long generation = observationEpoch.get();
    try {
      return new Observation(
          new EnvironmentCatalog()
              .observe(
                  request.url(),
                  responseHeaders(response),
                  decodedBody(PacketFormat.decodedResponse(response))),
          generation);
    } catch (Exception ignored) {
      return null;
    }
  }

  /** Merge a bounded metadata result on the EDT; no HTTP packets or bodies are retained. */
  void applyObservation(Observation observation) {
    if (closed.get() || observation == null || observation.generation() != observationEpoch.get())
      return;
    EnvironmentCatalog.Site observed = observation.site();
    EnvironmentCatalog.Site site = catalog.sites.get(observed.origin);
    if (site == null) {
      if (catalog.sites.size() >= 50)
        catalog.sites.remove(catalog.sites.keySet().iterator().next());
      site = new EnvironmentCatalog.Site(observed.origin);
      catalog.sites.put(site.origin, site);
    }
    for (var e : observed.detections.entrySet())
      if (site.detections.size() < 40 || site.detections.containsKey(e.getKey()))
        site.detections.put(e.getKey(), e.getValue());
    for (String path : observed.observed) if (site.observed.size() < 100) site.observed.add(path);
    for (String prefix : observed.prefixes) if (site.prefixes.size() < 8) site.prefixes.add(prefix);
    for (String path : observed.managementRoots)
      if (site.managementRoots.size() < 8) site.managementRoots.add(path);
    for (var e : observed.discovered.entrySet()) {
      var old = site.discovered.get(e.getKey());
      if ((old == null && site.discovered.size() < 500)
          || (old != null && old.score() < e.getValue().score())) {
        site.discovered.put(e.getKey(), e.getValue());
        site.associations.put(e.getKey(), observed.associations.get(e.getKey()));
      }
    }
    boolean found = false;
    for (int i = 0; i < origins.getItemCount(); i++)
      if (origins.getItemAt(i).equals(site.origin)) found = true;
    if (!found) {
      origins.addItem(site.origin);
      if (origins.getSelectedItem() == null) origins.setSelectedItem(site.origin);
    }
    refresh();
  }

  public void observe(HttpRequest request, HttpResponse response) {
    applyObservation(prepareObservation(request, response));
  }

  void refresh() {
    TargetWindow.show(
        targetSummary, Objects.toString(origins.getSelectedItem(), ""), "대상 · 트래픽에서 선택하세요");
    String selected = selectedUrl();
    refreshing = true;
    tech.setRowCount(0);
    paths.setRowCount(0);
    candidates = List.of();
    var site = catalog.sites.get(origins.getSelectedItem());
    if (site == null) {
      category = null;
      refreshing = false;
      selection.setText("전체 환경");
      showSelected();
      return;
    }
    for (var d : site.detections.values())
      tech.addRow(new Object[] {d.category(), d.name(), d.confidence(), d.evidence()});
    if (category != null
        && site.detections.values().stream().noneMatch(d -> d.category().equals(category)))
      category = null;
    for (int i = 0; i < tech.getRowCount(); i++)
      if (category != null && tech.getValueAt(i, 0).equals(category)) {
        int view = technologies.convertRowIndexToView(i);
        technologies.setRowSelectionInterval(view, view);
        break;
      }
    refreshing = false;
    selection.setText(category == null ? "전체 환경" : category + " 관련 후보");
    EnvironmentCatalog.Site filtered = site;
    if (category != null) {
      filtered = new EnvironmentCatalog.Site(site.origin);
      for (var entry : site.detections.entrySet())
        if (entry.getValue().category().equals(category))
          filtered.detections.put(entry.getKey(), entry.getValue());
      filtered.prefixes.addAll(site.prefixes);
      filtered.feedback.putAll(site.feedback);
      if (filtered.detections.containsKey("Spring Boot / Actuator"))
        filtered.managementRoots.addAll(site.managementRoots);
      for (var entry : site.discovered.entrySet())
        if (category.equals(site.associations.get(entry.getKey()))) {
          filtered.discovered.put(entry.getKey(), entry.getValue());
          filtered.associations.put(entry.getKey(), category);
        }
    }
    try {
      candidates =
          catalog.candidates(
              filtered,
              prefix.getText(),
              category == null && common.isSelected(),
              (Integer) limit.getSelectedItem());
      for (var c : candidates) {
        Packet p = packets.get(c.url());
        paths.addRow(
            new Object[] {
              c.url(),
              c.source(),
              c.purpose(),
              p == null ? (EnvironmentKnowledge.manualOnly(c.url()) ? "단일 검토" : "미검증") : p.state
            });
      }
      if (selected != null)
        for (int i = 0; i < candidates.size(); i++)
          if (candidates.get(i).url().equals(selected)) {
            int view = pathTable.convertRowIndexToView(i);
            pathTable.setRowSelectionInterval(view, view);
            break;
          }
      if (job == null)
        status.setText(
            "환경 "
                + site.detections.size()
                + " · 후보 URL "
                + candidates.size()
                + " · 응답 근거 우선 · 존재/취약점 미확인");
    } catch (Exception ex) {
      status.setText(ex.getMessage());
    }
    showSelected();
  }

  JPanel settingsContent() {
    JButton words = new JButton("경로 목록 가져오기");
    words.addActionListener(
        e -> {
          if (job == null) importWords();
        });
    JButton apply = new JButton("설정 확인");
    apply.addActionListener(
        e -> {
          try {
            AuthJudgement.rules(volatileFields.getText(), "", "");
            if (job == null) refresh();
          } catch (Exception ex) {
            status.setText(ex.getMessage());
          }
        });
    return TargetWindow.options(
        WorkbenchUi.row(new JLabel("검증 계정"), account, new JLabel("캡처된 세션 사용 · 갱신은 권한 비교에서 확인")),
        WorkbenchUi.row(new JLabel("앱 접두 경로"), prefix, new JLabel("최대 후보 수"), limit, common),
        WorkbenchUi.row(compareMissing, repeatMissing, unverifiedOnly),
        WorkbenchUi.row(new JLabel("JSON 동적 필드 제외"), volatileFields),
        new JLabel("예: $.requestId, $.meta.timestamp · 2회 기준 비교는 추가 GET 1건을 보냅니다."),
        WorkbenchUi.row(words, apply));
  }

  JPanel candidatePane() {
    JPanel p = new JPanel(new BorderLayout(0, 4));
    p.add(selection, BorderLayout.NORTH);
    p.add(new JScrollPane(pathTable));
    return p;
  }

  JPanel responsePane() {
    JPanel p = new JPanel(new BorderLayout(0, 4));
    p.add(WorkbenchUi.row(formatted, new JLabel("정렬은 표시 전용 · 원본 헤더 유지")), BorderLayout.NORTH);
    responseView.setLineWrap(true);
    responseView.setWrapStyleWord(false);
    p.add(new JScrollPane(responseView));
    return p;
  }

  void startOne() {
    String url = selectedUrl();
    if (url == null) {
      status.setText("검증할 후보 1건을 선택하세요.");
      return;
    }
    runUrls(List.of(url));
  }

  void start() {
    if (candidates.isEmpty()) {
      status.setText("검증할 후보가 없습니다.");
      return;
    }
    var urls =
        candidates.stream()
            .map(EnvironmentCatalog.Candidate::url)
            .distinct()
            .filter(u -> !EnvironmentKnowledge.manualOnly(u))
            .filter(u -> !unverifiedOnly.isSelected() || !packets.containsKey(u))
            .toList();
    if (urls.isEmpty()) {
      status.setText("일괄 검증할 미검증 후보가 없습니다. 단일 시작으로 다시 확인할 수 있습니다.");
      return;
    }
    runUrls(urls);
  }

  void runUrls(List<String> urls) {
    if (closed.get() || job != null) return;
    if (urls.isEmpty()) {
      status.setText("검증할 URL 없음");
      return;
    }
    try {
      for (String url : urls)
        if (!WorkbenchScope.contains(api, HttpRequest.httpRequestFromUrl(url)))
          throw new IllegalArgumentException("Scope 밖 후보가 있습니다. Scope를 확인하세요: " + url);
    } catch (Exception e) {
      status.setText(e.getMessage());
      return;
    }
    final Map<String, String> session;
    final String accountLabel = Objects.toString(account.getSelectedItem());
    try {
      session =
          account.getSelectedIndex() == 0
              ? Map.of()
              : Map.copyOf(sessions.headers(account.getSelectedIndex() - 1, urls.get(0)));
      if (account.getSelectedIndex() > 0)
        for (String url : urls) sessions.headers(account.getSelectedIndex() - 1, url);
    } catch (Exception ex) {
      status.setText("계정 검증 준비 실패 · " + ex.getMessage());
      return;
    }
    final Set<String> sessionNames = new HashSet<>(AuthComparePanel.DEFAULT_AUTH);
    sessionNames.addAll(AuthComparePanel.CSRF);
    sessionNames.addAll(session.keySet());
    final boolean compare = compareMissing.isSelected(), repeat = repeatMissing.isSelected();
    final Set<String> ignored;
    try {
      ignored = AuthJudgement.rules(volatileFields.getText(), "", "").ignored();
    } catch (Exception ex) {
      status.setText(ex.getMessage());
      return;
    }
    final Map<String, String> roots = new HashMap<>();
    for (String url : urls) roots.put(url, baselineRoot(url));
    stopping.set(false);
    start.setEnabled(false);
    single.setEnabled(false);
    technologies.setEnabled(false);
    stop.setEnabled(true);
    origins.setEnabled(false);
    prefix.setEnabled(false);
    limit.setEnabled(false);
    common.setEnabled(false);
    repeatMissing.setEnabled(false);
    volatileFields.setEnabled(false);
    compareMissing.setEnabled(false);
    account.setEnabled(false);
    status.setText(
        "검증 시작 · "
            + urls.size()
            + "개 · "
            + accountLabel
            + " GET"
            + (compare ? " · 없는 경로 기준 요청 포함" : ""));
    job =
        new SwingWorker<>() {
          int completed;
          String referenceNote = "";

          protected Void doInBackground() {
            Map<String, EnvironmentControls.Reference> missing = new HashMap<>();
            for (String url : urls) {
              if (stopping.get() || closed.get()) break;
              HttpRequest request = null;
              try {
                request =
                    Core.sessionRequest(HttpRequest.httpRequestFromUrl(url), session, sessionNames);
                if (compare && !missing.containsKey(roots.get(url))) {
                  String root = roots.get(url), issue = "기준 요청 실패";
                  EnvironmentControls.Sample first = null, second = null;
                  for (int probeIndex = 0; probeIndex < (repeat ? 2 : 1); probeIndex++) {
                    String reference = root + "/wb-missing-" + UUID.randomUUID();
                    var probe =
                        Core.sessionRequest(
                            HttpRequest.httpRequestFromUrl(reference), session, sessionNames);
                    if (!WorkbenchScope.contains(api, probe)) {
                      issue = "기준 요청 SCOPE 제외";
                      break;
                    }
                    if (stopping.get() || closed.get()) break;
                    try {
                      var result =
                          api.http()
                              .sendRequest(
                                  probe,
                                  RequestOptions.requestOptions()
                                      .withResponseTimeout(10000)
                                      .withRedirectionMode(RedirectionMode.NEVER));
                      var r = result == null ? null : result.response();
                      if (r == null) {
                        issue = "기준 응답 없음";
                        break;
                      }
                      if (r.statusCode() == 429) {
                        stopping.set(true);
                        referenceNote = "기준 HTTP 429 · 후속 요청 중단";
                        break;
                      }
                      var sample =
                          EnvironmentControls.sample(
                              r.statusCode(),
                              responseHeaders(r),
                              decodedBody(PacketFormat.decodedResponse(r)),
                              reference,
                              ignored);
                      if (probeIndex == 0) first = sample;
                      else second = sample;
                    } catch (Exception ex) {
                      issue = "기준 요청/디코딩 오류";
                      break;
                    }
                    if (probeIndex == 0 && repeat)
                      try {
                        Thread.sleep(200);
                      } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();
                        stopping.set(true);
                        break;
                      }
                  }
                  missing.put(root, EnvironmentControls.reference(first, second, repeat, issue));
                }
                if (stopping.get() || closed.get()) break;
                if (!WorkbenchScope.contains(api, request)) {
                  publish(
                      new Packet(
                          url, preview(request.toString()), "전송하지 않음 · Scope 제외", "Scope 제외"));
                  continue;
                }
                var rr =
                    api.http()
                        .sendRequest(
                            request,
                            RequestOptions.requestOptions()
                                .withResponseTimeout(10000)
                                .withRedirectionMode(RedirectionMode.NEVER));
                var response = rr == null ? null : rr.response();
                String headers = response == null ? "" : responseHeaders(response);
                String decoded = response == null ? "" : PacketFormat.decodedResponse(response);
                String note =
                    response == null
                        ? "응답 없음"
                        : EnvironmentControls.state(
                            response.statusCode(),
                            headers,
                            decodedBody(decoded),
                            url,
                            missing.get(roots.get(url)),
                            ignored);
                publish(
                    new Packet(
                        url,
                        preview(
                            (rr != null && rr.request() != null ? rr.request() : request)
                                .toString()),
                        response == null ? "응답 없음" : preview(response.toString()),
                        note,
                        response == null ? "응답 없음" : preview(decoded)));
                if (response != null && response.statusCode() == 429) stopping.set(true);
              } catch (Exception e) {
                publish(
                    new Packet(
                        url,
                        request == null ? "GET " + url : preview(request.toString()),
                        "요청 실패 · " + e.getClass().getSimpleName(),
                        "전송 오류"));
              }
              if (stopping.get() || closed.get()) break;
              try {
                Thread.sleep(200);
              } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
              }
            }
            return null;
          }

          protected void process(List<Packet> updates) {
            if (closed.get()) return;
            for (Packet p : updates) {
              if (packets.size() >= 300 && !packets.containsKey(p.url))
                packets.remove(packets.keySet().iterator().next());
              packets.put(p.url, p);
              java.util.regex.Matcher code =
                  java.util.regex.Pattern.compile("^HTTP (\\d{3})").matcher(p.state);
              if (code.find()) catalog.feedback(p.url, Integer.parseInt(code.group(1)), p.state);
              completed++;
              for (int i = 0; i < candidates.size(); i++)
                if (candidates.get(i).url().equals(p.url)) paths.setValueAt(p.state, i, 3);
            }
            showSelected();
            status.setText(
                "검증 "
                    + completed
                    + " / "
                    + urls.size()
                    + " · "
                    + (stopping.get() ? "중지 중" : "진행 중"));
          }

          protected void done() {
            job = null;
            if (closed.get()) return;
            start.setEnabled(true);
            single.setEnabled(true);
            technologies.setEnabled(true);
            stop.setEnabled(false);
            origins.setEnabled(true);
            prefix.setEnabled(true);
            limit.setEnabled(true);
            common.setEnabled(true);
            repeatMissing.setEnabled(true);
            volatileFields.setEnabled(true);
            compareMissing.setEnabled(true);
            account.setEnabled(true);
            status.setText(
                (stopping.get() ? "검증 중지" : "검증 완료")
                    + " · "
                    + completed
                    + " / "
                    + urls.size()
                    + " · 상태 코드는 검토 단서입니다.");
            if (catalog.sites.containsKey(origins.getSelectedItem())) refresh();
            status.setText(
                (stopping.get() ? "검증 중지" : "검증 완료")
                    + " · "
                    + completed
                    + " / "
                    + urls.size()
                    + " · 응답을 반영해 후보 순서 갱신"
                    + (referenceNote.isEmpty() ? "" : " · " + referenceNote));
            showSelected();
          }
        };
    job.execute();
  }

  static String responseHeaders(HttpResponse r) {
    return r.headers() == null
        ? ""
        : String.join("\n", r.headers().stream().map(h -> h.name() + ": " + h.value()).toList());
  }

  static String decodedBody(String packet) {
    int p = packet.indexOf("\r\n\r\n");
    if (p >= 0) return packet.substring(p + 4);
    p = packet.indexOf("\n\n");
    return p >= 0 ? packet.substring(p + 2) : packet;
  }

  String baselineRoot(String url) {
    java.net.URI uri = java.net.URI.create(url);
    String origin = EnvironmentCatalog.origin(uri),
        app = EnvironmentCatalog.prefix(prefix.getText());
    if (!app.isEmpty() && !uri.getPath().equals(app) && !uri.getPath().startsWith(app + "/"))
      app = "";
    var site = catalog.sites.get(origin);
    if (app.isEmpty() && site != null)
      for (String root : site.prefixes)
        if ((uri.getPath().equals(root) || uri.getPath().startsWith(root + "/"))
            && root.length() > app.length()) app = root;
    return origin + app;
  }

  void importWords() {
    if (job != null) return;
    var site = catalog.sites.get(origins.getSelectedItem());
    if (site == null) {
      status.setText("관찰된 대상을 먼저 선택하세요.");
      return;
    }
    JFileChooser chooser = new JFileChooser();
    if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
    try {
      var file = chooser.getSelectedFile().toPath();
      if (java.nio.file.Files.size(file) > 1024 * 1024)
        throw new IllegalArgumentException("목록 파일은 1MiB 이하로 줄여주세요.");
      var result =
          EnvironmentDiscovery.importWords(
              site, java.nio.file.Files.readString(file), file.getFileName().toString());
      category = "사용자 목록";
      refresh();
      status.setText("가져옴 " + result.accepted() + "개 · 중복/형식/제한 제외 " + result.skipped() + "개");
    } catch (Exception e) {
      status.setText("목록 가져오기 실패 · " + e.getMessage());
    }
  }

  void stop() {
    stopping.set(true);
    status.setText("중지 중 · 이미 전송한 요청은 응답/10초 타임아웃 후 종료합니다.");
  }

  public void close() {
    targetSettings.close();
    candidateSettings.close();
    closed.set(true);
    stopping.set(true);
    packets.clear();
    catalog.sites.clear();
    origins.removeAllItems();
    refresh();
  }
}
