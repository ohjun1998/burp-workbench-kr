# Workbench Strix 1.1.0 · 대화 화면

최종 JAR의 production Swing 패널과 합성 세션 예시입니다. 실제 사용자 Burp·모델·대상 진단 성공이 아닙니다. 원본 PNG는 수정하지 않았습니다.
