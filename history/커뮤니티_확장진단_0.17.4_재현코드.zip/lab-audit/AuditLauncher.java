package kr.workbench;
public final class AuditLauncher {
 public static void main(String[] args){try{CommunityExtensionAudit.main(args);System.exit(0);}catch(Throwable e){e.printStackTrace();System.exit(1);}}
}
