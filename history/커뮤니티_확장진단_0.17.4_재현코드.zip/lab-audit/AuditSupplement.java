package kr.workbench;
import java.util.*;import java.nio.file.*;import com.fasterxml.jackson.databind.ObjectMapper;import kr.payloadrunner.Engine;
public final class AuditSupplement {
 public static void main(String[] args)throws Exception {
  ObjectMapper mapper=new ObjectMapper();Map<String,Object> audit=mapper.readValue(Path.of(args[0]).toFile(),Map.class),report=new LinkedHashMap<>();List<Object> syntax=new ArrayList<>();
  var samples=new LinkedHashMap<String,String>();samples.put("classic fetch","fetch('/api/probe',{method:'POST',body:{id:1}});");samples.put("async wrapper","async function call(){await fetch('/api/probe',{method:'POST'});}");samples.put("optional chaining","const x=user?.id;fetch('/api/probe',{method:'POST'});");samples.put("nullish coalescing","const x=user.id??1;fetch('/api/probe',{method:'POST'});");samples.put("object spread","const x={...options};fetch('/api/probe',{method:'POST'});");samples.put("ES module","export const f=()=>fetch('/api/probe',{method:'POST'});");
  for(var s:samples.entrySet()){var result=JsAnalysis.analyze(s.getValue(),"http://127.0.0.1:18099/assets/probe.js");syntax.add(Map.of("case",s.getKey(),"source",s.getValue(),"status",result.status(),"endpoints",result.endpoints()));}
  report.put("syntaxIsolation",syntax);
  var method=Engine.class.getDeclaredMethod("normalized",String.class,String.class);method.setAccessible(true);String original="[{\"TITLE\":\"Burp Proxy 설정을 같이 공부해요\"}]",truthPayload="Burp%' AND 1=1 -- ";String a=(String)method.invoke(null,original,"Burp"),b=(String)method.invoke(null,original,truthPayload);
  report.put("normalizationReproduction",Map.of("baselineAndTrueBody",original,"baselineValue","Burp","truePayload",truthPayload,"normalizedBaseline",a,"normalizedTrue",b,"incorrectMismatch",!a.equals(b)));
  if(a.equals(b))throw new AssertionError("normalization issue not reproduced");
  Map<?,?> controls=(Map<?,?>)audit.get("missingPathControls");
  String first=controls.get("firstBody").toString(),second=controls.get("secondBody").toString();
  String n1=first.replace("&#47;audit-missing-one","{path}"),n2=second.replace("&#47;audit-missing-two","{path}");
  Object signature1=((Map<?,?>)controls.get("first")).get("signature"),signature2=((Map<?,?>)controls.get("second")).get("signature");
  report.put("encodedPathReproduction",Map.of("onlyEncodedPathDiffers",n1.equals(n2),"currentSignaturesDiffer",!signature1.equals(signature2)));
  if(!n1.equals(n2))throw new AssertionError("unexpected other missing-path differences");
  var domains=JsMiner.analyze("const role=user.role;window.fetch('/api/probe');const r=JSON.parse('{}');", "http://127.0.0.1:18099/assets/probe.js").domains();report.put("domainNoise",domains);if(domains.stream().noneMatch(d->d.host().equals("user.role")))throw new AssertionError("domain noise not reproduced");
  var discovered=(List<Map<String,Object>>)audit.get("communityJsDiscoveries");report.put("incorrectLiteralDiscovery",discovered.stream().filter(d->d.get("url").toString().matches(".*18099/(posts/?|messages/?|files/?|admin/users|search).*" )).toList());
  Map<?,?> categories=(Map<?,?>)audit.get("pathCategories");if(!categories.get("privatePost").equals("기타"))throw new AssertionError("path ID categorization behavior changed");
  mapper.writerWithDefaultPrettyPrinter().writeValue(Path.of(args[1]).toFile(),report);
  System.out.println("Supplement: normalization, encoded path, domain noise, path-ID category and 6 syntax samples checked.");
 }
}
