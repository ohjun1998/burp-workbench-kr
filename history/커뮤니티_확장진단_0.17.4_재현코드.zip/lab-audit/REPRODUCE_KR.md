# 재현 코드 안내

대상은 첨부된 burp-development-workspace 레이아웃의 실습 사이트와 Workbench 0.17.4입니다. 이 코드는 실제 Burp GUI를 실행하지 않습니다. 서버는 127.0.0.1:18099에만 임시 바인딩하고 실행 스크립트의 finally에서 종료합니다. 모든 데이터는 실습용입니다.

원래 실행 환경: Python 3.13, JDK 24.0.2 (Java 17 대상으로 컴파일), Windows. 스크립트의 Java/Python 경로와 작업 경로는 재현 환경에 맞게 조정하세요.

1. 프로젝트를 work/source/burp-development-workspace에 준비합니다. 확장은 0.17.4 소스/JAR이어야 합니다.
2. 확장 build_all.py로 테스트 클래스를 준비합니다. 하네스는 WorkbenchTest/AuthRecordTest의 Montoya 어댑터를 재사용합니다.
3. prepare_lab_audit.py를 실행합니다. WAR 안의 라이브러리를 작업 폴더에 추출하고 Tomcat/annotation 런타임을 Maven Central에서 내려받아 checksum을 확인하며 실습 소스를 컴파일합니다.
4. community_tests.py로 사이트 기본 동작을 확인합니다. 준비 스크립트가 work/lab-audit/community_tests.py와 HTTP 클라이언트를 만듭니다.
5. run_lab_audit.py로 실제 JAR 연계 검사를 실행합니다. CommunityExtensionAudit.java/AuditLauncher.java는 work/lab-audit 안에 두세요.
6. run_audit_supplement.py로 HTTP 캡처 JS의 62개 회귀와 오프라인 원인 재현을 실행합니다.

상용/실제 서비스 대신 이 실습 소스만 대상으로 하는 테스트입니다. 운영 확장 코드를 수정하거나 새 릴리스 JAR을 생성하는 스크립트는 포함하지 않습니다. test PASS는 문제 현상 재현까지 확인했다는 뜻이며 모든 취약점 탐지 성공을 뜻하지 않습니다.
