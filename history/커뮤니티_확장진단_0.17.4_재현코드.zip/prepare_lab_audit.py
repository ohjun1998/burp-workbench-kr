from pathlib import Path
import zipfile,shutil,subprocess,os,urllib.request,hashlib,json
root=Path('work/source/burp-development-workspace/community-security-lab').resolve()
task=Path('work/lab-audit').resolve();deps=task/'.build-deps';classes=task/'.build'
deps.mkdir(parents=True,exist_ok=True);classes.mkdir(exist_ok=True)
with zipfile.ZipFile(root/'dist/ROOT.war') as z:
 for name in z.namelist():
  if name.startswith('WEB-INF/lib/') and name.endswith('.jar'):(deps/Path(name).name).write_bytes(z.read(name))
for artifact,version,group in [('tomcat-embed-core','10.1.60','org/apache/tomcat/embed'),('jakarta.annotation-api','2.1.1','jakarta/annotation')]:
 p=deps/f'{artifact}-{version}.jar'
 if not p.exists():
  url=f'https://repo.maven.apache.org/maven2/{group}/{artifact}/{version}/{p.name}'
  with urllib.request.urlopen(url,timeout=45) as r:p.write_bytes(r.read())
  with urllib.request.urlopen(url+'.sha1',timeout=30) as r:expected=r.read().decode().strip().split()[0]
  assert hashlib.sha1(p.read_bytes()).hexdigest()==expected
java=Path('C:/Program Files/Java/jdk-24/bin/java.exe');javac=java.with_name('javac.exe')
cp=os.pathsep.join(str(p) for p in deps.glob('*.jar'))
subprocess.run([str(javac),'--release','17','-parameters','-encoding','UTF-8','-cp',cp,'-d',str(classes)]+[str(p) for p in (root/'src/main/java').rglob('*.java')],check=True)
shutil.copytree(root/'src/main/resources',classes,dirs_exist_ok=True)
shutil.copyfile(root/'http_test_client.py',task/'http_test_client.py')
test=(root/'community_tests.py').read_text(encoding='utf-8').replace("['java','-cp',cp",f"[{str(java)!r},'-cp',cp")
(task/'community_tests.py').write_text(test,encoding='utf-8')
(task/'runtime-hashes.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in deps.glob('*.jar')},indent=2),encoding='utf-8')
print('Prepared lab source classes and dependencies in',task,flush=True)
