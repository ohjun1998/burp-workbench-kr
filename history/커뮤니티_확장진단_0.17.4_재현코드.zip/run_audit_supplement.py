from pathlib import Path
import subprocess,os,sys,json
sys.stdout.reconfigure(encoding='utf-8')
task=Path('work/lab-audit').resolve();root=Path('work/source/burp-development-workspace/burp-workbench-kr/burp-workbench').resolve();lab=Path('work/source/burp-development-workspace/community-security-lab').resolve()
java='C:/Program Files/Java/jdk-24/bin/java.exe';javac='C:/Program Files/Java/jdk-24/bin/javac.exe'
cp=os.pathsep.join([str(root/'dist/burp-workbench-kr-0.17.4.jar')]+[str(p) for p in (task/'.build-deps').glob('*.jar')]);classes=task/'audit-classes'
source=(lab/'validation/JsLabEngineTest.java').read_text(encoding='utf-8').replace('Workbench KR 0.15.0 JsAnalysis + JsMiner','Workbench KR 0.17.4 JsAnalysis + JsMiner (HTTP-captured lab fixtures)')
(task/'JsLabEngineTest.java').write_text(source,encoding='utf-8')
subprocess.run([javac,'--release','17','-encoding','UTF-8','-cp',cp,'-d',str(classes),str(task/'AuditSupplement.java'),str(task/'JsLabEngineTest.java')],check=True)
for cls,args in [('AuditSupplement',[str(task/'audit-results.json'),str(task/'supplement-results.json')]),('JsLabEngineTest',[str(task/'http-js-fixtures'),str(task/'js-engine-results.json')])]:
 r=subprocess.run([java,'-Djava.awt.headless=true','-cp',os.pathsep.join([str(classes),cp]),'kr.workbench.'+cls]+args,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=60)
 (task/(cls+'-log.txt')).write_text(r.stdout+r.stderr,encoding='utf-8');print(r.stdout+r.stderr)
 if r.returncode:raise SystemExit(r.returncode)
print(json.dumps(json.loads((task/'supplement-results.json').read_text(encoding='utf-8')),ensure_ascii=False,indent=2))
