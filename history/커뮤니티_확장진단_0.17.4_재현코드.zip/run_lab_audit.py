from pathlib import Path
import subprocess,os,time,json,urllib.request,sys
sys.stdout.reconfigure(encoding='utf-8')
task=Path('work/lab-audit').resolve();root=Path('work/source/burp-development-workspace/burp-workbench-kr/burp-workbench').resolve()
java='C:/Program Files/Java/jdk-24/bin/java.exe';javac='C:/Program Files/Java/jdk-24/bin/javac.exe'
deps=[str(p) for p in (task/'.build-deps').glob('*.jar')]
cp=os.pathsep.join([str(root/'dist/burp-workbench-kr-0.17.4.jar'),str(root/'deps/montoya-2026.jar'),str(root/'deps/legacy-api.jar'),str(root/'build/tests')]+deps)
classes=task/'audit-classes';classes.mkdir(exist_ok=True)
subprocess.run([javac,'--release','17','-encoding','UTF-8','-cp',cp,'-d',str(classes),str(task/'CommunityExtensionAudit.java'),str(task/'AuditLauncher.java')],check=True)
server=None
with (task/'server.log').open('w',encoding='utf-8') as log:
 try:
  server=subprocess.Popen([java,'-cp',os.pathsep.join([str(task/'.build')]+deps),'lab.enterprise.DevServer'],env=dict(os.environ,PORT='18099'),stdout=log,stderr=subprocess.STDOUT)
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
  for _ in range(100):
   try:
    with opener.open('http://127.0.0.1:18099/health',timeout=1) as r:
     if r.status==200:break
   except Exception:
    if server.poll() is not None:raise RuntimeError('server failed; see server.log')
    time.sleep(.2)
  else:raise RuntimeError('server readiness timeout')
  run=subprocess.run([java,'-Djava.awt.headless=true','-cp',os.pathsep.join([str(classes),cp]),'kr.workbench.AuditLauncher','18099',str(task/'audit-results.json')],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=240)
  text=run.stdout+run.stderr;(task/'audit-log.txt').write_text(text,encoding='utf-8');print(text,flush=True)
  if run.returncode:raise SystemExit(run.returncode)
 finally:
  if server is not None:
   server.terminate()
   try:server.wait(timeout=15)
   except subprocess.TimeoutExpired:server.kill();server.wait(timeout=5)
print('Temporary lab server stopped.',flush=True)
