# 게시글 계정 점검

## 영향 (진단자 작성)
owned training lab

## 재현 절차
Alice denial / Admin allowance / Bob baseline

## 1. 권한 비교 원본
GET http://127.0.0.1:18299/api/community/fixed/posts/102

완료

요청: requests/1.http
응답: responses/1.http

## 2. alice
GET http://127.0.0.1:18299/api/community/fixed/posts/102

기대 DENY · 404/410 존재·세션 재검토

요청: requests/2.http
응답: responses/2.http

## 3. admin
GET http://127.0.0.1:18299/api/community/fixed/posts/102

기대 ALLOW · 성공 응답 관측

요청: requests/3.http
응답: responses/3.http

## 4. bob
GET http://127.0.0.1:18299/api/community/fixed/posts/102

원본과 동일 인증 · 교차 인가 미검증

요청: requests/4.http
응답: responses/4.http


자동 관찰은 후보이며 진단자가 실제 영향과 재현 결과를 확인해야 합니다. 인증값·쿼리값은 가려져 있으므로 재현 시 로컬 원본으로 보완하세요.
