package kr.workbench;
import burp.api.montoya.*;import burp.api.montoya.core.*;import burp.api.montoya.http.handler.*;import burp.api.montoya.http.message.requests.*;import burp.api.montoya.internal.*;import burp.api.montoya.persistence.*;
import javax.swing.*;import java.util.*;import java.util.List;import java.util.concurrent.atomic.*;
public final class TrafficScopeTest extends WorkbenchTest {
 public static void main(String[] args)throws Exception{
  editRules();
  Map<String,String> saved=new HashMap<>();AtomicInteger globalMutations=new AtomicInteger();var data=proxy(PersistedObject.class,(p,m,a)->switch(m.getName()){case "getString"->saved.get((String)a[0]);case "setString"->{saved.put((String)a[0],(String)a[1]);yield null;}default->def(m);});var persistence=proxy(Persistence.class,(p,m,a)->m.getName().equals("extensionData")?data:def(m));MontoyaApi api=proxy(MontoyaApi.class,(p,m,a)->{if(m.getName().equals("persistence"))return persistence;if(m.getName().equals("scope"))return proxy(burp.api.montoya.scope.Scope.class,(pp,mm,aa)->{if(mm.getName().equals("includeInScope")||mm.getName().equals("excludeFromScope"))globalMutations.incrementAndGet();return def(mm);});return PayloadIntegrationTest.host(m.getReturnType());});
  HttpRequest outside=request("https://scope.test/api?id=secret","GET",false,List.of());WorkbenchScope scope=WorkbenchScope.install(api);check(!WorkbenchScope.contains(api,outside),"unconfigured scope respects Burp fallback");scope.add(outside.url(),false);check(WorkbenchScope.contains(api,outside)&&WorkbenchScope.contains(api,"https://scope.test/api/child?q=1"),"local URL registration authorizes exact path and descendants");check(!WorkbenchScope.contains(api,"https://scope.test/apievil")&&!WorkbenchScope.contains(api,"https://scope.test/other"),"path boundary prevents scope broadening");check(!WorkbenchScope.contains(api,"https://scope.test.evil/api")&&!WorkbenchScope.contains(api,"http://scope.test/api")&&!WorkbenchScope.contains(api,"https://scope.test:8443/api"),"host protocol and port enforced");check(!WorkbenchScope.contains(api,"https://scope.test/api/%2e%2e/admin")&&!WorkbenchScope.contains(api,"https://scope.test/api/x%2fy"),"encoded traversal and slash ambiguity excluded");check(!scope.save().contains("secret")&&scope.rules().get(0).url().equals("https://scope.test/api"),"stored scope excludes query secrets");scope.add("https://scope.test/api#fragment",false);check(scope.rules().size()==1,"scope registration deduplicates same URL");scope.add("https://scope.test/a",true);check(WorkbenchScope.contains(api,"https://scope.test/other")&&!WorkbenchScope.contains(api,"https://sub.scope.test/other"),"domain rule includes paths but never implicit subdomains");check(WorkbenchScope.legacy(api,"https://scope.test/api",false),"legacy payload runner shares traffic scope");WorkbenchScope.release(api);scope=WorkbenchScope.install(api);check(scope.rules().size()==2&&WorkbenchScope.contains(api,outside),"project scope restored after reload");for(var r:scope.rules())scope.remove(r);check(!WorkbenchScope.contains(api,request("https://scope.test/api","GET",true,List.of())),"deleting last local rule leaves no authorized targets");WorkbenchScope.release(api);saved.clear();
  ObjectFactoryLocator.FACTORY=proxy(MontoyaObjectFactory.class,(p,m,a)->def(m));WorkbenchExtension extension=new WorkbenchExtension();extension.initialize(api);seedTraffic(extension,outside,response(200,"{}"));seedTraffic(extension,request("https://other.test/a","GET",false,List.of()),response(200,"{}"));
  JTable traffic=(JTable)get(extension,"logTable");JPanel lists=(JPanel)get(extension,"scopeContent");JTabbedPane pages=(JTabbedPane)get(extension,"tabs");JTable rules=(JTable)get(extension,"scopeTable");
  AtomicReference<java.awt.Component> openedScope=new AtomicReference<>();
  extension.dialogOpener=(owner,title,content,modal,closed)->{check(title.contains("SCOPE")&&!modal,"primary scope list opens its actual modeless editor");openedScope.set(content);return null;};
  JPanel root=(JPanel)get(extension,"root");
  edt(()->{
   traffic.setRowSelectionInterval(0,0);
   ((JButton)UiLayoutTest.named(root,"wb.traffic.scope.list")).doClick(0);
   check(openedScope.get()==lists,"primary SCOPE button exposes the retained scope editor");
   ((JTextField)UiLayoutTest.named(openedScope.get(),"wb.traffic.scope.url")).setText(outside.url());
   ((JButton)UiLayoutTest.named(openedScope.get(),"wb.traffic.scope.add")).doClick(0);
   check(rules.getRowCount()==1&&rules.getValueAt(0,2).equals("https://scope.test/api"),"primary scope editor registers the URL path and removes query secrets");
   check(pages.getSelectedIndex()==0&&traffic.getSelectedRow()==0,"scope window preserves traffic page and selection");
   check(WorkbenchScope.contains(api,outside),"scope registration works without Burp Target Scope");
  });
  ActivityPanel activity=(ActivityPanel)get(extension,"activity");EnvironmentPanel env=(EnvironmentPanel)get(extension,"environments");
  // The removed context command used to backfill selected packets. The primary Simple
  // flow registers a scope, enables collection, and observes a subsequently admitted packet.
  edt(()->((JButton)UiLayoutTest.named(root,"wb.traffic.capture.mode")).doClick(0));
  var captured=response(200,"{}");registerTrafficPacket(outside,captured);
  var source=proxy(ToolSource.class,(p,m,a)->m.getName().equals("toolType")?ToolType.PROXY:def(m));
  var admittedRequest=proxy(HttpRequestToBeSent.class,(p,m,a)->switch(m.getName()){case "toolSource"->source;case "messageId"->43;case "annotations"->null;default->HttpRequest.class.getMethod(m.getName(),m.getParameterTypes()).invoke(outside,a);});
  var admittedResponse=proxy(HttpResponseReceived.class,(p,m,a)->switch(m.getName()){case "toolSource"->source;case "messageId"->43;case "initiatingRequest"->outside;case "annotations"->null;default->burp.api.montoya.http.message.responses.HttpResponse.class.getMethod(m.getName(),m.getParameterTypes()).invoke(captured,a);});
  extension.handleHttpRequestToBeSent(admittedRequest);extension.handleHttpResponseReceived(admittedResponse);
  CaptureObservations observations=(CaptureObservations)get(extension,"captureObservations");
  TrafficUsability0532Test.await(()->observations.pending()==0,"admitted scoped packet observations did not settle");
  ActivityReconTest.idle(activity);
  check(activity.tracker.views().stream().anyMatch(v->v.url().equals("https://scope.test/api")),"admitted scoped traffic enters coverage after primary scope registration");
  check(env.origins.getItemCount()==1,"admitted scoped traffic is available to environment discovery");
  edt(()->((JButton)UiLayoutTest.named(root,"wb.traffic.capture.mode")).doClick(0));
  var tool=proxy(ToolSource.class,(p,m,a)->m.getName().equals("toolType")?ToolType.REPEATER:def(m));HttpRequest base=request("https://scope.test/api?id=changed","GET",false,List.of());var event=proxy(HttpRequestToBeSent.class,(p,m,a)->switch(m.getName()){case "toolSource"->tool;case "messageId"->42;case "annotations"->null;default->HttpRequest.class.getMethod(m.getName(),m.getParameterTypes()).invoke(base,a);});extension.handleHttpRequestToBeSent(event);ActivityReconTest.idle(activity);check(activity.tracker.views().stream().noneMatch(v->v.repeater()>0),"OFF blocks passive Repeater observation despite a manual local rule");
  edt(()->{rules.setRowSelectionInterval(0,0);JButton remove=(JButton)UiLayoutTest.named(lists,"wb.traffic.scope.remove");remove.doClick();check(rules.getRowCount()==0&&!WorkbenchScope.contains(api,outside),"scope list deletion immediately revokes tool scope");});
  check(globalMutations.get()==0&&PayloadIntegrationTest.sent.get()==0,"scope changes neither mutate Burp global Scope nor send target requests");for(var h:PayloadIntegrationTest.modernUnloads)h.extensionUnloaded();edt(()->{});check(activity.tracker.views().isEmpty(),"scope integration unload closes activity");System.out.println("TrafficScopeTest: "+checks+" checks passed");
 }
 static void editRules(){
  MontoyaApi api=proxy(MontoyaApi.class,(p,m,a)->def(m));WorkbenchScope scope=WorkbenchScope.install(api);
  scope.add("https://edit.test/first",false);scope.add("https://edit.test/second",false);
  var first=scope.rules().get(0);scope.setEnabled(first,false);
  var replacement=scope.update(first,"https://edit.test/replaced?password=hidden");
  check(scope.rules().get(0).equals(replacement)&&!scope.enabled(replacement),"rule update preserves order and disabled checkbox");
  check(!scope.matchesTraffic("https://edit.test/first/a")&&!scope.save().contains("hidden"),"update revokes old path and discards query secrets");
  for(String invalid:new String[]{"ftp://edit.test/a","not a URL","https://edit.test/a/%2fadmin","https://edit.test/second"}){
   String before=scope.save();boolean rejected=false;try{scope.update(replacement,invalid);}catch(IllegalArgumentException ex){rejected=true;}
   check(rejected&&before.equals(scope.save()),"invalid or duplicate update leaves the entire rule set unchanged: "+invalid);
  }
  check(scope.update(replacement,replacement.url()+"#fragment").equals(replacement)&&!scope.enabled(replacement),"no-op normalized edit preserves checkbox");
  scope.add("https://origin.test/path",true);var domain=scope.rules().get(2);var moved=scope.update(domain,"https://new-origin.test/a");
  check(moved.originOnly()&&moved.url().equals("https://new-origin.test/")&&scope.matchesTraffic("https://new-origin.test/other"),"domain rule editing preserves domain semantics");
  scope.remove(replacement);String before=scope.save();boolean rejected=false;try{scope.update(replacement,"https://edit.test/resurrect");}catch(IllegalArgumentException ex){rejected=true;}
  check(rejected&&before.equals(scope.save()),"stale edit cannot recreate a removed rule");
  scope.syncBurp(TrafficScopeModesTest.config("https://native.test/"));var nativeRule=scope.rules().get(scope.rules().size()-1);before=scope.save();rejected=false;
  try{scope.update(nativeRule,"https://edit.test/native");}catch(IllegalArgumentException ex){rejected=true;}
  check(rejected&&before.equals(scope.save()),"native rule cannot be converted into a local rule by edit");
  WorkbenchScope.release(api);
 }
}
