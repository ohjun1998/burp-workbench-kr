package kr.workbench;
import burp.*;import burp.api.montoya.*;import burp.api.montoya.http.message.requests.*;import javax.swing.*;import javax.swing.table.*;import java.awt.*;import java.awt.image.*;import java.nio.charset.StandardCharsets;import java.util.*;import java.util.List;
public class PacketUiTest extends WorkbenchTest {
 static List<Component> components(Component c){List<Component> all=new ArrayList<>();all.add(c);if(c instanceof Container co)for(Component child:co.getComponents())all.addAll(components(child));return all;}
 static List<String> buttons(Component c){return components(c).stream().filter(x->x instanceof JButton).map(x->((JButton)x).getText()).toList();}
 public static void main(String[] args)throws Exception{
 String raw="POST /api HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{\"id\":9007199254740993,\"items\":[1,2]}";
 edt(()->{PacketView p=new PacketView();p.setPacket(raw);check(p.text.getText().contains("\n  \"id\": 9007199254740993"),"shared request preview indents JSON without changing integer");p.formatted.doClick();check(p.text.getText().equals(raw),"shared preview restores exact raw text");p.formatted.doClick();check(raw.contains("\r\n\r\n{\"id\""),"format toggle never edits source string");p.setPacket("raw compressed bytes", "HTTP/1.1 200\r\n\r\n{\"ok\":true}");check(p.text.getText().contains("\n  \"ok\""),"decoded response source can be formatted separately");p.formatted.doClick();check(p.text.getText().equals("raw compressed bytes"),"raw response remains accessible after decoded display");
 for(var pair:new Object[][]{{"200",WorkbenchUi.Tone.SUCCESS},{"HTTP 200",WorkbenchUi.Tone.SUCCESS},{"302",WorkbenchUi.Tone.REDIRECT},{"404",WorkbenchUi.Tone.WARNING},{"HTTP 503",WorkbenchUi.Tone.ERROR},{"미검증",WorkbenchUi.Tone.NEUTRAL},{"진행 중",WorkbenchUi.Tone.ACTIVE},{"전송 오류",WorkbenchUi.Tone.ERROR},{"검토 필요",WorkbenchUi.Tone.WARNING}})check(WorkbenchUi.tone((String)pair[0])==pair[1],"status classification "+pair[0]);
 JTable t=new JTable(new DefaultTableModel(new Object[][]{{"HTTP 200"}},new String[]{"상태"}));WorkbenchUi.table(t);Component cell=t.prepareRenderer(t.getCellRenderer(0,0),0,0);check(((JLabel)cell).getText().equals("200"),"HTTP status text removes redundant prefix");cell.setSize(100,31);BufferedImage image=new BufferedImage(100,31,BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();cell.paint(g);g.dispose();int expected=WorkbenchUi.toneInk(WorkbenchUi.Tone.SUCCESS).getRGB();boolean found=false;for(int y=0;y<31;y++)for(int x=0;x<100;x++)if(image.getRGB(x,y)==expected)found=true;check(found,"success status is painted in green text without a filled badge");Color previous=UIManager.getColor("Panel.background");UIManager.put("Panel.background",new Color(30,30,30));cell=t.prepareRenderer(t.getCellRenderer(0,0),0,0);check(cell.getForeground().equals(WorkbenchUi.toneInk(WorkbenchUi.Tone.SUCCESS)),"dark theme status has bright readable green");UIManager.put("Panel.background",previous);});
 byte[] gzip;try(var output=new java.io.ByteArrayOutputStream()){try(var zip=new java.util.zip.GZIPOutputStream(output)){zip.write("{\"compressed\":true}".getBytes(StandardCharsets.UTF_8));}gzip=output.toByteArray();}var compressed=proxy(burp.api.montoya.http.message.responses.HttpResponse.class,(p,m,a)->switch(m.getName()){case "headerValue"->"gzip";case "body"->bytes(gzip);case "toByteArray"->bytes(gzip);case "statusCode"->(short)200;case "toString"->"binary raw";default->def(m);});check(PacketFormat.pretty(PacketFormat.decodedResponse(compressed)).contains("\n  \"compressed\""),"compressed response decoded and formatted for managed viewers");
 BurpExtender entry=new BurpExtender();entry.registerExtenderCallbacks((IBurpExtenderCallbacks)PayloadIntegrationTest.host(IBurpExtenderCallbacks.class));edt(()->entry.initialize((MontoyaApi)PayloadIntegrationTest.host(MontoyaApi.class)));edt(()->{});WorkbenchExtension w=(WorkbenchExtension)get(entry,"workbench");
 HttpRequest base=request("https://test/api","POST",true,List.of());HttpRequest q=proxy(HttpRequest.class,(p,m,a)->m.getName().equals("toString")?raw:m.getName().equals("toByteArray")?bytes(raw.getBytes(StandardCharsets.UTF_8)):m.invoke(base,a));seedTraffic(w,q,response(200,"{\"result\":[{\"ok\":true}]}"));edt(()->{try{((JTable)get(w,"logTable")).setRowSelectionInterval(0,0);var requestEditor=(burp.api.montoya.ui.editor.HttpRequestEditor)get(w,"requestView");var responseEditor=(burp.api.montoya.ui.editor.HttpResponseEditor)get(w,"responseView");
 check(requestEditor.getRequest()==q&&responseEditor.getResponse()!=null,"traffic passes original request and response to native Burp editors");
 PacketInspector inspector=(PacketInspector)get(w,"requestPacket");
 check(SwingUtilities.isDescendingFrom(inspector,(Container)get(w,"root"))&&inspector.text.getText().contains("9007199254740993"),"traffic mounts the approved Pretty Raw Hex packet inspector with original content");
 check(UiLayoutTest.named(inspector,"wb.traffic.request.search")==inspector.search,"request Search bar is part of the production packet pane");
 Component requestUi=(Component)get(w,"requestEditorComponent");requestUi.setBackground(Color.MAGENTA);
 Component[] opened={null};w.dialogOpener=(owner,title,content,modal,closed)->{opened[0]=content;return null;};inspector.more.doClick(0);
 check(opened[0]!=null&&SwingUtilities.isDescendingFrom(requestUi,(Container)opened[0]),"more button mounts the real Burp editor in a separate window");
 WorkbenchUi.style(opened[0]);check(requestUi.getBackground().equals(Color.MAGENTA),"native editor keeps host styling when opened from the inspector");
  ((JTable)get(w,"logTable")).clearSelection();
 check(requestEditor.getRequest()==null&&responseEditor.getResponse()==null&&inspector.text.getText().isEmpty(),"clearing selection clears custom and native packet editors");
 JsAnalysisPanel js=(JsAnalysisPanel)get(w,"jsAnalysis");List<String> names=buttons(js);
 var selectedTools=(JComponent)UiLayoutTest.named(js,"wb.js.selected.tools");
 JPopupMenu selectedMenu=(JPopupMenu)selectedTools.getClientProperty("wb.simple.js.tools.menu");
 check(selectedTools instanceof AbstractButton b&&b.getText().replace(" ▾", "").equals("선택 경로")&&selectedMenu!=null&&UiLayoutTest.named(js,"wb.js.more")!=null
     &&java.util.Arrays.stream(selectedMenu.getComponents()).filter(x->x instanceof JMenuItem)
         .map(x->((JMenuItem)x).getText()).toList().containsAll(List.of("관찰된 API 패킷 보기","원문 위치로 이동"))
     &&!names.contains("NPM 존재 조회")&&!names.contains("수집 파일 저장"),
     "JS selected-path menu retains observed packet and original source navigation without extra utility buttons");
 Object runner=get(entry,"payloadRunner");JPanel panel=(JPanel)get(runner,"panel");List<String> actions=buttons(panel);
 JButton settings=(JButton)get(runner,"settingsButton"),start=(JButton)get(runner,"start"),stop=(JButton)get(runner,"stopButton"),evidence=(JButton)get(runner,"evidenceButton"),csv=(JButton)get(runner,"export");
 check(UiLayoutTest.named(panel,"wb.simple.payload.settings")==settings
     &&UiLayoutTest.named(panel,"wb.simple.payload.start")==start
     &&UiLayoutTest.named(panel,"wb.simple.payload.stop")==stop
     &&UiLayoutTest.named(panel,"wb.simple.payload.evidence")==evidence
     &&java.util.stream.Stream.of(settings,start,stop,evidence).allMatch(button->button.getActionListeners().length>0),
     "PDF payload controls retain the exact named settings, start, stop and evidence controllers with their handlers");
 w.selectPayloadRunnerPage();JTabbedPane phases=(JTabbedPane)get(runner,"workflow");phases.setSelectedIndex(0);
 check(ApprovedWorkflowTestSupport.visible(start,panel)&&ApprovedWorkflowTestSupport.visible(stop,panel)
     &&!ApprovedWorkflowTestSupport.visible(evidence,panel)&&!ApprovedWorkflowTestSupport.available(csv,panel),
     "payload preparation prioritizes direct start and stop while result evidence and CSV are absent from visible actions");
 phases.setSelectedIndex(1);
 var csvMenu=ApprovedWorkflowTestSupport.menuAccess(csv,panel);
 check(!ApprovedWorkflowTestSupport.visible(csv,panel)&&csvMenu!=null
     &&csvMenu.item().getName().equals("wb.payload.export.menu")
     &&csvMenu.item().getText().equals(csv.getText())&&csvMenu.item().isEnabled()==csv.isEnabled()
     &&csv.getActionListeners().length>0,
     "PDF results expose the retained CSV controller only through the actual inspection-management menu");
 check(ApprovedWorkflowTestSupport.visible(evidence,panel)&&Boolean.TRUE.equals(evidence.getClientProperty("wb.primary"))
     &&SwingUtilities.isDescendingFrom(evidence,(Container)UiLayoutTest.named(panel,"wb.actions.payload.execution"))
     &&ApprovedWorkflowTestSupport.visible(stop,panel)&&!ApprovedWorkflowTestSupport.visible(start,panel)
     &&ApprovedWorkflowTestSupport.available(start,panel)
     &&!actions.contains("작업 창 열기")&&!actions.contains("더보기"),
     "PDF results prioritize top-level evidence and direct stop while reinspection stays in its retained menu");
 phases.setSelectedIndex(0);
 JTextArea draft=(JTextArea)get(runner,"request");check(kr.packetui.PacketStyle.installed(draft),"payload request editor uses shared packet syntax and gutter");draft.setText(raw);((JToggleButton)get(runner,"requestPreview")).doClick();check(draft.getText().equals(raw),"payload structured preview preserves editable request bytes");check(components(panel).stream().filter(x->x instanceof PacketView).count()>=3,"payload draft and result request/response have common previews");}catch(Exception e){throw new RuntimeException(e);}});
 for(var h:PayloadIntegrationTest.modernUnloads)h.extensionUnloaded();for(var h:PayloadIntegrationTest.legacyUnloads)h.extensionUnloaded();edt(()->{});System.out.println("PacketUiTest: "+checks+" checks passed");
 }
}
