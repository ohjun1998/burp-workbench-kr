# Workbench Simple 1.4.21

왼쪽 최상단에 **통합 점검·대시보드**를 컴팩트 강조형 두 줄로 배치했습니다. 아래 도구 목록을 스크롤해도 두 항목은 보입니다. 통합 점검은 기존 준비 창을 열고, 대시보드는 기존 현재 실행 결과 화면을 엽니다. 메뉴를 누르는 동작만으로 점검을 시작하지 않습니다.

[설치 JAR](downloads/1.4.21/burp-workbench-simple-1.4.21.jar) · [독립 소스 ZIP](downloads/1.4.21/burp-workbench-simple-1.4.21-source.zip) · [변경 안내](docs/RELEASE_SIMPLE_1.4.21_KR.md) · [실제 화면·검증](../docs/reports/2026-11-01-compact-primary-navigation/REPORT_KR.md)

# Workbench Simple 1.4.20

승인한 16개 화면과 다시 대조해 입력 컨트롤, 카드 내부 여백·구분선·모서리, 배너·필터·아이콘·원문 표시를 보완했습니다. 숫자 입력은 기존 모델과 키보드 증감을 유지한 채 시안의 단일 테두리로 표시합니다. 선택 상자 안쪽의 중복 테두리도 제거했습니다. 입력 문서·원문 바이트·선택과 SCOPE·취소·명시적 실행 동작을 유지합니다.

[설치 JAR](downloads/1.4.20/burp-workbench-simple-1.4.20.jar) · [독립 소스 ZIP](downloads/1.4.20/burp-workbench-simple-1.4.20-source.zip) · [변경 안내](docs/RELEASE_SIMPLE_1.4.20_KR.md) · [승인 시안·1.4.19·수정본 비교와 검증](../docs/reports/2026-11-01-approved-review/REPORT_KR.md)

# Workbench Simple 1.4.19

상단 달 모양 버튼으로 Workbench의 라이트·다크 테마를 바로 전환합니다. 설정·전체 화면·오류 기록 등의 기존 도구는 별도의 톱니 메뉴에서 이름과 아이콘으로 선택합니다. 아이콘 전용 버튼에서 메뉴를 만들 때 빈 행으로 표시되던 문제도 수정했습니다.

[설치 JAR](downloads/1.4.19/burp-workbench-simple-1.4.19.jar) · [독립 소스 ZIP](downloads/1.4.19/burp-workbench-simple-1.4.19-source.zip) · [변경 안내](docs/RELEASE_SIMPLE_1.4.19_KR.md) · [실제 화면·검증](../docs/reports/2026-11-01-header-tools/REPORT_KR.md)

# Workbench Simple 1.4.18

요청·응답 목록에 적용한 승인 시안 기준을 나머지 도구와 결과·계정 연결 화면까지 확장했습니다. 메뉴와 버튼, 표의 열 순서, 카드와 원문 읽기 영역을 조정했습니다. 기존 원본 ID·바이트와 검사 엔진, SCOPE·중지·계정 준비 동작을 유지합니다.

[변경 안내](docs/RELEASE_SIMPLE_1.4.18_KR.md) · [설치 JAR](downloads/1.4.18/burp-workbench-simple-1.4.18.jar) · [독립 소스 ZIP](downloads/1.4.18/burp-workbench-simple-1.4.18-source.zip) · [승인 시안·실제 창 비교](../docs/reports/2026-10-31-all-tools-approved/1.4.18/REPORT_KR.md)

아래 이전 버전과 배포 파일은 보존합니다.

# Workbench Simple 1.4.17

승인 PDF와 달랐던 공통 화면, 검사 결과의 실제 필터·응답 시간, 보고서 작성 카드, 인증 준비 창 전체3탭을 보완했습니다. 최종 JAR의 전체7,474개·두 테마/세 크기258화면·실제 Linux 창180개·Katana102개 검사를 통과했습니다. [변경 안내](docs/RELEASE_SIMPLE_1.4.17_KR.md) · [설치 JAR](downloads/1.4.17/burp-workbench-simple-1.4.17.jar) · [독립 소스 ZIP](downloads/1.4.17/burp-workbench-simple-1.4.17-source.zip) · [시안과 실제 비교 PDF](../docs/reports/2026-10-31-pdf-alignment/1.4.17/workbench-simple-1.4.17-pdf-alignment.pdf). 실제 Windows Burp GUI는 직접 검증하지 않았습니다.

독립 소스 ZIP에서는 이 폴더의 `python dev.py check`, 저장소 전체에서는 `python simple/dev.py check`를 사용합니다. 아래는 이전 버전 설명입니다.

# Workbench Simple 1.4.16

승인한 16개 화면의 작업 흐름을 실제 확장에 적용했습니다. 주 작업과 보조 메뉴를 구분하고, 고급 설정을 접어 원문·결과·작성 영역을 넓혔습니다. [변경 안내](docs/RELEASE_SIMPLE_1.4.16_KR.md) · [설치 JAR](downloads/1.4.16/burp-workbench-simple-1.4.16.jar) · [실제 화면 PDF](../docs/reports/2026-10-31-approved-workflow/workbench-simple-1.4.16-workflow.pdf). 이전 버전은 아래 보존합니다.

1.4.14에 남아 있던 주요 버튼을 실제 작업 영역 아래로 재배치합니다. [변경 안내](docs/RELEASE_SIMPLE_1.4.15_KR.md) · [설치 JAR](downloads/1.4.15/burp-workbench-simple-1.4.15.jar).

16개 화면의 작업 공간과 버튼 배치를 정리했습니다. [변경 안내](docs/RELEASE_SIMPLE_1.4.14_KR.md) · [설치 JAR](downloads/1.4.14/burp-workbench-simple-1.4.14.jar).

Apple 디자인 언어를 참고한 라이트·다크 테마를 적용했습니다. [변경 안내](docs/RELEASE_SIMPLE_1.4.13_KR.md) · [설치 JAR](downloads/1.4.13/burp-workbench-simple-1.4.13.jar). 아래 이전 버전 설명과 배포 파일은 보존합니다.

# Workbench Simple 1.4.12

승인한 13개 화면의 버튼 배치를 적용했습니다. 실행·중지를 인접 배치하고 선택 작업을 목록/상세 옆으로 옮겼으며 16개 Guide 예시도 갱신했습니다. [설치 JAR](downloads/1.4.12/burp-workbench-simple-1.4.12.jar) · [변경 안내](docs/RELEASE_SIMPLE_1.4.12_KR.md) · [실제 화면·검증](https://github.com/ohjun1998/burp-workbench-kr/blob/main/docs/reports/2026-10-31-contextual-button-layout/README.md).


**Simple 1.4.11은 도구별 Guide와 빨간 번호 사용 설명을 제공합니다.** 현재 도구에 맞는 별도 가이드 창,16개 화면·96개 단계와 중복/보조 기능 정리를 적용합니다. [설치 JAR](downloads/1.4.11/burp-workbench-simple-1.4.11.jar) · [가이드·정리 검토 화면](docs/images/1.4.11/README.md) · [사용법](docs/RELEASE_SIMPLE_1.4.11_KR.md).

**Simple 1.4.10은 독립 창·최대화·F11 전체화면과 36px 상단을 제공합니다.** Workbench 탭을 누르면 도구를 선택하는 별도 창이 열립니다. 메뉴 색상·마우스 반응·선택 강조와 간격도 정리했습니다. [설치 JAR](downloads/1.4.10/burp-workbench-simple-1.4.10.jar) · [화면](docs/images/1.4.10/README.md) · [사용법](docs/RELEASE_SIMPLE_1.4.10_KR.md).

**Simple 1.4.9는 외부 노출·CVE 조사의 두 탭을 추가합니다.** 검색식·결과 URL 관리와 NVD/KEV/EPSS 조회, 관측·영향·수정 버전 상세를 제공합니다. [설치 JAR](downloads/1.4.9/burp-workbench-simple-1.4.9.jar) · [구현 화면](docs/images/1.4.9/README.md) · [기능·제한](docs/RELEASE_SIMPLE_1.4.9_KR.md).

**Simple 1.4.8은 시안의 단계·요약 줄·계정 비교·상세 정보·증거 편집 구성 요소를 다시 적용합니다.** [설치 JAR](downloads/1.4.8/burp-workbench-simple-1.4.8.jar) · [8개 실제 화면](docs/images/1.4.8/README.md) · [시안 비교](docs/design/1.4.8/COMPARE.html) · [변경·검증](docs/RELEASE_SIMPLE_1.4.8_KR.md). 아래 이전 버전은 보존 이력입니다.

**Simple 1.4.7은 계정 카드·개수 배지·기능 트리부터 공통 버튼·표·패킷까지 세부 디자인을 적용합니다.** [설치 JAR](downloads/1.4.7/burp-workbench-simple-1.4.7.jar) · [8개 실제 화면](docs/images/1.4.7/README.md) · [변경·검증](docs/RELEASE_SIMPLE_1.4.7_KR.md). 아래 이전 버전 파일과 설명은 보존 이력입니다.

**승인 시안과 달랐던 1.4.5 화면을 다시 구성했습니다.** [1.4.6 JAR](downloads/1.4.6/burp-workbench-simple-1.4.6.jar) · [실제 8개 화면](docs/images/1.4.6/README.md) · [변경·검증](docs/RELEASE_SIMPLE_1.4.6_KR.md).

아래 1.4.5 설명은 이전 배포 이력이며, 시각적 일치가 부족해 이번 버전에서 수정했습니다.

**큰 본문 제목 없이 작업 도구 모음부터 시작하는 8개 도구의 새 배치를 적용합니다.** [1.4.5 JAR](downloads/1.4.5/burp-workbench-simple-1.4.5.jar) · [소스·체크섬](downloads/1.4.5/) · [변경·실제 화면](docs/RELEASE_SIMPLE_1.4.5_KR.md).

아래는 이전 배포 이력입니다.

**첨부한 Workbench 0.39.2처럼 작은 상단 도구 모음과 왼쪽 5개 폴더로 디자인·배치를 바꿉니다.** 한글 기본 글꼴·표·선택 강조를 맞추고 Simple 기능과 1.4.3 로드 수정을 유지합니다. [1.4.4 설치 JAR](downloads/1.4.4/burp-workbench-simple-1.4.4.jar) · [소스·체크섬](downloads/1.4.4/) · [배치·사용 안내](docs/RELEASE_SIMPLE_1.4.4_KR.md).

아래 1.4.3 및 이전 버전의 설명과 파일은 보존 이력입니다.

**Burp 확장 추가 시 `com/sun/net/httpserver/HttpServer` 오류로 전체 로드가 중단되는 문제를 수정합니다.** 브라우저 연결 서버를 사용할 수 없으면 원인과 복구 방법을 표시하고 일반 HTTP 작업을 초기화합니다. 이 상태에서 브라우저 도우미·SPA 연결은 사용할 수 없습니다. [1.4.3 JAR](downloads/1.4.3/burp-workbench-simple-1.4.3.jar) · [소스·체크섬](downloads/1.4.3/) · [설치·Java 확인 방법](docs/RELEASE_SIMPLE_1.4.3_KR.md).

아래는 보존한 1.4.2의 작업 흐름 안내입니다. 새 설치에는 문서 상단의 최신 버전을 사용하세요.

**점검 대시보드에서 현재 실행의 수치를 보고, 카드·막대를 눌러 조건별 목록과 근거·원본을 확인합니다.** 기존 8개 도구와 Katana·SCOPE 통합 점검을 유지하고 기존 Next 및 Simple 1.0.0–1.4.1 JAR·소스·PDF를 보존합니다.

1.4.2는 서버·경로의 대상과 계정을 기본 화면에서 선택하고, 수신 중에도 읽던 응답을 유지하며, URL 대상 준비 오류를 같은 창에서 바로 수정하게 합니다. 검색 준비·화면 반영의 완료 상태도 보강합니다. [실제 작업의 전후 검증](docs/RELEASE_SIMPLE_1.4.2_KR.md)과 [보존한 1.4.1 개선 기록](docs/RELEASE_SIMPLE_1.4.1_KR.md)을 참고하세요.

SCOPE URL·HTTP 계정 선택 → Katana·통합 점검 시작 → 결과·원본 확인 → 필요한 기존 도구·증거 저장으로 이어갑니다. 도구를 정해진 순서대로 모두 거칠 필요는 없습니다.

| 필요한 파일 | 위치 |
|---|---|
| 설치 JAR | [burp-workbench-simple-1.4.2.jar](downloads/1.4.2/burp-workbench-simple-1.4.2.jar) |
| 독립 빌드 소스 | [소스 ZIP](downloads/1.4.2/burp-workbench-simple-1.4.2-source.zip) · [SHA256SUMS](downloads/1.4.2/SHA256SUMS) |
| 브라우저·SPA helper | [helper 0.4.1 ZIP](downloads/1.4.2/feature-mapper-browser-helper-0.4.1.zip) |
| 외부 Katana 1.8.0 | [공식 배포·SHA-256 확인 설치 도구](tools/install_katana.py) · [고정 의존성 기록](docs/KATANA_DEPENDENCY.json) · 실행 파일 별도 설치 |
| 실사용 개선 안내 | [일상 조건·설정 절차·읽기·복구 개선](docs/RELEASE_SIMPLE_1.4.2_KR.md) |
| 대시보드 집계 기준 | [수치·필터·근거·원본 연결](docs/RELEASE_SIMPLE_1.4.0_KR.md) |
| 기존 도구 그림 가이드 | [보존한 1.3.2 HTML 안내서](docs/GUIDE_SIMPLE_KR.html) · [1.3.2 문서 원고](docs/GUIDE_SIMPLE_KR.md) |
| 기존 도구 PDF 가이드 | [보존한 1.3.2 그림 가이드북](downloads/guides/1.3.2/Workbench_Simple_1.3.2_Guide_KR.pdf) |
| 실제 검증 결과 | [1.4.2 검사와 미실행 범위](docs/VERIFICATION_SIMPLE_1.4.2.json) |
| Katana 실제 실행 | [공식 프로세스·격리 HTTP/HTTPS 검증](docs/verification/1.4.2/katana-native/katana-verification.json) |
| Katana 적용 범위 | [기존 요구사항·구현·검사 연결표](docs/KATANA_SCOPE_1.3.2_SPEC_KR.md) |

## 점검 대시보드

상단 **대시보드 → 통합 점검 열기**에서 실행을 준비합니다. 현재 실행의 관측 경로·API와 명세·환경과 DB 단서·민감정보 후보·계정별 차이·미확인 수치를 클릭하면 같은 기준의 결과 목록을 표시합니다. 계정과 민감정보 중요도로 좁히고 항목을 선택해 근거·원본 위치를 확인합니다. 연결된 원본에서 Repeater 준비·증거 추가로 이어갑니다.

카드 수와 목록 수는 같은 집계 기준을 사용합니다. 후보와 확정 취약점, 전송 한도와 점검 완료율을 구분하며 계정 정보가 없는 후보는 전체 결과 계정에서 확인합니다. 대시보드는 현재 실행만 표시하며 조회와 필터는 대상 요청을 보내지 않습니다. [전체 집계 기준과 사용법](docs/RELEASE_SIMPLE_1.4.0_KR.md)을 참고하세요.

대량 결과를 집계하는 동안에는 **—**와 진행 안내를 표시합니다. 같은 실행의 갱신은 이전 집계임을 명시하고, 실행·계정 변경이나 종료 뒤에 오래된 결과가 다시 표시되지 않도록 처리합니다.

## SCOPE 통합 점검

| 결과 | 연결한 기능 | 판정과 범위 |
|---|---|---|
| 메뉴·기능 발견 | Katana·HTML·JS·robots/sitemap·API 문서와 브라우저 관측을 연결합니다. | 실제 관측, 문서 선언, 기술 추정 후보를 구분합니다. |
| 환경·주요 경로 | 서버·WAS·프레임워크·프록시/CDN·DB 단서를 모으고 관련 경로를 확인합니다. | 탐지 근거·확실성과 응답 내용 확인 상태를 함께 읽습니다. |
| API·민감정보 | API 문서와 관측 요청을 대조하고 키·토큰·내부 정보 후보를 분류합니다. | 공개 식별자·예제·비밀키 후보, 중요도·확신도·유효성을 구분합니다. |
| 권한·변경 비교 | 선택한 HTTP 계정별 응답 차이와 이전 실행의 새 항목·변경 후보를 확인합니다. | 같은 프로젝트·계정·조건의 비교만 사용하고 불완전 실행을 해결로 확정하지 않습니다. |
| 원본·증거 | 불변 원본 ID에서 요청·응답을 열고 기존 도구와 증거에 연결합니다. | 과거 이력의 원본이 없으면 현재 원본처럼 열리지 않습니다. |
| 원문 값 분류 보고서 | 현재 응답의 API·민감정보·토큰·키·환경 값을 위치와 원본 ID별로 저장합니다. | 제품 탐지와 보고서 추가 파싱을 구분하며 로컬 ZIP에는 원문 값이 포함됩니다. |
| 범위·실행 상태 | SCOPE·리디렉션·요청 한도·세션·중지/재개와 제외 사유를 확인합니다. | HTTP 완료·브라우저 탐색·미검사·실패 상태를 각각 확인합니다. |

## 설치와 첫 점검

1. Simple 설치 JAR burp-workbench-simple-1.4.2.jar를 준비하고 기존 Workbench 파일을 보관합니다.
2. Burp Extensions → Add → Java에서 Simple JAR를 선택하고 Workbench Simple 탭을 엽니다.
3. 한 확장에서만 수집하려면 기존 Workbench의 로드를 해제하고 Simple을 사용합니다. 기존 확장이나 원본 파일을 삭제할 필요는 없습니다.
4. SCOPE 목록에 대상 URL과 경로를 등록하고 허용·제외 범위를 확인합니다. 통합 점검 화면에서 URL·HTTP 계정과 요청 한도를 정합니다.
5. Katana 탐색의 실행 파일·수집 조건을 확인한 뒤 통합 점검을 시작합니다. Katana 수집과 환경·경로·API·키/민감정보·권한 차이·커버리지 결과를 확인합니다. 브라우저 모드는 helper를 준비한 뒤 선택합니다.
6. 원본과 근거를 읽고 필요한 기존 도구에 연결합니다. 제출할 증거는 가림 미리보기 → 증거 ZIP 저장으로, 파싱한 원문 값은 통합 점검의 분류 보고서 저장으로 각각 저장합니다.

화면 열기와 도구 이동은 전송하지 않습니다. 통합 점검 시작은 설정한 범위에 조회 요청을 전송합니다. 일반 트래픽 수집 OFF/SCOPE와 명시적 통합 점검 실행을 구분합니다.

## Katana 1.8.0 설치와 수집

1. Simple 폴더 또는 독립 소스 ZIP의 루트에서 python tools/install_katana.py --dest 뒤에 쓸 수 있는 외부 절대 경로를 지정합니다. 저장소 루트에서는 simple/tools/install_katana.py를 사용합니다. 공식 Katana 1.8.0 배포와 SHA-256을 확인해 실행 파일·설치 기록을 저장합니다.
2. 설치 완료 시 출력된 실행 파일 경로를 복사합니다. Workbench의 SCOPE 통합 점검 → 실행 조건에서 파일 선택 또는 경로 입력 후 설치 확인을 누릅니다. Katana는 별도 설치하며 관리자 권한·PATH·사용자 CA 변경이 필요하지 않습니다.
3. Katana 탐색을 선택하고 Katana 페이지 한도와 수집 시간(초)을 정합니다. 선택한 HTTP 계정이 Katana 수집의 실행 주체입니다. 대상 URL·허용 경로·계정·총 요청 한도를 확인한 뒤 통합 점검을 시작합니다.
4. Katana 수집에서 상태·발견 출처·후보와 차단 사유를 확인합니다. 환경·경로·API·민감정보·계정별 차이·변경·커버리지는 기존 결과 탭에서 이어서 읽습니다.

Linux/macOS에서 Simple 폴더 또는 독립 소스 ZIP 루트의 사용 예:

```sh
python tools/install_katana.py --dest "$HOME/Tools/Workbench-Katana/1.8.0"
```

저장소 루트에서 실행할 때는 `python simple/tools/install_katana.py`를 사용합니다.

Windows에서는 `--dest "C:/Tools/Workbench-Katana/1.8.0" --platform windows_amd64`처럼 사용자가 쓸 수 있는 외부 폴더와 해당 플랫폼을 지정할 수 있습니다. 설치 도구는 PATH·HOME 설정을 재지정하거나 시스템 CA를 설치하지 않습니다.

- 기존 Katana 재개 자료가 필요하면 먼저 보관합니다. 공급자 Katana 1.8.0은 버전 확인 때도 기본 사용자 설정 위치의 10일 지난 resume 파일을 정리할 수 있습니다. 설치 도구는 HOME을 재지정하지 않으며 이 동작을 의존성·설치 기록에 명시합니다.
- Katana는 HTML·JavaScript·폼 메타데이터·기술 단서를 수집합니다. 실제 대상 요청은 실행 전용 인증 loopback 프록시를 거쳐 Workbench의 HTTP 계정·SCOPE·요청 예산을 적용합니다.
- HTTPS CONNECT도 같은 전송 경계를 사용합니다. 실행용 임시 인증서를 사용하며 사용자 운영체제·브라우저에 CA 인증서를 설치하지 않습니다. 대상 Cookie·Authorization은 Katana 명령행이나 설정 파일로 전달하지 않습니다.
- JSONL의 경로·폼·기술 메타데이터는 자동 재조회하지 않습니다. 폼의 action·메서드·입력 이름은 발견 정보이며 값은 메타데이터에 남기지 않고 민감 필드 이름을 가립니다. 폼 제출·자동 로그인·쓰기·키 자동 검증·외부 공급자 API·자동 업데이트는 실행하지 않습니다.
- Katana는 # 조각이 없는 HTTP(S) 주소에서 표준 HTML/JS 모드로 수집합니다. SPA 메뉴·hash route는 기존 브라우저 helper에서 선택합니다. 브라우저 로그인 세션은 선택한 Workbench HTTP 계정과 별개입니다.
- Katana 종료와 사이트 전체 검증 완료를 구분합니다. 시간·페이지·요청 한도, 차단·실패·부분 분석과 미확인 항목을 확인합니다. 일시정지 후 재개해도 처음 정한 절대 시간과 공통 요청 예산을 유지합니다.
- Katana 실행 파일이 없거나 실행에 실패하면 Katana 실패·부분 수집 사유를 확인합니다. 일반 HTTP 점검 결과는 따로 유지하며 Katana 수집 성공으로 표시하지 않습니다.

## 브라우저·SPA 모드 준비

1. 배포 파일 feature-mapper-browser-helper-0.4.1.zip을 새 폴더에 풀어 manifest.json이 보이는 폴더를 준비합니다. 기존 helper와 배포 파일은 보관합니다.
2. Chrome은 chrome://extensions, Edge는 edge://extensions를 열고 개발자 모드에서 압축해제된 확장 로드를 선택해 해당 폴더를 불러옵니다.
3. Workbench의 기능 매핑 설정에서 브라우저 연결 주소와 토큰을 확인하고 helper 팝업에 입력한 뒤 연결을 확인·저장합니다. 토큰은 로컬 연결에 사용합니다.
4. 브라우저에서 대상 사이트를 열고 필요한 로그인을 마칩니다. helper에서 현재 사이트를 활성화하고 정상적인 사이트 접근 권한 절차를 진행합니다.
5. SPA 통합 탐색 허용을 켭니다. 통합 점검에서 브라우저 모드를 선택해 시작하면 helper가 같은 브라우저 프로필의 로그인 세션을 사용하는 별도 탐색 탭을 엽니다.
6. 기존 사용자 탭은 유지합니다. 실행을 중지하면 탐색 탭과 해당 실행의 가드 정리를 확인합니다. 브라우저 로그인 계정은 Workbench에서 선택한 HTTP 계정과 별개입니다.

브라우저 모드는 URL 규칙으로 안전하게 표현할 수 있는 범위에서 사용합니다. 지원하지 않는 정규식 범위는 사용 불가 사유를 확인하고 HTTP 모드로 점검합니다. 좁은 SCOPE가 필요한 리소스를 제외하면 부분 탐색으로 표시하며 범위를 자동 확장하지 않습니다.

브라우저 로그인 계정과 HTTP 점검 계정은 별개입니다. helper는 쿠키를 HTTP 계정으로 복사하지 않으며, 브라우저 페이지·동작 한도와 네트워크 관측 수는 HTTP 요청 예산과 구분합니다.

## 기존 8개 도구

| 도구 | 유지한 핵심 기능 | 부가 흐름 정리 |
|---|---|---|
| 요청·응답 (요청·응답 목록) | SCOPE, OFF/SCOPE 수집, 검색, 요청·응답 원본, Repeater 준비와 증거 연결 | 중복 탐색·작업 관리 바 제거. 저장 검색 조건은 검색 설정에서 필요할 때 사용. |
| 기능 매핑 (기능 자동 매핑) | 기능·실행·세션 분류, 패킷·분류 근거, 프로젝트 저장·열기와 점검 업무 연결 | 핵심 분류·프로젝트 흐름 유지. 브라우저 도우미와 세부 설정은 필요한 경우 선택. |
| 계정 비교 (계정 권한 비교) | 계정 연결, 세션·권한·쓰기 조회 조건, 선택 요청 직접 비교, 중지와 결과 근거 | 신규 요청 자동 비교 토글 제거. 선택한 원본의 준비와 직접 실행에 집중. |
| API 찾기 (JS에서 API 찾기) | 관측 텍스트 응답의 API·키 후보, 원본 위치·로컬 이력, 선택 API의 요청 준비 | 시작 시 기존 History 자동 순회 제거. 부가 NPM·소스맵 조회는 메인 흐름에서 제외. |
| 서버·경로 (서버·경로 탐색) | 관측 서버·경로 정보, 후보 경로, 선택 경로의 직접 GET 확인 | 선택 대상과 확인 조건 중심으로 사용. 보조 설정·수집 경로는 필요할 때 열기. |
| 응답 분석 (응답 보안 분석) | 보안 단서, API 문서, 저장 후 조회 흐름과 원본·증거 연결 | 주요 분석 기능 유지. 보조 설정은 필요할 때 열고 원본 근거 확인에 집중. |
| 입력값 검사 (입력값 보안 검사) | 검사 유형, 입력 위치·값, 간격·한도·SCOPE, 기준·변경·대조 결과와 증거 연결 | 검사 조건과 결과 검토에 집중. 선택 결과에서 증거로 바로 연결. |
| 재현·증거 (재현·증거 정리) | 요청 순차 재현·중지·결과 확인, 원본·비교·재현 결과 추가, 가림과 ZIP 저장 | OAST·외부 도구·기존 브라우저 보조 화면 제외. 요청 재현·증거 정리 유지, SPA는 통합 점검에서 선택. |

## 결과를 읽는 기준

- 관측은 실제 응답이나 참조를 읽은 상태입니다. 기술 이름·DB 오류·경로 이름은 근거와 함께 읽고, 추정 또는 미확인 상태를 확정으로 바꾸지 않습니다.
- HTTP 200이어도 공통 홈·로그인·soft404일 수 있습니다. 부재 경로 대조가 불안정하거나 보안 확인·요청 제한이 발생하면 내용 확인을 보류합니다.
- 키 형식이 맞아도 공개 SDK 식별자·예제·비밀키 후보가 다릅니다. 기본은 마스킹과 원본 위치·지문 표시이며 발견한 키를 자동 검증하거나 인증값으로 사용하지 않습니다.
- 분류 보고서 저장은 응답 원문을 포함하는 별도 로컬 내보내기입니다. 정적 문자열과 동적 API 템플릿을 구분하고, 식을 평가하거나 없는 원문 값을 만들어내지 않습니다. 화면·이력의 가림은 유지합니다.
- 본문 줄·문자 위치는 분석한 텍스트 본문을 기준으로 읽습니다. HTTP 헤더를 포함한 원시 패킷의 바이트 위치와 다르며 압축·문자 인코딩에 따라 원본 미리보기와 직접 일치하지 않을 수 있습니다.
- 브라우저 메뉴·화면·API 연결은 전용 탭과 현재 라우트의 관측 문맥입니다. 지연 메뉴는 제한 시간 안에서 기다리며, 한도와 미확인 상태를 전체 메뉴 완료로 해석하지 않습니다.
- 브라우저 탐색은 허용 Origin·포트·경로·제외 범위를 지킵니다. URL 규칙으로 안전하게 표현할 수 없는 범위는 브라우저 모드 사용 불가 사유를 확인하고 HTTP 모드로 점검합니다.
- 좁은 SCOPE가 필요한 스크립트·리소스를 제외하면 일부 메뉴가 열리지 않을 수 있습니다. 결과는 부분 탐색으로 읽고 범위를 자동으로 넓힌 것으로 가정하지 않습니다.
- 자동 탐색은 GET/HEAD와 알려진 변경 경로 제외 규칙을 사용합니다. GET을 사용하는 서버 기능에 부작용이 전혀 없음을 보장하는 방식은 아니므로 결과와 원본을 확인합니다.
- HTTP 요청 예산에는 기준·신원·리디렉션 요청도 포함됩니다. 브라우저의 페이지·동작 한도와 실제 네트워크 관측 수는 HTTP 점검의 엄격한 요청 예산과 구분합니다.
- 대형 덤프·아카이브 후보는 자동 점검에서 제외합니다. 압축을 푼 본문 분석에도 바이트 한도를 적용하며 전체 압축 원본은 별도로 보관합니다. 분석 한도는 실제 다운로드 중단 한도가 아니므로 미검사·부분 분석 이유를 확인합니다.
- 저장된 실행 이력은 마스킹된 결과·지문 중심입니다. 인증 헤더·쿠키·본문·시크릿 원문을 실행 이력으로 저장하지 않으며, 현재 실행의 원본과 과거 요약을 구분합니다.

## 원본·이력·증거

통합 점검은 현재 실행의 전체 원본 요청·응답을 불변 ID로 연결하고, 기존 도구와 증거에서 같은 원본을 사용합니다. 저장된 실행 이력은 마스킹된 결과·지문 중심이며 원본 패킷 자동 복원을 의미하지 않습니다. 과거 원본이 현재 세션에 없으면 이력으로 구분합니다.

Simple 설정 키는 `simple.*`, 저장 폴더는 `.burp-workbench-simple`입니다. 기존 Next와 분리되며 이전 Simple 설정은 같은 Simple 저장 공간을 사용합니다.

## 캡처와 검증

그림은 Simple 운영 Swing 화면에 합성 예제 패킷을 넣어 렌더링한 캡처입니다. 실제 Burp GUI를 조작한 캡처가 아닙니다. 예제 URL·계정·판정은 실제 대상 점검의 성공을 뜻하지 않습니다. DOM 어댑터·실제 브라우저·실제 Burp 실행 범위는 버전별 검증 기록에서 구분합니다.

## 개발과 가이드 재생성

완전한 JDK에서 `python dev.py build`, `python dev.py check`를 사용합니다. 기본 컴파일은 `--release 17`입니다. Node 검사 런처는 설치된 Node가 지원하는 옵션 표기를 확인하며 실제 하위 검사 집계를 검증합니다.

이번 로컬 빌드는 별도로 준비한 Temurin JDK 17의 `--release 17`을 사용합니다. 런타임·컴파일 방식과 실제 실행한 검사·제한은 1.4.2 검증 기록을 확인합니다.

테스트 어댑터 빌드 후 두 캡처 명령으로 기존 8개 도구와 통합 점검 화면을 같은 버전 디렉터리에 생성합니다. PDF 생성에는 Python `reportlab`, `Pillow`가 필요하고, 구조 검증에는 `PyMuPDF`를 사용합니다.

```sh
python tools/render_simple.py --check
python tools/render_scope_inspection.py --check
```

JDK 17 이상에서 위 명령을 실행하거나 `--java`로 JDK 경로를 지정합니다. 기존 1.3.2 그림 가이드·PDF와 생성 도구는 보존하며 이번 대시보드 안내는 별도 1.4.0 문서와 운영 컴포넌트 캡처로 제공합니다. 원본 Next나 이전 Simple 결과를 새 검사 수로 합산하지 않습니다. GPL·제3자 고지를 보존합니다.

[보존한 Simple 1.3.1 안내서](docs/history/1.3.1/GUIDE_SIMPLE_KR.html) · [1.3.1 PDF](downloads/guides/1.3.1/Workbench_Simple_1.3.1_Guide_KR.pdf) · [1.3.0 안내서](docs/history/1.3.0/GUIDE_SIMPLE_KR.html) · [1.3.0 PDF](downloads/guides/1.3.0/Workbench_Simple_1.3.0_Guide_KR.pdf) · [1.2.0 안내서](docs/history/1.2.0/GUIDE_SIMPLE_KR.html) · [1.1.0 안내서](docs/history/1.1.0/GUIDE_SIMPLE_KR.html) · [1.0.0 안내서](docs/history/1.0.0/GUIDE_SIMPLE_KR.html)
