package kr.workbench;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.text.JTextComponent;
import java.awt.*;

/** Local component styling only; never modifies Burp's global look-and-feel. */
public final class WorkbenchUi {
 private WorkbenchUi(){}
 public static boolean dark(){return kr.packetui.VisualTheme.dark();}
 public static Color surface(){return kr.packetui.VisualTheme.surface();}
 public static Color raised(){return kr.packetui.VisualTheme.raised();}
 public static Color background(){return kr.packetui.VisualTheme.background();}
 public static Color ink(){return kr.packetui.VisualTheme.ink();}
 public static Color line(){return kr.packetui.VisualTheme.line();}
 public static Color accent(){return kr.packetui.VisualTheme.accent();}
 public static Color selected(){return kr.packetui.VisualTheme.selected();}
 private static Font bundled;
 private static synchronized Font bundledFont(){if(bundled==null)try(var in=WorkbenchUi.class.getResourceAsStream("/fonts/WorkbenchSans-Regular.otf")){if(in!=null)bundled=Font.createFont(Font.TRUETYPE_FONT,in);}catch(Exception ignored){}return bundled;}
 private static Font preferred;
 private static int appearanceScale=100;
 private static boolean appearanceCompact;
 static void setAppearance(int scale,boolean compact){if(scale!=100&&scale!=125&&scale!=150)throw new IllegalArgumentException("지원하는 글자 크기가 아닙니다.");appearanceScale=scale;appearanceCompact=compact;}
 static int appearanceScale(){return appearanceScale;}
 static boolean appearanceCompact(){return appearanceCompact;}
 public static float displaySize(float base){return base*appearanceScale/100f;}
 static int displayPixels(int base){return Math.round(base*appearanceScale/100f);}
 public static synchronized Font font(){if(preferred==null){Font f=bundledFont();preferred=f==null?new Font(Font.SANS_SERIF,Font.PLAIN,14):f;}return preferred.deriveFont(Font.PLAIN,displaySize(14f));}
 private static Font areaFont(JTextArea area){if(Boolean.TRUE.equals(area.getClientProperty("wb.approved.note")))return font().deriveFont(displaySize(11f));if(Boolean.TRUE.equals(area.getClientProperty("wb.approved.codec")))return textFont(area.getText()).deriveFont(displaySize(14f));if(Boolean.TRUE.equals(area.getClientProperty("wb.approved.packet"))||Boolean.TRUE.equals(area.getClientProperty("wb.approved.fact")))return textFont(area.getText()).deriveFont(displaySize(12f));return Boolean.TRUE.equals(area.getClientProperty("wb.prose"))?font():textFont(area.getText());}
 public static Font textFont(String text){Font mono=new Font(Font.MONOSPACED,Font.PLAIN,12).deriveFont(displaySize(12f));return mono.canDisplayUpTo(text==null?"":text)<0?mono:font();}
 public static JDialog settingsWindow(Component owner,String title,Component content,boolean modal,Runnable closed){
  if(GraphicsEnvironment.isHeadless())return null;
  Window parent=SwingUtilities.getWindowAncestor(owner);JDialog dialog=new JDialog(parent,title,modal?Dialog.ModalityType.APPLICATION_MODAL:Dialog.ModalityType.MODELESS);dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
  JPanel body=settingsBody(content,dialog::dispose);dialog.setContentPane(body);dialog.setMinimumSize(new Dimension(560,300));dialog.setSize(760,480);dialog.setLocationRelativeTo(owner);dialog.addWindowListener(new java.awt.event.WindowAdapter(){public void windowClosed(java.awt.event.WindowEvent e){if(closed!=null)closed.run();}});dialog.setVisible(true);return dialog;
 }
 static JPanel settingsBody(Component content,Runnable closeAction){JPanel body=new JPanel(new BorderLayout(8,8));body.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));body.add(content instanceof JTabbedPane tabs&&"wb.auth.preparation.tabs".equals(tabs.getName())?content:new JScrollPane(content));JButton close=new JButton("닫기");close.addActionListener(e->closeAction.run());body.add(row(close),BorderLayout.SOUTH);style(body);return body;}
 public static JPanel row(Component... parts){JPanel p=new JPanel(new WrapLayout(FlowLayout.LEFT,8,5)){@Override public Dimension getMaximumSize(){return new Dimension(Integer.MAX_VALUE,getPreferredSize().height);}};p.setAlignmentX(Component.LEFT_ALIGNMENT);for(Component c:parts)p.add(c);return p;}
 public static JPanel group(String title,Component... parts){JPanel p=row(parts);p.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(line()),title,TitledBorder.LEADING,TitledBorder.TOP,font().deriveFont(displaySize(11f)),ink()));return p;}
 public static JPanel card(String title,Component body){return ApprovedUi.card(title,body);}
 public static JPanel nativeCard(String title,Component editor){if(editor instanceof JComponent j)j.putClientProperty("wb.nativeEditor",true);return card(title,editor);}
 public static JSplitPane split(int direction,Component a,Component b,double ratio){
  JSplitPane p=new JSplitPane(direction,a,b);p.setContinuousLayout(true);p.setBorder(null);p.setDividerSize(7);p.setMinimumSize(new Dimension(100,80));
  a.setMinimumSize(new Dimension(80,60));b.setMinimumSize(new Dimension(80,60));configureSplit(p,ratio);
  p.addComponentListener(new java.awt.event.ComponentAdapter(){public void componentResized(java.awt.event.ComponentEvent e){p.putClientProperty("wb.split.pending",true);placeSplit(p);}public void componentShown(java.awt.event.ComponentEvent e){SwingUtilities.invokeLater(()->placeSplit(p));}});
  if(p.getUI() instanceof javax.swing.plaf.basic.BasicSplitPaneUI ui)ui.getDivider().addMouseListener(new java.awt.event.MouseAdapter(){public void mouseReleased(java.awt.event.MouseEvent e){int size=(p.getOrientation()==JSplitPane.HORIZONTAL_SPLIT?p.getWidth():p.getHeight())-p.getDividerSize();if(size>160){double ratio=Math.max(.1,Math.min(.9,(double)p.getDividerLocation()/size));p.putClientProperty("wb.split.ratio",ratio);p.setResizeWeight(ratio);}}});
  p.addHierarchyListener(e->{if((e.getChangeFlags()&java.awt.event.HierarchyEvent.SHOWING_CHANGED)!=0&&p.isShowing())SwingUtilities.invokeLater(()->placeSplit(p));});
  return p;
 }
 static void restoreSplit(JSplitPane p,double ratio){configureSplit(p,Math.max(.1,Math.min(.9,ratio)));}
 private static void configureSplit(JSplitPane p,double ratio){p.setResizeWeight(ratio);p.putClientProperty("wb.split.ratio",ratio);p.putClientProperty("wb.split.pending",true);SwingUtilities.invokeLater(()->placeSplit(p));}
 private static void placeSplit(JSplitPane p){if(!Boolean.TRUE.equals(p.getClientProperty("wb.split.pending")))return;int size=p.getOrientation()==JSplitPane.HORIZONTAL_SPLIT?p.getWidth():p.getHeight();if(size<160)return;p.setDividerLocation((Double)p.getClientProperty("wb.split.ratio"));p.putClientProperty("wb.split.pending",false);}
 /** The navigation breadcrumb and F1 guide provide titles and explanations once. */
 public static JPanel header(String title,String description,Component controls){JPanel p=new JPanel(new BorderLayout());p.setName("wb.workspace.controls");p.getAccessibleContext().setAccessibleName(title);p.setToolTipText(description);if(controls!=null)p.add(controls);else p.setVisible(false);return p;}
 public static JLabel hint(String text){JLabel hint=new JLabel(text);hint.setVisible(false);return hint;}
 public static void feedback(JLabel label){String initial=label.getText();label.setVisible(false);label.addPropertyChangeListener("text",e->{String text=label.getText();label.setVisible(text!=null&&!text.isBlank()&&!text.equals(initial));if(label.getParent()!=null)label.getParent().revalidate();});}

 public static void primary(JButton b){b.putClientProperty("wb.primary",true);buttonPaint(b);}
 private static void buttonPaint(AbstractButton b){if(Boolean.TRUE.equals(b.getClientProperty("wb.filter.segment"))){b.setForeground(b.isSelected()?accent():kr.packetui.VisualTheme.muted());return;}if(Boolean.TRUE.equals(b.getClientProperty("wb.state.toggle"))){boolean lamp=Boolean.TRUE.equals(b.getClientProperty("wb.analysis.lamp"));b.setBackground(b.isSelected()?(lamp?new Color(23,58,39):new Color(23,125,70)):(lamp?new Color(55,25,30):new Color(181,45,58)));b.setForeground(Color.WHITE);return;}boolean active=b.isEnabled()&&Boolean.TRUE.equals(b.getClientProperty("wb.primary"));b.setBackground(active?kr.packetui.VisualTheme.primary():surface());b.setForeground(active?Color.WHITE:b.isEnabled()?ink():toneInk(Tone.NEUTRAL));}
 private static boolean insideCard(Component component){
  for(Container parent=component.getParent();parent!=null;parent=parent.getParent())
   if(parent instanceof JComponent card&&Boolean.TRUE.equals(card.getClientProperty("wb.card"))||parent.getName()!=null&&parent.getName().startsWith("wb.card."))return true;
  return false;
 }
 public static void style(Component c){
  if(c instanceof JComponent embedded && embedded.getClientProperty("wb.embedded.style") instanceof Runnable style){style.run();return;}
  if(c instanceof PacketInspector inspector){inspector.applyTheme();return;}
  if(c instanceof JComponent aa)aa.putClientProperty(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
  if(c instanceof JComponent j&&Boolean.TRUE.equals(j.getClientProperty("wb.nativeEditor")))return;
  Font previous=c.getFont();Object size=c instanceof JComponent j?j.getClientProperty("wb.font.size"):null;boolean heading=c instanceof JComponent j&&Boolean.TRUE.equals(j.getClientProperty("wb.font.heading"));c.setFont(font().deriveFont(heading?Font.BOLD:previous==null?Font.PLAIN:previous.getStyle(),displaySize(size instanceof Number n?n.floatValue():13f)));c.setForeground(ink());
  if(c instanceof JPanel p){p.setAlignmentX(Component.LEFT_ALIGNMENT);p.setBackground(Boolean.TRUE.equals(p.getClientProperty("wb.surface"))||insideCard(p)?surface():background());if(p.getLayout() instanceof FlowLayout f&&!(f instanceof WrapLayout))p.setLayout(new WrapLayout(f.getAlignment(),8,5));if(p.getName()!=null&&p.getName().startsWith("wb.card."))p.setBackground(surface());}
  if(c instanceof JLabel l&&l.getFont()!=null){if(l.getParent()!=null&&l.getParent().getName()!=null&&l.getParent().getName().startsWith("wb.card.")){l.setFont(font().deriveFont(Font.BOLD,displaySize(13f)));l.setOpaque(true);l.setBackground(surface());}}
  if(c instanceof JLabel secondary&&Boolean.TRUE.equals(secondary.getClientProperty("wb.secondary")))secondary.setForeground(toneInk(Tone.NEUTRAL));
  if(c instanceof JPopupMenu popup){popup.setBackground(surface());popup.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(line()),BorderFactory.createEmptyBorder(4,0,4,0)));}
  if(c instanceof JMenuItem item)item.setBackground(surface());
  if(c instanceof JLabel l&&Boolean.TRUE.equals(l.getClientProperty("wb.status")))statusPaint(l);
  if(c instanceof AbstractButton b&&(b instanceof JButton||b instanceof JToggleButton&&!(b instanceof JCheckBox)&&!(b instanceof JRadioButton))){b.setFont(font().deriveFont(displaySize(12f)));WorkbenchSkin.button(b);b.setMargin(b.getName()!=null&&b.getName().startsWith("wb.settings.")?new Insets(2,6,2,6):new Insets(5,11,5,11));b.setFocusPainted(true);buttonPaint(b);if(!Boolean.TRUE.equals(b.getClientProperty("wb.button.watch"))){b.putClientProperty("wb.button.watch",true);b.addPropertyChangeListener("enabled",e->buttonPaint(b));b.addPropertyChangeListener("wb.primary",e->buttonPaint(b));}if(b.getToolTipText()==null)b.setToolTipText(b.getText());}
  if(c instanceof JCheckBox b){b.setIcon(kr.packetui.VisualTheme.checkIcon());b.setIconTextGap(6);b.setOpaque(false);if(b.getToolTipText()==null)b.setToolTipText(b.getText());}
  if(c instanceof JTextComponent t){t.setBackground(surface());t.setForeground(ink());t.setCaretColor(ink());t.setSelectionColor(selected());t.setSelectedTextColor(ink());if(t instanceof JTextArea a){a.setFont(areaFont(a));if(!Boolean.TRUE.equals(a.getClientProperty("wb.font.watch"))){a.putClientProperty("wb.font.watch",true);a.getDocument().addDocumentListener(new javax.swing.event.DocumentListener(){void update(){SwingUtilities.invokeLater(()->a.setFont(areaFont(a)));}public void insertUpdate(javax.swing.event.DocumentEvent e){update();}public void removeUpdate(javax.swing.event.DocumentEvent e){update();}public void changedUpdate(javax.swing.event.DocumentEvent e){update();}});}a.setTabSize(2);a.setMargin(new Insets(8,10,8,10));if(Boolean.TRUE.equals(a.getClientProperty("wb.packet.syntax")))kr.packetui.PacketStyle.install(a);}else if(t instanceof JTextField field){ApprovedInputs.text(field);}else {t.setMargin(new Insets(8,10,8,10));t.setBorder(kr.packetui.VisualTheme.border(6,10,6,10));}}
  if(c instanceof JComboBox<?> b){b.setFont(font().deriveFont(heading?Font.BOLD:Font.PLAIN,displaySize(size instanceof Number n?n.floatValue():12f)));if(!Boolean.TRUE.equals(b.getClientProperty("wb.approved.combo")))WorkbenchSkin.combo(b);b.setBorder(ApprovedInputs.BORDER);b.setBackground(surface());b.setMaximumRowCount(16);}
  if(c instanceof JSpinner spinner)ApprovedInputs.spinner(spinner);
  if(c instanceof JTabbedPane p){p.setFont(font().deriveFont(displaySize(12f)));if(!Boolean.TRUE.equals(p.getClientProperty("wb.hidden.tabs")))WorkbenchSkin.tabs(p);p.setBackground(background());}
  if(c instanceof JTable t){table(t);return;}
  if(c instanceof JList<?> l){l.setFixedCellHeight(displayPixels(32));l.setBackground(surface());l.setSelectionBackground(selected());l.setSelectionForeground(ink());}
  if(c instanceof JScrollBar bar)WorkbenchSkin.scroll(bar);
  if(c instanceof JSeparator separator)WorkbenchSkin.separator(separator);
  if(c instanceof JScrollPane p){p.setBorder(p.getViewport().getView() instanceof JTable&&insideCard(p)?null:BorderFactory.createLineBorder(line()));p.getViewport().setBackground(surface());}
  if(c instanceof JSplitPane p){WorkbenchSkin.split(p);p.setDividerSize(7);p.setContinuousLayout(true);p.setBorder(null);p.setBackground(background());}
  if(c instanceof JProgressBar p){p.setForeground(accent());p.setBackground(background());if(Boolean.TRUE.equals(p.getClientProperty("wb.reference.progress")))WorkbenchSkin.progress(p);}
  if(c instanceof Container p)for(Component child:p.getComponents())style(child);
  ApprovedUi.component(c);
  if(c instanceof FolderNavigation navigation)navigation.restoreAppearance();
 }
 public static void table(JTable t){boolean compact=Boolean.TRUE.equals(t.getClientProperty("wb.table.compact"))||appearanceCompact;WorkbenchSkin.table(t);t.setFont(font().deriveFont(displaySize(compact?11f:12f)));t.setRowHeight(displayPixels(t.getClientProperty("wb.approved.rowHeight") instanceof Number n?n.intValue():compact?32:35));t.setShowVerticalLines(false);t.setShowHorizontalLines(true);t.setGridColor(line());t.setIntercellSpacing(new Dimension(0,1));t.setSelectionBackground(selected());t.setSelectionForeground(ink());t.setBackground(surface());t.setForeground(ink());t.setFillsViewportHeight(!Boolean.TRUE.equals(t.getClientProperty("wb.table.floating")));t.getTableHeader().setFont(font().deriveFont(compact?Font.PLAIN:Font.BOLD,displaySize(11f)));t.getTableHeader().setBackground(raised());t.getTableHeader().setForeground(ink());t.getTableHeader().setPreferredSize(new Dimension(0,displayPixels(31)));t.getTableHeader().setReorderingAllowed(true);t.setDefaultRenderer(Object.class,new Cells());t.setDefaultRenderer(String.class,new Cells());t.setDefaultRenderer(Integer.class,new Cells());t.setDefaultRenderer(Long.class,new Cells());}
 public static void packetLayout(Component root,boolean horizontal){if(root instanceof JComponent j&&"wb.payload.root".equals(root.getName()))j.putClientProperty("wb.packet.horizontal",horizontal);if(root instanceof JComponent j&&Boolean.TRUE.equals(j.getClientProperty("wb.nativeEditor")))return;if(root instanceof PassiveScanWorkspace passive)passive.layout(horizontal);if(root instanceof JSplitPane split){if(Boolean.TRUE.equals(split.getClientProperty("wb.workflow.fixedLayout"))){for(Component child:split.getComponents())packetLayout(child,horizontal);return;}String name=split.getName();Component first=split.getLeftComponent(),second=split.getRightComponent();boolean messages=first!=null&&second!=null&&first.getName()!=null&&second.getName()!=null&&first.getName().contains("요청")&&second.getName().contains("응답");double ratio=.5;if(messages||name!=null&&name.endsWith(".messages"))split.setOrientation(horizontal?JSplitPane.HORIZONTAL_SPLIT:JSplitPane.VERTICAL_SPLIT);else if(name!=null&&name.endsWith("workspace")){split.setOrientation(horizontal?JSplitPane.VERTICAL_SPLIT:JSplitPane.HORIZONTAL_SPLIT);ratio=horizontal?(name.equals("wb.traffic.workspace")?.40:name.equals("wb.js.workspace")?.60:name.equals("wb.auth.workspace")?.32:.40):name.equals("wb.traffic.workspace")?.40:.45;}else if(name!=null&&(name.endsWith("lists")||name.equals("wb.payload.editors"))){split.setOrientation(horizontal?JSplitPane.HORIZONTAL_SPLIT:JSplitPane.VERTICAL_SPLIT);ratio=name.equals("wb.js.lists")?.60:name.equals("wb.payload.editors")?.6:name.equals("wb.payload.lists")?.55:.40;}else{if(root instanceof Container c)for(Component child:c.getComponents())packetLayout(child,horizontal);return;}configureSplit(split,ratio);}if(root instanceof Container c)for(Component child:c.getComponents())packetLayout(child,horizontal);}
 public enum Tone { SUCCESS,REDIRECT,WARNING,ERROR,ACTIVE,NEUTRAL }
 public static Tone tone(String value){String t=value==null?"":value;if(t.contains("없는 경로와 동일")||t.contains("응답 검토")||t.contains("반사 관찰"))return Tone.WARNING;java.util.regex.Matcher m=java.util.regex.Pattern.compile("^(?:HTTP\\s+)?([1-5][0-9]{2})(?:\\s*[·:].*)?$").matcher(t);if(m.matches()){int code=Integer.parseInt(m.group(1));return code>=500?Tone.ERROR:code>=400?Tone.WARNING:code>=300?Tone.REDIRECT:code>=200?Tone.SUCCESS:Tone.ACTIVE;}if(t.contains("오류")||t.contains("실패")||t.contains("중단"))return Tone.ERROR;if(t.contains("미확인")||t.contains("확인 필요")||t.contains("미검증")||t.contains("대기")||t.contains("준비")||t.contains("미지정")||t.contains("중지")||t.contains("일시정지")||t.equals("—"))return Tone.NEUTRAL;if(t.contains("검토")||t.contains("후보")||t.contains("미해결")||t.contains("제외")||t.contains("반사"))return Tone.WARNING;if(t.contains("진행")||t.contains("분석 중")||t.contains("감시 중")||t.contains("백그라운드")||t.contains("Record 중"))return Tone.ACTIVE;if(t.contains("완료")||t.contains("정적")||t.contains("확인"))return Tone.SUCCESS;return Tone.NEUTRAL;}
 public static Color toneInk(Tone tone){return switch(tone){case SUCCESS->dark()?new Color(103,213,164):new Color(11,119,82);case REDIRECT,ACTIVE->dark()?new Color(110,175,255):new Color(36,99,185);case WARNING->dark()?new Color(237,186,101):new Color(171,104,11);case ERROR->dark()?new Color(255,115,125):new Color(189,46,60);case NEUTRAL->kr.packetui.VisualTheme.muted();};}
 public static Color toneFill(Tone tone){return switch(tone){case SUCCESS->dark()?new Color(32,60,51):new Color(233,247,240);case REDIRECT,ACTIVE->dark()?new Color(38,58,87):new Color(225,237,255);case WARNING->dark()?new Color(67,55,39):new Color(255,244,222);case ERROR->dark()?new Color(82,40,48):new Color(255,226,230);case NEUTRAL->dark()?new Color(34,40,50):new Color(248,249,251);};}
 public static void engineStatuses(Component component){if(component==null)return;if(component instanceof JComponent j){if(Boolean.TRUE.equals(j.getClientProperty("wb.nativeEditor"))||Boolean.TRUE.equals(j.getClientProperty("wb.engine.statuses")))return;j.putClientProperty("wb.engine.statuses",true);}if(component instanceof JTable table){Runnable install=()->{for(int i=0;i<table.getColumnCount();i++){String name=table.getColumnName(i).toLowerCase(java.util.Locale.ROOT);if(name.contains("status")||name.contains("상태")||name.equals("code"))table.getColumnModel().getColumn(i).setCellRenderer(new Cells());}table.setRowHeight(Math.max(displayPixels(Boolean.TRUE.equals(table.getClientProperty("wb.table.compact"))||appearanceCompact?24:31),table.getRowHeight()));};install.run();table.getModel().addTableModelListener(e->{if(e.getFirstRow()==javax.swing.event.TableModelEvent.HEADER_ROW)SwingUtilities.invokeLater(install);});}if(component instanceof Container container){for(Component child:container.getComponents())engineStatuses(child);container.addContainerListener(new java.awt.event.ContainerAdapter(){public void componentAdded(java.awt.event.ContainerEvent e){SwingUtilities.invokeLater(()->engineStatuses(e.getChild()));}});}}
 public static Icon statusIcon(String value){return new Icon(){final Font f=font().deriveFont(Font.BOLD,displaySize(12f));public int getIconWidth(){return Math.max(48,new JLabel(value).getFontMetrics(f).stringWidth(value)+16);}public int getIconHeight(){return 24;}public void paintIcon(Component c,Graphics g,int x,int y){Graphics2D gg=(Graphics2D)g.create();gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);gg.setColor(toneFill(tone(value)));gg.fillRoundRect(x,y,getIconWidth(),24,9,9);gg.setFont(f);gg.setColor(toneInk(tone(value)));gg.drawString(value,x+(getIconWidth()-gg.getFontMetrics().stringWidth(value))/2,y+17);gg.dispose();}};}
 public static void status(JLabel label){if(Boolean.TRUE.equals(label.getClientProperty("wb.status")))return;label.putClientProperty("wb.status",true);label.setAlignmentX(Component.LEFT_ALIGNMENT);label.setBorder(BorderFactory.createEmptyBorder(3,0,3,0));label.setOpaque(false);label.setFont(font().deriveFont(displaySize(11f)));label.addPropertyChangeListener("text",e->statusPaint(label));statusPaint(label);}
 private static void statusPaint(JLabel label){Tone t=tone(label.getText());label.setForeground(toneInk(t));label.setBackground(toneFill(t));label.setToolTipText(label.getText());}
 static class Cells extends DefaultTableCellRenderer {
  {putClientProperty("html.disable",true);}
  private Color badge;private boolean selectedRow,firstColumn;
  void responseBadge(String label){Tone tone=tone(label);badge=toneFill(tone);setForeground(toneInk(tone));setFont(getFont().deriveFont(displaySize(11f)));setHorizontalAlignment(LEFT);}
  @Override protected void paintComponent(Graphics graphics){
   Graphics2D g=(Graphics2D)graphics.create();WorkbenchSkin.antialias(g);g.setColor(getBackground());g.fillRect(0,0,getWidth(),getHeight());
   if(badge!=null){int width=Math.min(getWidth()-12,Math.max(34,getFontMetrics(getFont()).stringWidth(getText())+16)),height=Math.min(22,getHeight()-6);g.setColor(badge);g.fillRoundRect(11,(getHeight()-height)/2,width,height,5,5);setBorder(BorderFactory.createEmptyBorder(0,19,0,3));}
   setOpaque(false);super.paintComponent(g);setOpaque(true);if(selectedRow&&firstColumn){g.setColor(accent());g.fillRect(0,0,3,getHeight());}g.dispose();
  }
  @Override public Component getTableCellRendererComponent(JTable table,Object value,boolean selection,boolean focus,int row,int column){
   super.getTableCellRendererComponent(table,value,selection,focus,row,column);badge=null;selectedRow=selection;firstColumn=column==0;
   setBorder(BorderFactory.createEmptyBorder(0,11,0,11));setFont(table.getFont());setForeground(ink());setBackground(selection?selected():surface());setHorizontalAlignment(LEFT);
   String text=value==null?"":value.toString();setToolTipText(text);String name=String.valueOf(table.getColumnModel().getColumn(column).getHeaderValue()),lower=name.toLowerCase(java.util.Locale.ROOT);
   if(name.equals("응답 시간")&&value instanceof Number)setText(text+" ms");
   if(name.equals("유형")&&table.getClientProperty("wb.approved.evidence.types") instanceof java.util.function.IntFunction<?> source){setText(String.valueOf(source.apply(table.convertRowIndexToModel(row))));}
   if(lower.equals("cvss")&&text.matches("[0-9]+(?:\\.[0-9]+)?")){double score=Double.parseDouble(text);Tone severity=score>=9?Tone.ERROR:score>=7?Tone.WARNING:Tone.NEUTRAL;badge=toneFill(severity);setForeground(toneInk(severity));setFont(table.getFont().deriveFont(displaySize(11f)));}
   boolean method=name.contains("메서드")||lower.equals("method");boolean state=!method&&(name.contains("상태")||lower.contains("status")||lower.equals("code")||lower.equals("http")||name.endsWith("판정")||name.equals("조회 결과")||name.equals("원본")||name.equals("비교")||name.equals("관측 결과"));
   if(state&&!text.equals("미검증")&&!text.equals("미실행")&&!text.equals("기준 응답")&&!text.equals("대조 응답")){Tone tone=tone(text);badge=toneFill(tone);setForeground(toneInk(tone));setFont(table.getFont().deriveFont(displaySize(11f)));if(text.matches("HTTP [1-5][0-9]{2}"))setText(text.substring(5));}
   if(Boolean.TRUE.equals(table.getClientProperty("wb.table.flat"))&&!text.matches("(?:HTTP )?[1-5][0-9]{2}.*"))badge=null;
   if((name.contains("URL")||name.contains("경로"))&&text.startsWith("http"))try{var uri=java.net.URI.create(text);setText(uri.getRawPath()+(uri.getRawQuery()==null?"":"?"+uri.getRawQuery()));}catch(IllegalArgumentException ignored){}
   return this;
  }
 }
 /** Wrapping action rows report their real height, avoiding hidden buttons at small widths. */
 public static final class WrapLayout extends FlowLayout {
  private int lastWidth=-1,lastHeight=-1;
  public WrapLayout(int align,int h,int v){super(align,h,v);}
  @Override public void layoutContainer(Container target){super.layoutContainer(target);int h=preferredLayoutSize(target).height;if(target.getWidth()!=lastWidth||h!=lastHeight){lastWidth=target.getWidth();lastHeight=h;target.setMaximumSize(new Dimension(Integer.MAX_VALUE,h));SwingUtilities.invokeLater(()->{Container parent=target.getParent();if(parent instanceof JComponent j)j.revalidate();});}}
  @Override public Dimension preferredLayoutSize(Container target){return size(target,false);}
  @Override public Dimension minimumLayoutSize(Container target){Dimension d=size(target,true);d.width=100;return d;}
  private Dimension size(Container target,boolean min){synchronized(target.getTreeLock()){int width=target.getWidth();Container ancestor=target;while(width<=0&&ancestor.getParent()!=null){ancestor=ancestor.getParent();width=ancestor.getWidth();}if(width<=0)width=1280;Insets in=target.getInsets();int available=Math.max(100,width-in.left-in.right-2*getHgap()),x=0,y=0,height=0,max=0;for(Component c:target.getComponents()){if(!c.isVisible())continue;Dimension d=min?c.getMinimumSize():c.getPreferredSize();int gap=x==0?0:getHgap();if(x>0&&x+gap+d.width>available){max=Math.max(max,x);y+=height+getVgap();x=0;height=0;gap=0;}x+=gap+d.width;height=Math.max(height,d.height);}max=Math.max(max,x);return new Dimension(max+in.left+in.right+2*getHgap(),y+height+in.top+in.bottom+2*getVgap());}}
 }
}
