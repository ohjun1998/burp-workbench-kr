package kr.workbench;

import burp.api.montoya.MontoyaApi;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Path2D;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.*;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import javax.swing.plaf.basic.BasicTreeUI;
import javax.swing.tree.*;

/** Folder navigation over the existing page instances and their shared selection model. */
final class FolderNavigation extends JPanel implements AutoCloseable {
  private static final int DEFAULT_WIDTH = 190;
  private static final int NARROW_WIDTH = 174;
  private static final int MIN_WIDTH = 160;
  private static final int MAX_WIDTH = 420;
  private final MontoyaApi api;
  private final JTabbedPane pages;
  private final boolean classic;
  private final Map<String, DefaultMutableTreeNode> tools = new LinkedHashMap<>();
  private final JTree tree;
  private final TreeCellRenderer renderer = new NavigationRenderer();
  private final JScrollPane sidebar;
  private CompactPrimaryNavigation primaryNavigation;
  private final JSplitPane split;
  private final JButton toggle = new JButton();
  private final JLabel current = new JLabel();
  private JPanel trafficHeader, standardHeaderActions, headerLine, trafficFooter;
  private JButton themeToggle;
  private Runnable themeAction = () -> {};
  private final JLabel breadcrumb = new JLabel();
  private final JButton back = new JButton("←"), forward = new JButton("→"), quick = new JButton("기능 찾기");
  private final NavigationViewState.ModelVersions modelVersions = new NavigationViewState.ModelVersions();
  private final List<Visit> visits = new ArrayList<>();
  private final List<String> recent = new ArrayList<>();
  private final TargetWindow quickWindow;
  private QuickNavigationPanel quickPanel;
  private Consumer<String> routeOpener = this::openLocalRoute;
  private Supplier<String> routeProvider = this::selectedRoute, projectProvider = () -> "";
  private Function<String, Object> captureExtra = route -> null;
  private Consumer<Object> restoreExtra = state -> {};
  private String historyProject = "";
  private int visitIndex = -1;
  private long historyGeneration;
  private boolean changingHistory, recordPending, closed;
  private static final int HISTORY_LIMIT = 24, RECENT_LIMIT = 8;
  private static final class Visit {
    final String route;
    NavigationViewState view;
    Object extra;
    Visit(String route, NavigationViewState view, Object extra) { this.route = route; this.view = view; this.extra = extra; }
  }
  private int menuWidth = DEFAULT_WIDTH;
  private boolean customMenuWidth;
  private boolean hidden;
  private boolean adjusting;
  private boolean synchronizing;

  /** Keep the established page API for context actions, help and engine integrations, without tabs. */
  static class Pages extends JTabbedPane {
    @Override
    public void updateUI() {
      setUI(new BasicTabbedPaneUI() {
        @Override protected int calculateTabAreaHeight(int placement, int runs, int maximum) { return 0; }
        @Override protected int calculateTabAreaWidth(int placement, int runs, int maximum) { return 0; }
        @Override protected Insets getContentBorderInsets(int placement) { return new Insets(0, 0, 0, 0); }
        @Override protected void paintTabArea(Graphics graphics, int placement, int selected) {}
        @Override protected void paintContentBorder(Graphics graphics, int placement, int selected) {}
      });
    }

    @Override
    public void setTabLayoutPolicy(int policy) {
      // There is no tab strip to scroll; avoid invisible tab-scroll buttons taking focus.
      super.setTabLayoutPolicy(WRAP_TAB_LAYOUT);
    }
  }

  FolderNavigation(MontoyaApi api, JTabbedPane pages, Runnable openSettings) {
    this(api, pages, openSettings, null, null);
  }

  FolderNavigation(MontoyaApi api, JTabbedPane pages, Runnable openSettings, JButton help, JButton logs) {
    this(api, pages, openSettings, help, logs, false);
  }

  FolderNavigation(MontoyaApi api, JTabbedPane pages, Runnable openSettings, JButton help, JButton logs,
      boolean classic, AbstractButton... shortcuts) {
    super(new BorderLayout(0, 0));
    this.api = api;
    this.pages = pages;
    this.classic = classic;
    quickWindow = new TargetWindow(this, "기능 바로 찾기 · Ctrl+K", this::quickPanel);
    setName("wb.navigation");
    pages.setName("wb.navigation.pages");
    pages.setMinimumSize(new Dimension(360, 100));
    try {
      String width = read("width");
      if (width != null) {
        menuWidth = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, Integer.parseInt(width)));
        customMenuWidth = true;
      }
    } catch (NumberFormatException ignored) {}
    hidden = Boolean.parseBoolean(read("hidden"));

    AbstractButton inspectionShortcut = shortcut(shortcuts, "wb.scope.inspection.open");
    AbstractButton dashboardShortcut = shortcut(shortcuts, "wb.simple.dashboard.open");
    boolean promoted = classic && inspectionShortcut != null && dashboardShortcut != null;
    DefaultMutableTreeNode root = new DefaultMutableTreeNode("도구");
    folder(root, "트래픽", "traffic", "mapper");
    if (classic) folder(root, "탐색·정보 수집", "js", "environment", "exposure");
    else folder(root, "탐색·정보 수집", "js", "environment", "exposure");
    folder(root, "보안 분석·검증", "auth", "response.recon", "payload");
    if (classic) {
      folder(root, "데이터 도구", "data");
      if (promoted) folder(root, "점검 관리·증거", "activity", "bounty");
      else folder(root, "점검 관리·증거", "activity", "bounty", "dashboard");
    } else folder(root, "점검 관리·증거", "bounty");
    tree = new NavigationTree(root);
    tree.setName("wb.navigation.tree");
    tree.setRootVisible(false);
    tree.setShowsRootHandles(false);
    tree.setRowHeight(0);
    tree.setToggleClickCount(1);
    tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
    tree.getAccessibleContext().setAccessibleName("기능 폴더 목록");
    tree.setToolTipText("폴더를 펼쳐 기능 선택 · 방향키로 이동 · 선택만으로 검사를 실행하지 않습니다.");
    tree.setCellRenderer(renderer);
    /* Renderer labels stay transparent so the selected background spans the whole row. */
    for (int row = 0; row < tree.getRowCount(); row++) tree.expandRow(row);
    tree.addTreeSelectionListener(event -> {
      if (synchronizing) return;
      Object chosen = tree.getLastSelectedPathComponent();
      if (chosen instanceof DefaultMutableTreeNode node && node.getUserObject() instanceof Tool tool) {
        int index = indexOf(tool.id());
        if (index >= 0) navigate(tool.id());
      }
      tree.repaint();
    });
    sidebar = new JScrollPane(tree);
    sidebar.setName("wb.navigation.sidebar");
    sidebar.setMinimumSize(new Dimension(MIN_WIDTH, 80));sidebar.setBorder(null);
    if (promoted) {
      primaryNavigation = new CompactPrimaryNavigation(inspectionShortcut, dashboardShortcut);
      sidebar.setColumnHeaderView(primaryNavigation);
      sidebar.getColumnHeader().setName("wb.navigation.primary.viewport");
    }
    sidebar.setPreferredSize(new Dimension(menuWidth, 400));
    split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sidebar, pages);
    split.setName("wb.navigation.split");
    split.setContinuousLayout(true);
    split.setResizeWeight(0);
    split.setBorder(null);
    split.setDividerSize(7);
    split.addPropertyChangeListener(JSplitPane.DIVIDER_LOCATION_PROPERTY, event -> {
      if (adjusting || hidden || split.getWidth() <= 0) return;
      customMenuWidth = true;
      menuWidth = constrained(split.getDividerLocation());
      write("width", Integer.toString(menuWidth));
      constrainDivider();
    });
    split.addComponentListener(new ComponentAdapter() {
      @Override public void componentResized(ComponentEvent event) { constrainDivider(); }
    });
    toggle.setName("wb.navigation.toggle");toggle.setIcon(WorkspaceIcons.of("menu"));toggle.putClientProperty("wb.segment.button",true);toggle.setPreferredSize(new Dimension(30,30));toggle.setMinimumSize(new Dimension(30,30));toggle.setMaximumSize(new Dimension(30,30));toggle.putClientProperty("wb.compact.button",true);
    toggle.addActionListener(event -> setMenuHidden(!hidden));
    back.setName("wb.navigation.back"); forward.setName("wb.navigation.forward");
    quick.setName("wb.navigation.quick");
    back.setToolTipText("이전 작업 화면 · Alt+←"); forward.setToolTipText("다음 작업 화면 · Alt+→");
    quick.setToolTipText("기능 이름이나 목적으로 찾기 · Ctrl+K");
    back.getAccessibleContext().setAccessibleName("이전 작업 화면");
    forward.getAccessibleContext().setAccessibleName("다음 작업 화면");
    back.addActionListener(e -> goBack()); forward.addActionListener(e -> goForward());
    quick.addActionListener(e -> openQuickNavigation());
    current.setName("wb.navigation.current");
    current.setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 6));
    current.putClientProperty("wb.font.size", 12);
    breadcrumb.setName("wb.navigation.breadcrumb");
    breadcrumb.putClientProperty("wb.font.size", 12);
    breadcrumb.putClientProperty("wb.secondary", true);
    JButton settings = new JButton("설정");
    settings.setName("wb.navigation.settings");
    settings.setToolTipText(BuildInfo.PRODUCT_NAME + " " + BuildInfo.VERSION + " · 화면 설정");
    settings.addActionListener(event -> openSettings.run());
    JLabel version = new JLabel("SIMPLE " + BuildInfo.VERSION);
    version.setName("wb.next.version");
    version.setFont(WorkbenchUi.font().deriveFont(Font.BOLD, WorkbenchUi.displaySize(13f)));
    version.setForeground(WorkbenchUi.accent());
    version.setToolTipText(BuildInfo.PRODUCT_NAME + " " + BuildInfo.VERSION);
    JPanel navigationLine = new JPanel(new BorderLayout(8, 0));
    navigationLine.setName("wb.navigation.toolbar.line");
    navigationLine.putClientProperty("wb.surface", classic);
    JPanel navigationControls = new JPanel();
    navigationControls.putClientProperty("wb.surface", classic);
    navigationControls.setLayout(new BoxLayout(navigationControls, BoxLayout.X_AXIS));
    navigationControls.setBorder(classic ? BorderFactory.createEmptyBorder()
        : BorderFactory.createEmptyBorder(5, 8, 5, 8));
    Component[] navigationButtons = classic ? new Component[] {toggle}
        : new Component[] {toggle, version, back, forward, quick};
    for (Component control : navigationButtons) {
      if (navigationControls.getComponentCount() > 0) navigationControls.add(Box.createHorizontalStrut(8));
      navigationControls.add(control);
    }

    if (classic) {
      JLabel brand = new JLabel("Workbench", new BrandMark(), SwingConstants.LEADING);
      brand.setName("wb.navigation.brand");
      brand.setIconTextGap(7);
      brand.putClientProperty("wb.font.size", 15);
      brand.putClientProperty("wb.font.heading", true);
      brand.setToolTipText(BuildInfo.PRODUCT_NAME + " " + BuildInfo.VERSION);
      navigationControls.add(Box.createHorizontalStrut(7));
      navigationControls.add(brand);
      navigationControls.setPreferredSize(new Dimension(DEFAULT_WIDTH - 12, 38));
    }

    navigationLine.add(navigationControls, BorderLayout.WEST);
    JPanel location = new JPanel(new BorderLayout());
    location.setName("wb.navigation.location");
    location.putClientProperty("wb.surface", classic);
    if (classic) location.add(breadcrumb, BorderLayout.WEST);
    location.add(current, BorderLayout.CENTER);
    navigationLine.add(location, BorderLayout.CENTER);
    JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 3, 1));
    actions.setName("wb.navigation.actions");
    actions.putClientProperty("wb.surface", classic);
    AbstractButton guideButton=null;
    for (AbstractButton shortcut : shortcuts) if (shortcut != null) {
      if(Boolean.TRUE.equals(shortcut.getClientProperty("wb.guide.button"))){guideButton=shortcut;continue;}
      if(classic)compactAction(shortcut, shortcut.getName()!=null&&shortcut.getName().contains("fullscreen")?"fullscreen":shortcut.getText().contains("Scope")?"target":"dashboard",shortcut.getText());
      actions.add(shortcut);
    }
    if (help != null) {if(classic)compactAction(help,"help","도움말");actions.add(help);}
    if(classic)compactAction(settings,"gear","화면 설정");
    actions.add(settings);
    if (logs != null) {if(classic)compactAction(logs,"logs","오류 기록");actions.add(logs);}
    if(guideButton!=null){guideButton.setPreferredSize(new Dimension(66,30));guideButton.setMinimumSize(new Dimension(66,30));guideButton.setMaximumSize(new Dimension(66,30));actions.add(guideButton);}
    for(Component c:actions.getComponents())if(c instanceof AbstractButton b)b.putClientProperty("wb.segment.button",true);
    standardHeaderActions=actions;headerLine=navigationLine;
    trafficHeader=new JPanel(new FlowLayout(FlowLayout.RIGHT,12,4));trafficHeader.putClientProperty("wb.surface",true);
    JLabel projectCaption=new JLabel("웹 애플리케이션 점검");projectCaption.putClientProperty("wb.font.size",11);projectCaption.putClientProperty("wb.secondary",true);trafficHeader.add(projectCaption);
    themeToggle=new JButton();themeToggle.setName("wb.traffic.header.tools");themeToggle.setPreferredSize(new Dimension(28,28));themeToggle.putClientProperty("wb.segment.button",true);themeToggle.addActionListener(e->{if(!closed)themeAction.run();});trafficHeader.add(themeToggle);
    JPopupMenu toolsMenu=new JPopupMenu();toolsMenu.setName("wb.navigation.tools.popup");for(Component c:actions.getComponents())if(c instanceof AbstractButton action)toolsMenu.add(WorkflowUi.proxy(action));
    JButton toolsButton=new JButton(WorkspaceIcons.of("gear"));toolsButton.setName("wb.navigation.tools.open");toolsButton.setPreferredSize(new Dimension(28,28));toolsButton.putClientProperty("wb.segment.button",true);toolsButton.setToolTipText("설정 및 창 도구");toolsButton.getAccessibleContext().setAccessibleName("설정 및 창 도구");toolsButton.setComponentPopupMenu(toolsMenu);toolsButton.addActionListener(e->{WorkbenchUi.style(toolsMenu);toolsMenu.show(toolsButton,toolsButton.getWidth()-toolsMenu.getPreferredSize().width,toolsButton.getHeight());});trafficHeader.add(toolsButton);
    AbstractButton originalGuide=guideButton;JButton explain=new JButton("화면 설명");explain.setName("wb.traffic.guide.open");explain.putClientProperty("wb.segment.button",true);explain.addActionListener(e->{if(originalGuide!=null)originalGuide.doClick(0);else if(help!=null)help.doClick(0);});trafficHeader.add(explain);
    navigationLine.add(actions, BorderLayout.EAST);
    JPanel toolbar = new ResponsiveToolbar(navigationLine, classic);
    add(toolbar, BorderLayout.NORTH);
    trafficFooter=new JPanel(new BorderLayout());trafficFooter.setPreferredSize(new Dimension(0,20));
    trafficFooter.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(1,0,0,0,WorkbenchUi.line()),BorderFactory.createEmptyBorder(0,206,0,16)));
    JLabel footerVersion=new JLabel(BuildInfo.PRODUCT_NAME + " "+BuildInfo.VERSION),footerView=new JLabel("요청·응답 목록 · 라이트");
    for(JLabel label:new JLabel[]{footerVersion,footerView}){label.putClientProperty("wb.font.size",9);label.putClientProperty("wb.secondary",true);}
    footerView.putClientProperty("wb.traffic.footer",true);trafficFooter.add(footerVersion);trafficFooter.add(footerView,BorderLayout.EAST);add(trafficFooter,BorderLayout.SOUTH);
    add(split, BorderLayout.CENTER);
    getInputMap(WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(
        KeyStroke.getKeyStroke("control shift M"), "toggleMenu");
    getActionMap().put("toggleMenu", new AbstractAction() {
      public void actionPerformed(ActionEvent event) { setMenuHidden(!hidden); }
    });
    bindNavigation("control K", "quickNavigation", this::openQuickNavigation);
    bindNavigation("alt LEFT", "navigationBack", this::goBack);
    bindNavigation("alt RIGHT", "navigationForward", this::goForward);
    if (classic) {
      String[] retained = {"traffic", "mapper", "auth", "js", "environment", "response.recon", "payload", "bounty"};
      for (int i = 0; i < retained.length; i++) {
        String id = retained[i];
        bindNavigation("alt " + (i + 1), "classic.tool." + id, () -> navigate(id));
      }
    }
    pages.addChangeListener(event -> { refreshSelection(); navigationChanged(); });
    refreshSelection();
    updateHistoryActions();
  }

  private static AbstractButton shortcut(AbstractButton[] shortcuts, String name) {
    for (AbstractButton shortcut : shortcuts)
      if (shortcut != null && name.equals(shortcut.getName())) return shortcut;
    return null;
  }

  private static void compactAction(AbstractButton button,String icon,String accessible) {
    String tip=button.getToolTipText();
    button.setIcon(WorkspaceIcons.of(icon));button.setText("");
    button.getAccessibleContext().setAccessibleName(accessible);
    if(tip==null||tip.isBlank())button.setToolTipText(accessible);
    button.putClientProperty("wb.compact.button",true);
    button.setPreferredSize(new Dimension(30,30));button.setMinimumSize(new Dimension(30,30));button.setMaximumSize(new Dimension(30,30));
    button.addPropertyChangeListener("text",event->{String next=button.getText();if(next!=null&&!next.isEmpty()){button.getAccessibleContext().setAccessibleName(next);button.setText("");}});
  }

  void setThemeAction(Runnable action) { themeAction=Objects.requireNonNull(action);restoreAppearance(); }

  /** Route callbacks only open retained UI components; the host must not execute network actions. */
  void configureRoutes(Consumer<String> opener, Supplier<String> currentRoute, Supplier<String> projectIdentity) {
    routeOpener = Objects.requireNonNull(opener); routeProvider = Objects.requireNonNull(currentRoute);
    projectProvider = Objects.requireNonNull(projectIdentity); resetHistory();
  }

  /** Additional in-memory traffic query/original-ID checkpoint; never serialized by navigation. */
  void setViewStateHooks(Supplier<Object> capture, Consumer<Object> restore) {
    Objects.requireNonNull(capture); setViewStateHooks(route -> capture.get(), restore);
  }
  /** A page-change event is delivered after selection changed, so capture uses the bookmarked route. */
  void setViewStateHooks(Function<String, Object> capture, Consumer<Object> restore) {
    captureExtra = Objects.requireNonNull(capture); restoreExtra = Objects.requireNonNull(restore);
    if (visitIndex >= 0) visits.get(visitIndex).extra = captureExtra.apply(visits.get(visitIndex).route);
  }

  /** The host calls this after changes in nested work tabs, using the same event coalescing as pages. */
  void navigationChanged() {
    if (closed || changingHistory) return;
    refreshSelection();
    ensureProject(); captureCurrent();
    if (recordPending) return;
    recordPending = true;
    long token = historyGeneration;
    SwingUtilities.invokeLater(() -> {
      if (token != historyGeneration) return;
      recordPending = false;
      if (!closed && !changingHistory) recordDestination(currentRoute());
    });
  }

  void navigate(String route) {
    if (closed || NavigationTargets.target(route) == null) return;
    ensureProject(); captureCurrent(); historyGeneration++; recordPending = false; changingHistory = true;
    try { routeOpener.accept(route); }
    finally { changingHistory = false; }
    String actualRoute = currentRoute();
    recordDestination(NavigationTargets.target(actualRoute) == null ? route : actualRoute); refreshSelection();
  }

  void goBack() { moveHistory(-1); }
  void goForward() { moveHistory(1); }
  boolean canGoBack() { ensureProject(); return visitIndex > 0; }
  boolean canGoForward() { ensureProject(); return visitIndex >= 0 && visitIndex + 1 < visits.size(); }
  List<String> recentRoutes() { ensureProject(); return List.copyOf(recent); }

  private void moveHistory(int direction) {
    if (closed) return;
    ensureProject(); int next = visitIndex + direction;
    if (next < 0 || next >= visits.size() || historyProject.isBlank()) return;
    captureCurrent(); Visit visit = visits.get(next); String expectedProject = historyProject;
    long token = ++historyGeneration; recordPending = false; changingHistory = true;
    try {
      routeOpener.accept(visit.route);
      if (!expectedProject.equals(currentProject())) { resetHistory(); return; }
      if (visit.extra != null) restoreExtra.accept(visit.extra);
      visit.view.restore(modelVersions); visitIndex = next;
      rememberRecent(visit.route); refreshSelection();
    } finally { changingHistory = false; updateHistoryActions(); }
    SwingUtilities.invokeLater(() -> {
      if (!closed && token == historyGeneration && expectedProject.equals(currentProject())
          && visitIndex >= 0 && visits.get(visitIndex) == visit) visit.view.restoreScrolls();
    });
  }

  private void captureCurrent() {
    if (visitIndex < 0 || visitIndex >= visits.size()) return;
    Visit currentVisit = visits.get(visitIndex);
    currentVisit.view = currentVisit.view.refresh(modelVersions); currentVisit.extra = captureExtra.apply(currentVisit.route);
  }

  private void recordDestination(String route) {
    ensureProject();
    if (closed || historyProject.isBlank() || NavigationTargets.target(route) == null
        || pages.getSelectedComponent() == null) { updateHistoryActions(); return; }
    NavigationViewState view = NavigationViewState.capture(pages.getSelectedComponent(), modelVersions);
    if (visitIndex >= 0 && visits.get(visitIndex).route.equals(route) && visits.get(visitIndex).view.sameTabs(view)) {
      visits.get(visitIndex).view = view; visits.get(visitIndex).extra = captureExtra.apply(route);
    } else {
      while (visits.size() > visitIndex + 1) visits.remove(visits.size() - 1);
      visits.add(new Visit(route, view, captureExtra.apply(route)));
      if (visits.size() > HISTORY_LIMIT) visits.remove(0);
      visitIndex = visits.size() - 1;
    }
    rememberRecent(route); updateHistoryActions();
  }

  private void rememberRecent(String route) {
    recent.remove(route); recent.add(0, route);
    if (recent.size() > RECENT_LIMIT) recent.remove(recent.size() - 1);
  }

  void resetHistory() {
    historyGeneration++; recordPending = false; visits.clear(); recent.clear(); visitIndex = -1;
    historyProject = currentProject();
    modelVersions.close(); quickWindow.closeWindow(); if (quickPanel != null) quickPanel.reset();
    if (!closed && !changingHistory && !historyProject.isBlank() && pages.getSelectedComponent() != null)
      recordDestination(currentRoute());
    updateHistoryActions();
  }

  private void ensureProject() {
    if (!historyProject.equals(currentProject())) {
      historyGeneration++; recordPending = false; visits.clear(); recent.clear(); visitIndex = -1;
      historyProject = currentProject();
      modelVersions.close(); quickWindow.closeWindow();
      // This guard can run from the palette's DocumentListener. Reset outside that notification.
      long token = historyGeneration;
      if (quickPanel != null) SwingUtilities.invokeLater(() -> {
        if (token == historyGeneration && quickPanel != null) quickPanel.reset();
      });
      updateHistoryActions();
    }
  }

  private String currentProject() {
    try { return Objects.toString(projectProvider.get(), ""); }
    catch (RuntimeException error) { return ""; }
  }
  private String currentRoute() {
    try { return Objects.toString(routeProvider.get(), ""); }
    catch (RuntimeException error) { return ""; }
  }
  private String selectedRoute() {
    return pages.getSelectedComponent() instanceof JComponent page
        ? Objects.toString(page.getClientProperty("wb.feature.id"), "") : "";
  }
  private void openLocalRoute(String route) {
    String primary = switch (route) {
      case "data", "jwt" -> "traffic";
      case "passive" -> "environment";
      case "activity" -> "mapper";
      case "evidence" -> "bounty";
      default -> route;
    };
    int index = indexOf(primary); if (index >= 0) pages.setSelectedIndex(index);
  }
  private void updateHistoryActions() {
    back.setEnabled(!closed && visitIndex > 0);
    forward.setEnabled(!closed && visitIndex >= 0 && visitIndex + 1 < visits.size());
  }
  QuickNavigationPanel quickPanel() {
    if (quickPanel == null) quickPanel = new QuickNavigationPanel(this::recentRoutes, this::navigate, () -> {
      quickWindow.closeWindow(); if (quickPanel != null) quickPanel.reset();
    });
    return quickPanel;
  }
  void openQuickNavigation() {
    if (closed) return;
    ensureProject(); quickPanel().reset(); quickWindow.open();
    SwingUtilities.invokeLater(() -> { if (quickPanel != null && quickPanel.isShowing()) quickPanel.query.requestFocusInWindow(); });
  }
  void setQuickWindowOpener(WorkbenchExtension.DialogOpener opener) { quickWindow.opener = Objects.requireNonNull(opener); }
  private void bindNavigation(String key, String name, Runnable action) {
    getInputMap(WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(KeyStroke.getKeyStroke(key), name);
    getActionMap().put(name, new AbstractAction() {
      public void actionPerformed(ActionEvent event) { action.run(); }
    });
  }
  public void close() { closed = true; resetHistory(); quickWindow.close(); if(primaryNavigation!=null)primaryNavigation.close(); }

  /** Relayout is synchronous so a small window never needs a resize-event round trip to expose actions. */
  private static final class ResponsiveToolbar extends JPanel {
    private final int height;
    ResponsiveToolbar(JPanel line, boolean classic) {
      super(new BorderLayout());setName("wb.navigation.toolbar");
      height = classic ? 46 : 36;
      putClientProperty("wb.surface", classic);
      setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0,0,1,0,WorkbenchUi.line()),BorderFactory.createEmptyBorder(0,5,0,6)));
      add(line,BorderLayout.CENTER);
    }
    @Override public Dimension getPreferredSize(){Dimension d=super.getPreferredSize();return new Dimension(d.width,height);}
    @Override public Dimension getMinimumSize(){return new Dimension(300,height);}
  }

  private static final class BrandMark implements Icon {
    public int getIconWidth() { return 15; }
    public int getIconHeight() { return 15; }
    public void paintIcon(Component owner, Graphics graphics, int x, int y) {
      Graphics2D g = (Graphics2D) graphics.create();
      WorkbenchSkin.antialias(g);
      if(owner instanceof JComponent c&&Boolean.TRUE.equals(c.getClientProperty("wb.traffic.brand"))){g.setColor(WorkbenchUi.selected());g.fillRoundRect(x+5,y+4,15,15,8,8);}
      g.setColor(WorkbenchUi.accent());
      g.fillRoundRect(x, y, 15, 15, 8, 8);
      g.dispose();
    }
  }

  private boolean active(Object value) {
    if (!(value instanceof DefaultMutableTreeNode node)
        || !(node.getUserObject() instanceof Tool tool)) return false;
    return tool.id().equals(selectedToolId());
  }

  /** Local UI delegate and vector icons avoid OS-dependent folders and tree guide lines. */
  private final class NavigationTree extends JTree {
    @Override public boolean getScrollableTracksViewportWidth(){return classic||super.getScrollableTracksViewportWidth();}
    @Override public void scrollRectToVisible(Rectangle rectangle) {
      if (classic && getParent() instanceof JViewport viewport) {
        // The classic menu tracks its viewport width. An oversized renderer's preferred
        // rectangle must not scroll the tree and its fixed column header sideways.
        Rectangle vertical = new Rectangle(rectangle);
        vertical.x = 0;
        vertical.width = Math.min(Math.max(0, rectangle.width), Math.max(0, viewport.getExtentSize().width));
        super.scrollRectToVisible(vertical);
      } else super.scrollRectToVisible(rectangle);
    }
    private int hovered = -1;

    NavigationTree(TreeNode root) {
      super(root);
      setOpaque(false);
      setBorder(BorderFactory.createEmptyBorder(4, 9, 6, 0));
      addComponentListener(new ComponentAdapter(){public void componentResized(ComponentEvent e){treeDidChange();}});
      addMouseMotionListener(new MouseMotionAdapter() {
        @Override public void mouseMoved(MouseEvent event) {
          int row = rowAt(event);
          if (hovered != row) { hovered = row; repaint(); }
        }
      });
      addMouseListener(new MouseAdapter() {
        @Override public void mouseExited(MouseEvent event) { hovered = -1; repaint(); }
      });
      addFocusListener(new FocusAdapter() {
        @Override public void focusGained(FocusEvent event) { repaint(); }
        @Override public void focusLost(FocusEvent event) { repaint(); }
      });
    }

    @Override public void updateUI() {
      setUI(new BasicTreeUI() {
        @Override protected void installDefaults() {
          super.installDefaults();
          setLeftChildIndent(8);
          setRightChildIndent(10);
          setExpandedIcon(new NavigationIcon(IconKind.DOWN));
          setCollapsedIcon(new NavigationIcon(IconKind.RIGHT));
        }
        @Override protected void paintHorizontalLine(Graphics g, JComponent c, int y, int left, int right) {}
        @Override protected void paintVerticalLine(Graphics g, JComponent c, int x, int top, int bottom) {}
      });
    }

    @Override public String getToolTipText(MouseEvent event){int row=rowAt(event);if(row<0)return null;Object value=getPathForRow(row).getLastPathComponent();if(value instanceof DefaultMutableTreeNode node&&node.getUserObject() instanceof Tool tool)return FeatureGuide.feature(tool.id()).summary();return value.toString()+" · 펼치기/접기";}

    private int rowAt(MouseEvent event) {
      int row = getClosestRowForLocation(event.getX(), event.getY());
      Rectangle bounds = row < 0 ? null : getRowBounds(row);
      return bounds != null && event.getY() >= bounds.y && event.getY() < bounds.y + bounds.height ? row : -1;
    }

    @Override protected void processMouseEvent(MouseEvent event) {
      // Make the highlighted blank part of a row clickable too; leave chevrons to BasicTreeUI.
      int row = rowAt(event);
      Rectangle bounds = row < 0 ? null : getRowBounds(row);
      if (event.getID() == MouseEvent.MOUSE_PRESSED && SwingUtilities.isLeftMouseButton(event)
          && bounds != null && event.getX() >= bounds.x + bounds.width) {
        requestFocusInWindow();
        TreePath path = getPathForRow(row);
        setSelectionPath(path);
        if (!getModel().isLeaf(path.getLastPathComponent())) {
          if (isExpanded(path)) collapsePath(path); else expandPath(path);
        }
        event.consume();
        return;
      }
      super.processMouseEvent(event);
    }

    @Override protected void paintComponent(Graphics graphics) {
      Graphics2D g = (Graphics2D) graphics.create();
      if (classic) {
        g.setColor(kr.packetui.VisualTheme.sidebar());
        g.fillRect(0,0,getWidth(),getHeight());
      } else kr.packetui.VisualTheme.wash(g,getWidth(),getHeight(),kr.packetui.VisualTheme.sidebar(),WorkbenchUi.background());
      g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      Rectangle clip = g.getClipBounds();
      for (int row = 0; row < getRowCount(); row++) {
        Rectangle bounds = getRowBounds(row);
        if (bounds == null || clip != null && !clip.intersects(0, bounds.y, getWidth(), bounds.height)) continue;
        boolean currentTool = active(getPathForRow(row).getLastPathComponent());
        if (currentTool || isRowSelected(row) || row == hovered) {
          g.setColor(currentTool ? WorkbenchUi.selected() : kr.packetui.VisualTheme.hover());
          boolean exact=classic&&approvedShell();
          g.fillRoundRect(exact?9:4, bounds.y + (exact?1:2), getWidth()-(exact?18:8),bounds.height-(exact?2:4),8,8);
          if (currentTool && !(classic&&approvedShell())) {
            g.setColor(WorkbenchUi.accent());
            g.fillRect(4, bounds.y + 2, 3, bounds.height - 4);
          }
        }
      }
      g.dispose();
      super.paintComponent(graphics);
      if(classic&&approvedShell()&&getRowCount()>0){Rectangle last=getRowBounds(getRowCount()-1);if(last!=null&&getHeight()>=last.y+last.height+76){
        g=(Graphics2D)graphics.create();WorkbenchSkin.antialias(g);int y=last.y+last.height+18;g.setColor(WorkbenchUi.line());g.drawLine(9,y,getWidth()-10,y);
        Component context=ApprovedTrafficPanel.named(pages,"wb.traffic.target");String target=context instanceof JComboBox<?> box?Objects.toString(box.getSelectedItem(),""):"";
        g.setFont(WorkbenchUi.font().deriveFont(10f));g.setColor(WorkbenchUi.ink());g.drawString(target,18,y+26);g.setColor(kr.packetui.VisualTheme.muted());g.drawString("현재 프로젝트 · "+(WorkbenchScope.registeredRules(api).isEmpty()?"수집 범위 미설정":"수집 범위 설정됨"),18,y+44);g.dispose();
      }}
      if (hasFocus() && getLeadSelectionPath() != null) {
        Rectangle bounds = getPathBounds(getLeadSelectionPath());
        if (bounds != null) {
          g = (Graphics2D) graphics.create();
          g.setColor(WorkbenchUi.accent());
          g.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10, new float[] {2, 2}, 0));
          g.drawRoundRect(8, bounds.y + 4, getWidth() - 17, bounds.height - 9, 5, 5);
          g.dispose();
        }
      }
    }
  }

  private final class NavigationRenderer extends JLabel implements TreeCellRenderer {
    @Override public void updateUI() { setUI(new javax.swing.plaf.basic.BasicLabelUI()); }
    @Override public Dimension getPreferredSize(){Dimension d=super.getPreferredSize();d.width=Math.max(getIcon()==null?140:165,d.width);return d;}
    NavigationRenderer() {
      setOpaque(false);
      setIconTextGap(8);
      setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 8));
    }

    @Override
    public Component getTreeCellRendererComponent(JTree owner, Object value, boolean selected,
        boolean expanded, boolean leaf, int row, boolean focus) {
      DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;
      boolean toolNode = node.getUserObject() instanceof Tool;
      setText(node.toString());
      boolean exact=classic&&approvedShell();
      setFont(WorkbenchUi.font().deriveFont(!toolNode||exact&&active(node) ? Font.BOLD : Font.PLAIN,
          WorkbenchUi.displaySize(exact ? toolNode?12f:10f : classic ? toolNode ? 12.5f : 10.5f : toolNode ? 13.5f : 12.5f)));
      setBorder(BorderFactory.createEmptyBorder(exact ? toolNode?9:row==0?0:18 : toolNode?classic?8:6:classic?8:row==0?5:11,
          exact?toolNode?5:10:2,exact?toolNode?9:7:toolNode?classic?8:6:5,8));
      String kind=toolNode?((Tool)node.getUserObject()).id():groupIcon(node.toString());
      Icon icon = classic && !toolNode ? null : WorkspaceIcons.navigation(kind,
          active(node) ? WorkbenchUi.accent() : WorkbenchUi.toneInk(WorkbenchUi.Tone.NEUTRAL), !toolNode);
      if(exact&&toolNode){icon=new ApprovedTrafficIcon(kind,active(node)?WorkbenchUi.accent():kr.packetui.VisualTheme.muted());setIconTextGap(9);}else setIconTextGap(8);
      setIcon(icon);
      // The payload page attaches after navigation. Reserve its icon width even while unavailable.
      setDisabledIcon(icon);
      boolean available = !toolNode || indexOf(((Tool) node.getUserObject()).id()) >= 0;
      setEnabled(available);
      setForeground(available ? active(node) ? WorkbenchUi.accent()
          : classic && !toolNode ? kr.packetui.VisualTheme.muted() : WorkbenchUi.ink()
          : WorkbenchUi.toneInk(WorkbenchUi.Tone.NEUTRAL));
      setToolTipText(toolNode?FeatureGuide.feature(((Tool)node.getUserObject()).id()).summary():node.toString()+" · 펼치기/접기");
      return this;
    }

    @Override protected void paintComponent(Graphics graphics) {
      Graphics2D g = (Graphics2D) graphics.create();
      g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
      super.paintComponent(g);
      g.dispose();
    }
  }

  private static String groupIcon(String group){return switch(group){case "트래픽"->"traffic";case "탐색·정보 수집"->"discovery";case "보안 분석·검증"->"security";case "데이터 도구"->"data";default->"activity";};}

  private enum IconKind { FOLDER, OPEN_FOLDER, PAGE, RIGHT, DOWN }

  /** Java2D paths keep their edges sharp at the host's display scale. */
  private static final class NavigationIcon implements Icon {
    private final IconKind kind;
    NavigationIcon(IconKind kind) { this.kind = kind; }
    public int getIconWidth() { return kind == IconKind.RIGHT || kind == IconKind.DOWN ? 12 : 20; }
    public int getIconHeight() { return getIconWidth(); }

    public void paintIcon(Component component, Graphics graphics, int x, int y) {
      Graphics2D g = (Graphics2D) graphics.create();
      g.translate(x, y);
      g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      g.setStroke(new BasicStroke(1.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
      if (kind == IconKind.RIGHT || kind == IconKind.DOWN) {
        g.setColor(WorkbenchUi.dark() ? new Color(169, 181, 199) : new Color(99, 111, 129));
        Path2D arrow = new Path2D.Float();
        if (kind == IconKind.RIGHT) { arrow.moveTo(4, 2); arrow.lineTo(8, 6); arrow.lineTo(4, 10); }
        else { arrow.moveTo(2, 4); arrow.lineTo(6, 8); arrow.lineTo(10, 4); }
        g.draw(arrow);
      } else if (kind == IconKind.PAGE) {
        g.setColor(WorkbenchUi.dark() ? new Color(183, 195, 212) : new Color(101, 116, 137));
        Path2D page = new Path2D.Float();
        page.moveTo(5, 2); page.lineTo(11, 2); page.lineTo(16, 7); page.lineTo(16, 18);
        page.lineTo(5, 18); page.closePath();
        g.draw(page);
        g.drawLine(11, 2, 11, 7); g.drawLine(11, 7, 16, 7);
      } else {
        Path2D folder = new Path2D.Float();
        folder.moveTo(1, 5); folder.quadTo(1, 3, 3, 3); folder.lineTo(8, 3);
        folder.lineTo(10, 5); folder.lineTo(17, 5); folder.quadTo(19, 5, 19, 7);
        folder.lineTo(19, 16); folder.quadTo(19, 18, 17, 18); folder.lineTo(3, 18);
        folder.quadTo(1, 18, 1, 16); folder.closePath();
        g.setColor(new Color(225, 113, 26)); g.fill(folder);
        g.setColor(new Color(255, 169, 62)); g.drawLine(3, 6, 16, 6);
        if (kind == IconKind.OPEN_FOLDER) {
          Path2D front = new Path2D.Float();
          front.moveTo(1, 9); front.lineTo(20, 9); front.lineTo(18, 17);
          front.quadTo(18, 18, 16, 18); front.lineTo(3, 18); front.closePath();
          g.setColor(new Color(255, 150, 43)); g.fill(front);
        } else {
          g.setColor(new Color(255, 150, 43)); g.fillRoundRect(2, 8, 16, 9, 2, 2);
        }
      }
      g.dispose();
    }
  }

  private record Tool(String id) {
    @Override public String toString() { return FeatureGuide.title(id); }
  }

  private void folder(DefaultMutableTreeNode root, String name, String... ids) {
    DefaultMutableTreeNode group = new DefaultMutableTreeNode(name);
    root.add(group);
    for (String id : ids) {
      DefaultMutableTreeNode tool = new DefaultMutableTreeNode(new Tool(id), false);
      group.add(tool);
      tools.put(id, tool);
    }
  }

  private int indexOf(String id) {
    for (int i = 0; i < pages.getTabCount(); i++)
      if (pages.getComponentAt(i) instanceof JComponent page
          && id.equals(page.getClientProperty("wb.feature.id"))) return i;
    if (classic) {
      String host = switch (id) {
        case "data", "jwt" -> "traffic";
        case "passive" -> "environment";
        case "activity" -> "mapper";
        case "evidence" -> "bounty";
        default -> id;
      };
      if (!host.equals(id)) return indexOf(host);
    }
    return -1;
  }

  private boolean approvedShell(){return classic;}

  private String selectedToolId() {
    String route = currentRoute();
    String id = switch (route) {
      case "jwt" -> "data";
      case "evidence" -> "bounty";
      default -> route;
    };
    return tools.containsKey(id) ? id : selectedRoute();
  }

  void refreshSelection() {
    if(classic&&headerLine!=null){boolean exact=approvedShell();Component desired=exact?trafficHeader:standardHeaderActions;
      Component navigation=((BorderLayout)headerLine.getLayout()).getLayoutComponent(BorderLayout.WEST);
      if(navigation instanceof JPanel panel){panel.setBorder(BorderFactory.createEmptyBorder(0,exact?5:0,0,0));for(Component child:panel.getComponents())if(child instanceof JLabel brand){brand.setIconTextGap(exact?9:7);brand.putClientProperty("wb.traffic.brand",exact);}}
      ((BorderLayout)headerLine.getLayout()).setHgap(exact?11:8);
      if(((BorderLayout)headerLine.getLayout()).getLayoutComponent(BorderLayout.EAST)!=desired){headerLine.remove(exact?standardHeaderActions:trafficHeader);headerLine.add(desired,BorderLayout.EAST);
        if(exact){standardHeaderActions.setVisible(false);trafficHeader.add(standardHeaderActions);}else{trafficHeader.remove(standardHeaderActions);standardHeaderActions.setVisible(true);}headerLine.revalidate();}
      split.setDividerSize(exact?0:7);if(trafficFooter!=null)trafficFooter.setVisible(exact);
    }

    Component selected = pages.getSelectedComponent();
    if (!(selected instanceof JComponent page)) return;
    DefaultMutableTreeNode node = tools.get(selectedToolId());
    synchronizing = true;
    try {
      if (node == null) {
        tree.clearSelection();
        current.setText(FeatureGuide.title(Objects.toString(page.getClientProperty("wb.feature.id"), "")));
      } else {
        TreePath path = new TreePath(node.getPath());
        tree.setSelectionPath(path);
        tree.scrollPathToVisible(path);
        current.setText(node.toString());
      }
      current.setToolTipText(node==null?current.getText():node.getParent()+" / "+node);
      String group = node == null ? "" : Objects.toString(node.getParent(), "");
      if (node == null && primaryNavigation != null && "dashboard".equals(selectedToolId())) group = "통합 점검";
      breadcrumb.setText(group.isEmpty() ? "" : group + "  ›");
      breadcrumb.setToolTipText(group);
      breadcrumb.setForeground(kr.packetui.VisualTheme.muted());
    } finally { synchronizing = false; }
    if(primaryNavigation!=null)primaryNavigation.refreshSelection();
    updateApprovedFooter();tree.repaint();
  }

  private void updateApprovedFooter(){if(trafficFooter!=null)for(Component c:trafficFooter.getComponents())if(c instanceof JLabel label&&Boolean.TRUE.equals(label.getClientProperty("wb.traffic.footer")))label.setText((selectedToolId().isBlank()?"작업 공간":FeatureGuide.title(selectedToolId()))+" · "+(WorkbenchUi.dark()?"다크":"라이트"));}

  void restoreAppearance() {
    updateApprovedFooter();
    if(themeToggle!=null){String caption=WorkbenchUi.dark()?"라이트 모드로 전환":"다크 모드로 전환";themeToggle.setIcon(new ApprovedTrafficIcon(WorkbenchUi.dark()?"sun":"moon",kr.packetui.VisualTheme.muted()));themeToggle.setToolTipText(caption);themeToggle.getAccessibleContext().setAccessibleName(caption);}
    if(trafficFooter!=null)trafficFooter.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(1,0,0,0,WorkbenchUi.line()),BorderFactory.createEmptyBorder(0,206,0,16)));
    if(classic&&approvedShell()){split.setDividerSize(0);sidebar.setBorder(null);}

    if (tree.getUI().getClass().getEnclosingClass() != NavigationTree.class) tree.updateUI();
    tree.setCellRenderer(renderer);
    tree.setRowHeight(0);
    tree.setOpaque(false);
    tree.setFont(WorkbenchUi.font().deriveFont(WorkbenchUi.displaySize(15f)));
    tree.setBackground(kr.packetui.VisualTheme.sidebar());
    sidebar.getViewport().setBackground(kr.packetui.VisualTheme.sidebar());
    if(primaryNavigation!=null){
      primaryNavigation.restoreAppearance();
      sidebar.getColumnHeader().setBackground(kr.packetui.VisualTheme.sidebar());
    }
    tree.treeDidChange();
    if(classic){boolean exact=approvedShell();tree.setBorder(BorderFactory.createEmptyBorder(exact?13:4,9,6,exact?9:0));
      if(tree.getUI() instanceof BasicTreeUI ui){ui.setLeftChildIndent(exact?2:8);ui.setRightChildIndent(exact?4:10);}}
    sidebar.setMinimumSize(new Dimension(minimumMenuWidth(),80));
    constrainDivider();
  }

  void restoreLayout() {
    restoreAppearance();
    tree.setBackground(kr.packetui.VisualTheme.sidebar());
    sidebar.getViewport().setBackground(kr.packetui.VisualTheme.sidebar());
    sidebar.setVisible(!hidden);
    split.setDividerSize(hidden || classic&&approvedShell() ? 0 : 7);
    toggle.setText("");toggle.putClientProperty("wb.segment.button",true);
    toggle.setToolTipText("왼쪽 폴더 메뉴 " + (hidden ? "보기" : "숨기기") + " · Ctrl+Shift+M");
    toggle.getAccessibleContext().setAccessibleName(hidden ? "메뉴 보기" : "메뉴 숨기기");
    constrainDivider();
  }

  private void setMenuHidden(boolean value) {
    hidden = value;
    restoreLayout();
    write("hidden", Boolean.toString(hidden));
    revalidate();
    repaint();
  }

  @Override public void doLayout() {
    super.doLayout();
    // Apply responsive defaults before children lay out, including an initial layout
    // performed entirely on the EDT before queued resize events are delivered.
    if (split != null) constrainDivider();
  }

  private int minimumMenuWidth() {
    if(WorkbenchUi.appearanceScale()<=100)return MIN_WIDTH;
    int required=MIN_WIDTH;
    for(int row=0;row<tree.getRowCount();row++){
      TreePath path=tree.getPathForRow(row);Rectangle bounds=tree.getRowBounds(row);if(path==null||bounds==null)continue;
      Component label=renderer.getTreeCellRendererComponent(tree,path.getLastPathComponent(),false,tree.isExpanded(row),tree.getModel().isLeaf(path.getLastPathComponent()),row,false);
      required=Math.max(required,bounds.x+label.getPreferredSize().width+sidebar.getVerticalScrollBar().getPreferredSize().width+8);
    }
    return Math.min(MAX_WIDTH,required);
  }
  private int constrained(int width) {
    int minimum=minimumMenuWidth();
    int maximum = split.getWidth() > 0 ? Math.min(MAX_WIDTH, split.getWidth() - 367) : MAX_WIDTH;
    return Math.max(minimum, Math.min(Math.max(minimum, maximum), width));
  }

  private void constrainDivider() {
    adjusting = true;
    try {
      int requested = classic && !customMenuWidth && split.getWidth() > 0 && split.getWidth() <= 1300
          ? NARROW_WIDTH : menuWidth;
      split.setDividerLocation(hidden ? 0 : constrained(requested));
    }
    finally { adjusting = false; }
  }

  private String read(String suffix) {
    try { return api.persistence().preferences().getString(BuildInfo.storageKey("wb.navigation." + suffix)); }
    catch (Exception ignored) { return null; }
  }

  private void write(String suffix, String value) {
    try { api.persistence().preferences().setString(BuildInfo.storageKey("wb.navigation." + suffix), value); }
    catch (Exception ignored) { /* Layout remains usable if preferences are unavailable. */ }
  }
}
