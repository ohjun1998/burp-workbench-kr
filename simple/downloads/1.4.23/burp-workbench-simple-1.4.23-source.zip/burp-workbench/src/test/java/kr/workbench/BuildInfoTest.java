package kr.workbench;

import java.nio.file.Path;
import java.util.jar.JarFile;

/** Checks the packaged runtime identity, not just matching source constants. */
public final class BuildInfoTest {
    public static void main(String[] args) throws Exception {
        Path artifact = Path.of(BuildInfo.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        if (!artifact.toString().endsWith(".jar")) {
            throw new AssertionError("Run the release identity regression against the packaged JAR");
        }
        try (JarFile jar = new JarFile(artifact.toFile())) {
            String version = jar.getManifest().getMainAttributes().getValue("Implementation-Version");
            if (!BuildInfo.VERSION.equals(version)) throw new AssertionError("Runtime/manifest version mismatch");
            if (!artifact.getFileName().toString().equals(BuildInfo.ARTIFACT_ID + "-" + version + ".jar")) {
                throw new AssertionError("Artifact filename/manifest version mismatch");
            }
            if (!BuildInfo.IMPLEMENTATION_TITLE.equals(jar.getManifest().getMainAttributes().getValue("Implementation-Title"))) {
                throw new AssertionError("Runtime/manifest product title mismatch");
            }
            if (!FeatureGuide.EXTENSION_NAME.equals(BuildInfo.DISPLAY_NAME)) throw new AssertionError("Display identity mismatch");
            if (jar.stream().map(entry -> entry.getName()).anyMatch(name -> name.startsWith("kr/workbench/SimpleStrix") || name.startsWith("strix/"))) {
                throw new AssertionError("Removed Strix classes or runtime resources remain in the Simple JAR");
            }
        }
        System.out.println("BuildInfoTest: 5 checks passed");
    }
}
